"""
Custom exceptions for the NLP Pipeline.
"""

class PipelineException(Exception):
    """Base exception for all pipeline-related errors."""
    def __init__(self, message="An error occurred in the NLP pipeline"):
        self.message = message
        super().__init__(self.message)

class ConfigurationException(PipelineException):
    """Exception raised for errors in the configuration."""
    def __init__(self, message="Error in pipeline configuration"):
        self.message = message
        super().__init__(self.message)

class DataSourceException(PipelineException):
    """Exception raised for errors in data source operations."""
    def __init__(self, message="Error in data source operations"):
        self.message = message
        super().__init__(self.message)

class PreprocessingException(PipelineException):
    """Exception raised for errors in text preprocessing."""
    def __init__(self, message="Error in text preprocessing"):
        self.message = message
        super().__init__(self.message)

class ChunkingException(PipelineException):
    """Exception raised for errors in text chunking."""
    def __init__(self, message="Error in text chunking"):
        self.message = message
        super().__init__(self.message)

class EmbeddingException(PipelineException):
    """Exception raised for errors in embedding generation."""
    def __init__(self, message="Error in embedding generation"):
        self.message = message
        super().__init__(self.message)

class TargetException(PipelineException):
    """Exception raised for errors in target operations."""
    def __init__(self, message="Error in target operations"):
        self.message = message
        super().__init__(self.message)

class ChromaDBException(TargetException):
    """Exception raised for errors in ChromaDB operations."""
    def __init__(self, message="Error in ChromaDB operations"):
        self.message = message
        super().__init__(self.message)

class PostgresVectorException(TargetException):
    """Exception raised for errors in PostgreSQL vector operations."""
    def __init__(self, message="Error in PostgreSQL vector operations"):
        self.message = message
        super().__init__(self.message)

class Neo4jException(TargetException):
    """Exception raised for errors in Neo4j operations."""
    def __init__(self, message="Error in Neo4j operations"):
        self.message = message
        super().__init__(self.message)

class DataReadError(DataSourceException):
    """Exception raised for errors in reading data"""
    pass

class DataWriteError(PipelineException):
    """Exception raised for errors in writing data"""
    pass

class ModelLoadError(EmbeddingException):
    """Exception raised for errors in loading models"""
    pass

class DependencyError(PipelineException):
    """Exception raised for missing dependencies"""
    pass

class ValidationError(PipelineException):
    """Exception raised for validation errors"""
    pass

class CircuitBreakerError(PipelineException):
    """Exception raised when the circuit breaker is triggered"""
    pass

class TimeoutError(PipelineException):
    """Exception raised for operations that time out"""
    pass

class RetryExhaustionError(PipelineException):
    """Exception raised when all retries are exhausted"""
    pass

def handle_exception(func):
    """Decorator for handling exceptions and adding context"""
    import functools
    import traceback
    import logging
    
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except PipelineException as e:
            # Just re-raise pipeline errors as they already have context
            logging.error(f"Pipeline error in {func.__name__}: {e}")
            raise
        except Exception as e:
            # Wrap other exceptions with context
            module_name = func.__module__
            func_name = func.__name__
            stack_trace = traceback.format_exc()
            
            details = {
                "module": module_name,
                "function": func_name,
                "original_error": str(e),
                "stack_trace": stack_trace
            }
            
            logging.error(f"Error in {module_name}.{func_name}: {e}\n{stack_trace}")
            
            # Wrap in appropriate exception type based on context
            if "config" in module_name.lower():
                raise ConfigurationException(f"Configuration error in {func_name}", details) from e
            elif "source" in module_name.lower():
                raise DataSourceException(f"Data source error in {func_name}", details) from e
            elif "preprocess" in module_name.lower():
                raise PreprocessingException(f"Preprocessing error in {func_name}", details) from e
            elif "chunk" in module_name.lower():
                raise ChunkingException(f"Chunking error in {func_name}", details) from e
            elif "embed" in module_name.lower():
                raise EmbeddingException(f"Embedding error in {func_name}", details) from e
            elif "target" in module_name.lower():
                raise TargetException(f"Target error in {func_name}", details) from e
            else:
                raise PipelineException(f"Error in {module_name}.{func_name}", details) from e
    
    return wrapper

class CircuitBreaker:
    """Circuit breaker pattern implementation"""
    
    def __init__(self, failure_threshold: int = 3, recovery_timeout: int = 30, name: str = "default"):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.name = name
        self.failure_count = 0
        self.last_failure_time = 0
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
    
    def __call__(self, func):
        import functools
        import time
        import logging
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            current_time = time.time()
            
            # Check if in OPEN state and if recovery timeout has elapsed
            if self.state == "OPEN":
                if current_time - self.last_failure_time > self.recovery_timeout:
                    logging.info(f"Circuit {self.name} transitioning from OPEN to HALF_OPEN state")
                    self.state = "HALF_OPEN"
                else:
                    raise CircuitBreakerError(
                        f"Circuit {self.name} is OPEN. Retry after {self.recovery_timeout - (current_time - self.last_failure_time):.2f} seconds",
                        {"circuit": self.name, "state": self.state}
                    )
            
            try:
                result = func(*args, **kwargs)
                
                # If successful in HALF_OPEN, reset to CLOSED
                if self.state == "HALF_OPEN":
                    logging.info(f"Circuit {self.name} transitioning from HALF_OPEN to CLOSED state")
                    self.state = "CLOSED"
                    self.failure_count = 0
                
                return result
            
            except Exception as e:
                # Increment failure count
                self.failure_count += 1
                self.last_failure_time = current_time
                
                # If threshold reached, open the circuit
                if self.failure_count >= self.failure_threshold:
                    if self.state != "OPEN":
                        logging.warning(f"Circuit {self.name} transitioning to OPEN state after {self.failure_count} failures")
                        self.state = "OPEN"
                
                # Re-raise the original exception
                raise
        
        return wrapper

def retry(max_attempts: int = 3, delay: float = 1.0, backoff: float = 2.0, exceptions=None):
    """Retry decorator with exponential backoff"""
    if exceptions is None:
        exceptions = (Exception,)
    
    import functools
    import time
    import logging
    import random
    
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            attempt = 0
            current_delay = delay
            
            while attempt < max_attempts:
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    attempt += 1
                    if attempt >= max_attempts:
                        raise RetryExhaustionError(
                            f"All {max_attempts} retry attempts failed for {func.__name__}",
                            {"attempts": attempt, "last_error": str(e)}
                        ) from e
                    
                    # Add jitter to avoid thundering herd
                    jitter = random.uniform(0, 0.1 * current_delay)
                    wait_time = current_delay + jitter
                    
                    logging.warning(
                        f"Retry {attempt}/{max_attempts} for {func.__name__} after {wait_time:.2f}s: {str(e)}"
                    )
                    
                    time.sleep(wait_time)
                    current_delay *= backoff
        
        return wrapper
    
    return decorator

def timeout(seconds: int):
    """Timeout decorator to limit execution time of a function"""
    import functools
    import signal
    
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            def handler(signum, frame):
                raise TimeoutError(
                    f"Function {func.__name__} timed out after {seconds} seconds",
                    {"timeout": seconds}
                )
            
            # Set the timeout handler
            original_handler = signal.signal(signal.SIGALRM, handler)
            signal.alarm(seconds)
            
            try:
                return func(*args, **kwargs)
            finally:
                # Reset the alarm and restore original handler
                signal.alarm(0)
                signal.signal(signal.SIGALRM, original_handler)
        
        return wrapper
    
    return decorator 