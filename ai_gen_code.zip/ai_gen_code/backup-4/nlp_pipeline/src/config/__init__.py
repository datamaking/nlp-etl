"""
Configuration module for NLP Pipeline.
"""

from .config import PipelineConfig

__all__ = ['PipelineConfig'] 