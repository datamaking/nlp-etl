"""
Configuration classes for the NLP ETL Pipeline
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Union, Any
import os
import yaml
import json
import logging
from pyspark.sql import SparkSession
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables
load_dotenv()

class Department(Enum):
    """Enum for departments"""
    ADMIN = "ADMIN"
    HR = "HR"
    FINANCE = "FINANCE"
    IT_HELPDESK = "IT_HELPDESK"


class SourceType(Enum):
    """Enum for data source types"""
    HIVE = "HIVE"
    HDFS = "HDFS"
    LOCAL_FILE = "LOCAL_FILE"
    RDBMS = "RDBMS"


class FileFormat(Enum):
    """Enum for file formats"""
    TEXT = "TEXT"
    HTML = "HTML"
    JSON = "JSON"
    CSV = "CSV"


class TargetType(Enum):
    """Enum for data target types"""
    HIVE = "HIVE"
    HDFS = "HDFS"
    LOCAL_FILE = "LOCAL_FILE"
    RDBMS = "RDBMS"
    CHROMADB = "CHROMADB"
    POSTGRES_VECTOR = "POSTGRES_VECTOR"
    NEO4J = "NEO4J"


class LoadType(Enum):
    """Enum for data load types"""
    FULL = "FULL"
    INCREMENTAL_SCD2 = "INCREMENTAL_SCD2"
    INCREMENTAL_CDC = "INCREMENTAL_CDC"


class PreprocessingType(Enum):
    """Enum for preprocessing types"""
    HTML_PARSING = "HTML_PARSING"
    DATA_CLEANING = "DATA_CLEANING"
    STOPWORD_REMOVAL = "STOPWORD_REMOVAL"
    STEMMING = "STEMMING"
    LEMMATIZATION = "LEMMATIZATION"


class ChunkingStrategy(Enum):
    """Enum for chunking strategies"""
    FIXED_SIZE = "FIXED_SIZE"
    SENTENCE = "SENTENCE"
    PARAGRAPH = "PARAGRAPH"
    RECURSIVE = "RECURSIVE"
    SEMANTIC = "SEMANTIC"


class EmbeddingType(Enum):
    """Enum for embedding types"""
    TFIDF = "TFIDF"
    SENTENCE_ST5 = "SENTENCE_ST5"


@dataclass
class BaseConfig(ABC):
    """Abstract base configuration class"""
    name: str
    department: Department
    
    @abstractmethod
    def validate(self) -> bool:
        """Validate configuration"""
        pass
    
    def to_dict(self) -> Dict:
        """Convert config to dictionary"""
        return {k: (v.value if isinstance(v, Enum) else v) 
                for k, v in self.__dict__.items()}


@dataclass
class SourceConfig(BaseConfig):
    """Configuration for data sources"""
    source_type: SourceType
    file_format: Optional[FileFormat] = None
    tables: List[str] = field(default_factory=list)
    queries: List[str] = field(default_factory=list)
    join_columns: Optional[Dict[str, str]] = None
    connection_params: Optional[Dict[str, str]] = None
    file_paths: List[str] = field(default_factory=list)
    text_column: Optional[str] = None
    
    def validate(self) -> bool:
        """Validate source configuration"""
        if self.source_type in [SourceType.HIVE, SourceType.RDBMS] and not (self.tables or self.queries):
            return False
        if self.source_type in [SourceType.HDFS, SourceType.LOCAL_FILE] and not self.file_paths:
            return False
        if self.source_type == SourceType.RDBMS and not self.connection_params:
            return False
        return True


@dataclass
class PreprocessingConfig(BaseConfig):
    """Configuration for preprocessing"""
    preprocessing_types: List[PreprocessingType]
    params: Dict[str, Any] = field(default_factory=dict)
    
    def validate(self) -> bool:
        """Validate preprocessing configuration"""
        if not self.preprocessing_types:
            return False
        return True


@dataclass
class ChunkingConfig(BaseConfig):
    """Configuration for chunking"""
    chunking_strategy: ChunkingStrategy
    chunk_size: int = 512
    chunk_overlap: int = 50
    enable_smoothing: bool = True
    
    def validate(self) -> bool:
        """Validate chunking configuration"""
        if self.chunk_size <= 0:
            return False
        if self.chunk_overlap >= self.chunk_size:
            return False
        return True


@dataclass
class EmbeddingConfig(BaseConfig):
    """Configuration for embedding generation"""
    embedding_type: EmbeddingType
    model_path: Optional[str] = None
    batch_size: int = 32
    max_sequence_length: int = 512
    
    def validate(self) -> bool:
        """Validate embedding configuration"""
        if self.embedding_type == EmbeddingType.SENTENCE_ST5 and not self.model_path:
            return False
        if self.batch_size <= 0:
            return False
        return True


@dataclass
class TargetConfig(BaseConfig):
    """Configuration for data targets"""
    target_type: TargetType
    load_type: LoadType
    file_format: Optional[FileFormat] = None
    table_name: Optional[str] = None
    file_path: Optional[str] = None
    connection_params: Optional[Dict[str, str]] = None
    partition_columns: List[str] = field(default_factory=list)
    
    def validate(self) -> bool:
        """Validate target configuration"""
        if self.target_type in [TargetType.HIVE, TargetType.RDBMS] and not self.table_name:
            return False
        if self.target_type in [TargetType.HDFS, TargetType.LOCAL_FILE] and not self.file_path:
            return False
        if self.target_type in [TargetType.RDBMS, TargetType.CHROMADB, 
                               TargetType.POSTGRES_VECTOR, TargetType.NEO4J] and not self.connection_params:
            return False
        return True


class PipelineConfig:
    """
    Manages the configuration for the NLP Pipeline.
    Loads configuration from YAML files and environment variables.
    """
    
    def __init__(self, config_path: str):
        """
        Initialize the configuration with the path to a YAML config file.
        
        Args:
            config_path: Path to configuration file
        """
        self.config_path = config_path
        self.config = self._load_config()
        self._validate_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """
        Load configuration from the YAML file and apply any environment variables.
        
        Returns:
            Dict containing configuration settings
        """
        try:
            with open(self.config_path, 'r', encoding='utf-8') as file:
                config = yaml.safe_load(file)
                
            # Process environment variable placeholders in the config
            self._process_env_vars(config)
            
            return config
        except Exception as e:
            raise ValueError(f"Failed to load configuration from {self.config_path}: {e}")
    
    def _process_env_vars(self, config: Any) -> None:
        """
        Replace environment variable placeholders in the config with actual values.
        Processes the config in-place.
        
        Args:
            config: Configuration object to process
        """
        if isinstance(config, dict):
            for key, value in config.items():
                config[key] = self._process_env_vars(value)
        elif isinstance(config, list):
            for i, item in enumerate(config):
                config[i] = self._process_env_vars(item)
        elif isinstance(config, str) and config.startswith("${") and config.endswith("}"):
            env_var = config[2:-1]
            env_value = os.environ.get(env_var)
            if env_value is None:
                raise ValueError(f"Environment variable {env_var} not found")
            return env_value
        return config
    
    def _validate_config(self) -> None:
        """
        Validate the structure and values of the loaded configuration.
        Raises ValueError if the configuration is invalid.
        """
        # Check required sections
        required_sections = ['pipeline_name', 'spark', 'source', 'target']
        for section in required_sections:
            if section not in self.config:
                raise ValueError(f"Missing required configuration section: {section}")
        
        # Validate specific configuration sections
        self._validate_spark_config()
        self._validate_source_config()
        self._validate_preprocessing_config()
        self._validate_chunking_config()
        self._validate_embedding_config()
        self._validate_target_config()
    
    def _validate_spark_config(self) -> None:
        """Validate Spark configuration section."""
        spark_config = self.config.get('spark', {})
        required_spark_fields = ['app_name', 'master']
        for field in required_spark_fields:
            if field not in spark_config:
                raise ValueError(f"Missing required Spark configuration field: {field}")
    
    def _validate_source_config(self) -> None:
        """Validate data source configuration section."""
        source_config = self.config.get('source', {})
        if 'type' not in source_config:
            raise ValueError("Source configuration must specify 'type'")
        
        if 'parameters' not in source_config:
            raise ValueError("Source configuration must include 'parameters'")
        
        # Validate text column is specified
        if 'text_column' not in source_config:
            raise ValueError("Source configuration must specify 'text_column'")
    
    def _validate_preprocessing_config(self) -> None:
        """Validate preprocessing configuration section if present."""
        if 'preprocessing' in self.config:
            preproc_config = self.config['preprocessing']
            if 'operations' not in preproc_config:
                raise ValueError("Preprocessing configuration must specify 'operations'")
            
            if not isinstance(preproc_config['operations'], list):
                raise ValueError("Preprocessing 'operations' must be a list")
    
    def _validate_chunking_config(self) -> None:
        """Validate chunking configuration section if present."""
        if 'chunking' in self.config:
            chunking_config = self.config['chunking']
            if 'type' not in chunking_config:
                raise ValueError("Chunking configuration must specify 'type'")
            
            if 'parameters' not in chunking_config:
                raise ValueError("Chunking configuration must include 'parameters'")
    
    def _validate_embedding_config(self) -> None:
        """Validate embedding configuration section if present."""
        if 'embedding' in self.config:
            embedding_config = self.config['embedding']
            if 'type' not in embedding_config:
                raise ValueError("Embedding configuration must specify 'type'")
            
            if 'model' not in embedding_config:
                raise ValueError("Embedding configuration must specify 'model'")
    
    def _validate_target_config(self) -> None:
        """Validate target configuration section."""
        target_config = self.config.get('target', {})
        if 'type' not in target_config:
            raise ValueError("Target configuration must specify 'type'")
        
        if 'parameters' not in target_config:
            raise ValueError("Target configuration must include 'parameters'")
    
    def get_pipeline_name(self) -> str:
        """Get the pipeline name from the configuration."""
        return self.config.get('pipeline_name', 'NLP Pipeline')
    
    def get_pipeline_description(self) -> str:
        """Get the pipeline description from the configuration."""
        return self.config.get('description', '')
    
    def get_spark_config(self) -> Dict[str, Any]:
        """Get the Spark configuration section."""
        return self.config.get('spark', {})
    
    def get_source_config(self) -> Dict[str, Any]:
        """Get the data source configuration section."""
        return self.config.get('source', {})
    
    def get_preprocessing_config(self) -> Dict[str, Any]:
        """Get the preprocessing configuration section."""
        return self.config.get('preprocessing', {})
    
    def get_chunking_config(self) -> Dict[str, Any]:
        """Get the chunking configuration section."""
        return self.config.get('chunking', {})
    
    def get_embedding_config(self) -> Dict[str, Any]:
        """Get the embedding configuration section."""
        return self.config.get('embedding', {})
    
    def get_target_config(self) -> Dict[str, Any]:
        """Get the target configuration section."""
        return self.config.get('target', {})
    
    def get_intermediate_storage_config(self) -> Dict[str, Any]:
        """Get the intermediate storage configuration section."""
        return self.config.get('intermediate_storage', {})
    
    def build_spark_session(self) -> SparkSession:
        """
        Build and configure a Spark session based on configuration.
        
        Returns:
            Configured SparkSession
        """
        spark_config = self.get_spark_config()
        
        # Create Spark session builder
        builder = (
            SparkSession.builder
            .appName(spark_config.get('app_name', 'NLP Pipeline'))
            .master(spark_config.get('master', 'local[*]'))
        )
        
        # Set executor and driver memory if provided
        if 'executor_memory' in spark_config:
            builder = builder.config('spark.executor.memory', spark_config['executor_memory'])
            
        if 'driver_memory' in spark_config:
            builder = builder.config('spark.driver.memory', spark_config['driver_memory'])
        
        # Set additional config parameters if provided
        for key, value in spark_config.get('config', {}).items():
            builder = builder.config(key, value)
        
        # Create and return the Spark session
        return builder.getOrCreate()
    
    def create_checkpoint_path(self, stage: str) -> Optional[str]:
        """
        Get the checkpoint path for a specific pipeline stage.
        
        Args:
            stage: Pipeline stage name (extraction, preprocessing, chunking, embedding)
            
        Returns:
            Path string or None if checkpoints are not configured
        """
        storage_config = self.get_intermediate_storage_config()
        if not storage_config:
            return None
        
        path = storage_config.get(stage)
        if path:
            # Create directory if it doesn't exist
            os.makedirs(path, exist_ok=True)
            return path
        
        return None

    def __getitem__(self, key: str) -> Any:
        """Allow dictionary-like access to configuration."""
        return self.config.get(key)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value with an optional default."""
        return self.config.get(key, default)


class ConfigurationFactory:
    """Factory class for creating configurations"""
    
    @staticmethod
    def create_source_config(
        name: str,
        department: Department,
        source_type: SourceType,
        **kwargs
    ) -> SourceConfig:
        """Create a source configuration"""
        return SourceConfig(
            name=name,
            department=department,
            source_type=source_type,
            **kwargs
        )
    
    @staticmethod
    def create_preprocessing_config(
        name: str,
        department: Department,
        preprocessing_types: List[PreprocessingType],
        **kwargs
    ) -> PreprocessingConfig:
        """Create a preprocessing configuration"""
        return PreprocessingConfig(
            name=name,
            department=department,
            preprocessing_types=preprocessing_types,
            **kwargs
        )
    
    @staticmethod
    def create_chunking_config(
        name: str,
        department: Department,
        chunking_strategy: ChunkingStrategy,
        **kwargs
    ) -> ChunkingConfig:
        """Create a chunking configuration"""
        return ChunkingConfig(
            name=name,
            department=department,
            chunking_strategy=chunking_strategy,
            **kwargs
        )
    
    @staticmethod
    def create_embedding_config(
        name: str,
        department: Department,
        embedding_type: EmbeddingType,
        **kwargs
    ) -> EmbeddingConfig:
        """Create an embedding configuration"""
        return EmbeddingConfig(
            name=name,
            department=department,
            embedding_type=embedding_type,
            **kwargs
        )
    
    @staticmethod
    def create_target_config(
        name: str,
        department: Department,
        target_type: TargetType,
        load_type: LoadType,
        **kwargs
    ) -> TargetConfig:
        """Create a target configuration"""
        return TargetConfig(
            name=name,
            department=department,
            target_type=target_type,
            load_type=load_type,
            **kwargs
        )
    
    @staticmethod
    def create_pipeline_config(
        pipeline_name: str,
        department: Department,
        **kwargs
    ) -> PipelineConfig:
        """Create a pipeline configuration"""
        return PipelineConfig(
            config_path=pipeline_name
        ) 