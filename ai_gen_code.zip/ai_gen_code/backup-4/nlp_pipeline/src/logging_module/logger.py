"""
Logging utilities for the NLP Pipeline.
"""

import os
import sys
import logging
from datetime import datetime
from typing import Optional
from pathlib import Path
from loguru import logger

# Default logging configuration
DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_LOG_FORMAT = "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
DEFAULT_LOG_DIR = "logs"

def setup_logger(
    log_level: str = None, 
    log_dir: str = None,
    module_name: str = "nlp_pipeline"
) -> None:
    """
    Set up the logger for the NLP Pipeline.
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_dir: Directory to store log files
        module_name: Name of the module for which the logger is configured
    """
    # Get log level from environment or use default
    log_level = log_level or os.environ.get("LOG_LEVEL", DEFAULT_LOG_LEVEL)
    
    # Get log directory from environment or use default
    log_dir = log_dir or os.environ.get("LOG_DIR", DEFAULT_LOG_DIR)
    
    # Create log directory if it doesn't exist
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    
    # Generate log file name with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = f"{log_dir}/{module_name}_{timestamp}.log"
    
    # Configure logger
    logger.remove()  # Remove default handler
    
    # Add console handler with colored output
    logger.add(
        sys.stderr,
        format=DEFAULT_LOG_FORMAT,
        level=log_level,
        colorize=True
    )
    
    # Add file handler
    logger.add(
        log_file,
        format=DEFAULT_LOG_FORMAT,
        level=log_level,
        rotation="10 MB",  # Rotate when file reaches 10 MB
        retention="1 month",  # Keep logs for 1 month
        compression="zip"  # Compress rotated logs
    )
    
    # Configure logging for libraries that use standard logging
    logging.basicConfig(handlers=[InterceptHandler()], level=0, force=True)
    
    # Log startup information
    logger.info(f"Logging initialized for {module_name} at level {log_level}")
    logger.info(f"Log file: {log_file}")


def get_logger(name: str) -> logger:
    """
    Get a logger instance for a specific module.
    
    Args:
        name: Name of the module
        
    Returns:
        Configured logger instance
    """
    return logger.bind(name=name)


class InterceptHandler(logging.Handler):
    """
    Intercepts standard logging messages and redirects them to loguru.
    This allows handling logs from other libraries that use the standard logging module.
    """
    def emit(self, record):
        # Get corresponding Loguru level if it exists
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno
        
        # Find caller from where the logged message originated
        frame, depth = logging.currentframe(), 2
        while frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1
        
        # Log using loguru
        logger.opt(depth=depth, exception=record.exc_info).log(
            level, record.getMessage()
        ) 