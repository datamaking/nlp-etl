"""
Base class for text chunkers in the NLP Pipeline.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pyspark.sql import DataFrame

from ..exception import ChunkingException
from ..logging_module import get_logger

logger = get_logger(__name__)

class Chunker(ABC):
    """
    Abstract base class for all chunkers.
    
    Chunkers are responsible for splitting text into smaller chunks
    that can be processed by embedding models.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the chunker.
        
        Args:
            config: Configuration dictionary for the chunker
        """
        self.config = config
        self.parameters = config.get("parameters", {})
        self.input_column = config.get("input_column", "processed_text")
        self.output_column = config.get("output_column", "chunks")
        
        # Validate configuration
        self._validate_config()
        
        logger.info(f"Initialized {self.__class__.__name__}")
    
    def _validate_config(self) -> None:
        """
        Validate the chunker configuration.
        
        Raises:
            ChunkingException: If configuration is invalid
        """
        if not self.input_column:
            raise ChunkingException("Input column must be specified")
        
        if not self.output_column:
            raise ChunkingException("Output column must be specified")
        
        # Chunker-specific validation
        self._validate_chunker_config()
    
    def _validate_chunker_config(self) -> None:
        """
        Validate chunker-specific configuration.
        
        This method should be overridden by subclasses to provide
        chunker-specific validation.
        
        Raises:
            ChunkingException: If configuration is invalid
        """
        pass
    
    @abstractmethod
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data using the configured chunking strategy.
        
        Args:
            df: DataFrame containing the data to process
            
        Returns:
            DataFrame with exploded chunks
            
        Raises:
            ChunkingException: If processing fails
        """
        pass 