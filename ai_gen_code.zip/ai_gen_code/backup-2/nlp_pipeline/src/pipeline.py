"""
Main pipeline orchestration module for the NLP ETL Pipeline
"""
from typing import Dict, List, Optional, Any
import logging
import os
import sys
import argparse
import yaml
import time

from pyspark.sql import DataFrame, SparkSession

from src.config.config import PipelineConfig, ConfigurationFactory
from src.data_source.data_source import DataSourceFactory
from src.preprocessing.preprocessor import PreprocessorFactory
from src.chunking.chunker import ChunkerFactory, explode_chunks
from src.embedding.embedder import EmbedderFactory
from src.target.target_base import TargetFactory
from src.logging_module.logger import get_logger, log_execution_time, PipelineLogger
from src.exception.exceptions import handle_exception, NLPPipelineError
from src.utils.spark_utils import persist_dataframe, save_checkpoint

logger = get_logger(__name__)


class NLPPipeline:
    """
    Main pipeline orchestration class for the NLP ETL Pipeline
    
    This class is responsible for orchestrating the entire ETL pipeline:
    1. Loading configuration
    2. Creating a Spark session
    3. Extracting data from sources
    4. Preprocessing the data
    5. Chunking the text
    6. Generating embeddings
    7. Writing to targets
    """
    
    def __init__(self, config_path: str, log_level: str = "INFO", log_dir: str = "logs"):
        """
        Initialize the NLP Pipeline
        
        Args:
            config_path: Path to the pipeline configuration file
            log_level: Logging level
            log_dir: Directory to store logs
        """
        self.config_path = config_path
        
        # Initialize logger
        self.pipeline_logger = PipelineLogger(log_level=log_level, log_dir=log_dir)
        self.logger = self.pipeline_logger.logger
        
        # Load configuration
        self.config = self._load_config()
        
        # Create Spark session
        self.spark = self.config.get_spark_session()
        
        # Initialize components
        self.source = None
        self.preprocessor = None
        self.chunker = None
        self.embedder = None
        self.target = None
    
    @handle_exception
    def _load_config(self) -> PipelineConfig:
        """
        Load configuration from file
        
        Returns:
            Pipeline configuration
        """
        self.logger.info(f"Loading configuration from {self.config_path}")
        
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
        
        return PipelineConfig.from_yaml(self.config_path)
    
    @handle_exception
    def initialize_components(self) -> None:
        """
        Initialize pipeline components based on configuration
        """
        self.logger.info("Initializing pipeline components")
        
        # Initialize data source
        if self.config.source_config:
            self.logger.info("Initializing data source")
            self.source = DataSourceFactory.create_data_source(
                self.config.source_config, 
                self.spark
            )
        
        # Initialize preprocessor
        if self.config.preprocessing_config:
            self.logger.info("Initializing preprocessor")
            self.preprocessor = PreprocessorFactory.create_preprocessor(
                self.config.preprocessing_config, 
                self.spark
            )
        
        # Initialize chunker
        if self.config.chunking_config:
            self.logger.info("Initializing chunker")
            self.chunker = ChunkerFactory.create_chunker(
                self.config.chunking_config, 
                self.spark
            )
        
        # Initialize embedder
        if self.config.embedding_config:
            self.logger.info("Initializing embedder")
            self.embedder = EmbedderFactory.create_embedder(
                self.config.embedding_config, 
                self.spark
            )
        
        # Initialize target
        if self.config.target_config:
            self.logger.info("Initializing target")
            self.target = TargetFactory.create_target(
                self.config.target_config, 
                self.spark
            )
    
    @log_execution_time(stage_name="DataExtraction")
    @handle_exception
    def extract_data(self) -> DataFrame:
        """
        Extract data from source
        
        Returns:
            DataFrame with extracted data
        """
        self.logger.info("Extracting data from source")
        
        if not self.source:
            raise NLPPipelineError("Data source not initialized")
        
        df = self.source.read_data()
        
        # Save checkpoint if configured
        if "extraction" in self.config.intermediate_storage:
            checkpoint_dir = self.config.intermediate_storage["extraction"]
            df = save_checkpoint(df, checkpoint_dir, "extraction")
        
        return df
    
    @log_execution_time(stage_name="DataPreprocessing")
    @handle_exception
    def preprocess_data(self, df: DataFrame) -> DataFrame:
        """
        Preprocess data
        
        Args:
            df: DataFrame with raw data
            
        Returns:
            DataFrame with preprocessed data
        """
        self.logger.info("Preprocessing data")
        
        if not self.preprocessor:
            self.logger.info("No preprocessing configured, skipping")
            return df
        
        processed_df = self.preprocessor.preprocess(df)
        
        # Save checkpoint if configured
        if "preprocessing" in self.config.intermediate_storage:
            checkpoint_dir = self.config.intermediate_storage["preprocessing"]
            processed_df = save_checkpoint(processed_df, checkpoint_dir, "preprocessing")
        
        return processed_df
    
    @log_execution_time(stage_name="TextChunking")
    @handle_exception
    def chunk_text(self, df: DataFrame) -> DataFrame:
        """
        Chunk text data
        
        Args:
            df: DataFrame with preprocessed data
            
        Returns:
            DataFrame with chunked text
        """
        self.logger.info("Chunking text")
        
        if not self.chunker:
            self.logger.info("No chunking configured, skipping")
            return df
        
        # Apply chunking
        chunked_df = self.chunker.chunk(df)
        
        # Explode chunks into separate rows
        exploded_df = explode_chunks(chunked_df)
        
        # Save checkpoint if configured
        if "chunking" in self.config.intermediate_storage:
            checkpoint_dir = self.config.intermediate_storage["chunking"]
            exploded_df = save_checkpoint(exploded_df, checkpoint_dir, "chunking")
        
        return exploded_df
    
    @log_execution_time(stage_name="EmbeddingGeneration")
    @handle_exception
    def generate_embeddings(self, df: DataFrame) -> DataFrame:
        """
        Generate embeddings for text
        
        Args:
            df: DataFrame with chunked text
            
        Returns:
            DataFrame with embeddings
        """
        self.logger.info("Generating embeddings")
        
        if not self.embedder:
            self.logger.info("No embedding generation configured, skipping")
            return df
        
        # Generate embeddings
        embedding_df = self.embedder.generate_embeddings(df)
        
        # Save checkpoint if configured
        if "embedding" in self.config.intermediate_storage:
            checkpoint_dir = self.config.intermediate_storage["embedding"]
            embedding_df = save_checkpoint(embedding_df, checkpoint_dir, "embedding")
        
        return embedding_df
    
    @log_execution_time(stage_name="DataLoading")
    @handle_exception
    def load_data(self, df: DataFrame) -> None:
        """
        Load data to target
        
        Args:
            df: DataFrame with embeddings
        """
        self.logger.info("Loading data to target")
        
        if not self.target:
            self.logger.info("No target configured, skipping")
            return
        
        # Write data to target
        self.target.write_data(df)
    
    @log_execution_time(stage_name="PipelineExecution")
    @handle_exception
    def run(self) -> None:
        """
        Run the complete pipeline
        """
        self.logger.info(f"Starting NLP ETL Pipeline: {self.config.pipeline_name}")
        
        try:
            # Start pipeline timer
            self.pipeline_logger.start_pipeline_timer()
            
            # Initialize components
            self.initialize_components()
            
            # Extract data
            df = self.extract_data()
            self.logger.info(f"Extracted {df.count()} records from source")
            
            # Preprocess data
            df = self.preprocess_data(df)
            self.logger.info(f"Preprocessed data: {df.count()} records")
            
            # Chunk text
            df = self.chunk_text(df)
            self.logger.info(f"Chunked text: {df.count()} chunks")
            
            # Generate embeddings
            df = self.generate_embeddings(df)
            self.logger.info(f"Generated embeddings: {df.count()} embeddings")
            
            # Load data to target
            self.load_data(df)
            self.logger.info("Data loaded to target")
            
            # End pipeline timer and log summary
            elapsed_time = self.pipeline_logger.end_pipeline_timer()
            self.logger.info(f"Pipeline completed successfully in {elapsed_time:.2f} seconds")
            
            # Log execution summary
            summary = self.pipeline_logger.log_execution_summary()
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Pipeline execution failed: {str(e)}")
            # End timer even on failure
            self.pipeline_logger.end_pipeline_timer()
            raise
    
    def shutdown(self) -> None:
        """
        Shutdown the pipeline and clean up resources
        """
        self.logger.info("Shutting down pipeline")
        
        if self.spark:
            self.spark.stop()


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="NLP ETL Pipeline")
    
    parser.add_argument("--config", 
                        type=str, 
                        required=True,
                        help="Path to pipeline configuration YAML file")
    
    parser.add_argument("--log-level", 
                        type=str, 
                        default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
                        help="Logging level")
    
    parser.add_argument("--log-dir", 
                        type=str, 
                        default="logs",
                        help="Directory to store logs")
    
    return parser.parse_args()


def main():
    """Main entry point for the pipeline"""
    # Parse command line arguments
    args = parse_args()
    
    try:
        # Create and run pipeline
        pipeline = NLPPipeline(
            config_path=args.config,
            log_level=args.log_level,
            log_dir=args.log_dir
        )
        
        # Run pipeline
        pipeline.run()
        
        # Shutdown
        pipeline.shutdown()
        
        # Exit with success
        sys.exit(0)
        
    except Exception as e:
        logging.error(f"Pipeline execution failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main() 