#!/usr/bin/env python
"""
Command-line script to run the NLP ETL pipeline with a specified configuration file.
"""

import os
import sys
import argparse
import logging
from datetime import datetime

# Add the project root to sys.path if needed
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from src.pipeline import NLPPipeline

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(f"logs/pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    ]
)
logger = logging.getLogger(__name__)


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Run the NLP ETL Pipeline")
    
    parser.add_argument(
        "--config", "-c",
        required=True,
        help="Path to the YAML configuration file"
    )
    
    parser.add_argument(
        "--step", "-s",
        choices=["extract", "preprocess", "chunk", "embed", "load", "all"],
        default="all",
        help="Specific pipeline step to run (default: all)"
    )
    
    parser.add_argument(
        "--checkpoint", "-p",
        action="store_true",
        help="Use checkpoints if available"
    )
    
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )
    
    return parser.parse_args()


def main():
    """Main entry point for the pipeline script."""
    # Parse arguments
    args = parse_args()
    
    # Set verbose logging if requested
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # Create and run the pipeline
        logger.info(f"Initializing pipeline with config: {args.config}")
        pipeline = NLPPipeline(config_path=args.config)
        
        # Run specific step or full pipeline
        if args.step == "extract":
            pipeline.extract_data(use_checkpoint=args.checkpoint)
        elif args.step == "preprocess":
            pipeline.preprocess_data(use_checkpoint=args.checkpoint)
        elif args.step == "chunk":
            pipeline.chunk_data(use_checkpoint=args.checkpoint)
        elif args.step == "embed":
            pipeline.generate_embeddings(use_checkpoint=args.checkpoint)
        elif args.step == "load":
            pipeline.load_to_target(use_checkpoint=args.checkpoint)
        else:  # "all"
            pipeline.run(use_checkpoints=args.checkpoint)
        
        logger.info("Pipeline execution completed successfully")
        return 0
    
    except Exception as e:
        logger.exception(f"Pipeline execution failed: {str(e)}")
        return 1


if __name__ == "__main__":
    # Ensure the logs directory exists
    os.makedirs("logs", exist_ok=True)
    
    # Run the main function and exit with its return code
    sys.exit(main()) 