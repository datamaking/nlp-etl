"""
Unit tests for vector target components.
"""

import unittest
from unittest.mock import patch, MagicMock, call
import importlib

import pytest
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import (
    ChromaDBTarget,
    PostgresVectorTarget,
    Neo4jTarget
)
from src.exception import TargetException


class TestVectorTarget(unittest.TestCase):
    """Base test class for vector targets."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-vector-target") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        cls.spark.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for vector storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("chunk_id", StringType(), False),
            StructField("text", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("doc_id", StringType(), False),
            StructField("metadata", StringType(), True),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "id": "doc1", 
                "chunk_id": "doc1-chunk1",
                "text": "This is a test document.", 
                "chunk_text": "This is a test chunk.",
                "doc_id": "doc1",
                "metadata": "sample metadata 1", 
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5] * 10  # 50-dimensional
            },
            {
                "id": "doc2", 
                "chunk_id": "doc2-chunk1",
                "text": "Another test document for testing.", 
                "chunk_text": "Another test chunk for vector storage.",
                "doc_id": "doc2", 
                "metadata": "sample metadata 2", 
                "embedding": [0.2, 0.3, 0.4, 0.5, 0.6] * 10
            },
            {
                "id": "doc3", 
                "chunk_id": "doc3-chunk1",
                "text": "A third document to store.", 
                "chunk_text": "A third chunk to store.",
                "doc_id": "doc3",
                "metadata": None, 
                "embedding": [0.3, 0.4, 0.5, 0.6, 0.7] * 10
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df


class TestChromaDBTarget(TestVectorTarget):
    """Test the ChromaDBTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "collection_name": "test_collection",
                "persist_directory": "/tmp/chromadb",
                "chroma_db_impl": "duckdb+parquet",
                "batch_size": 10,
                "metadata_fields": ["id", "doc_id"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Patch ChromaDB import
        self.importlib_patcher = patch('src.target.vector_targets.importlib.util.find_spec')
        self.mock_find_spec = self.importlib_patcher.start()
        self.mock_find_spec.return_value = True
        
        # Patch ChromaDB client
        self.chromadb_patcher = patch('src.target.vector_targets.chromadb')
        self.mock_chromadb = self.chromadb_patcher.start()
        
        # Setup mock client and collection
        self.mock_client = MagicMock()
        self.mock_collection = MagicMock()
        self.mock_chromadb.Client.return_value = self.mock_client
        self.mock_client.get_or_create_collection.return_value = self.mock_collection
        
        self.target = ChromaDBTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.importlib_patcher.stop()
        self.chromadb_patcher.stop()
    
    def test_validate_config_valid(self):
        """Test that valid configuration passes validation."""
        self.target._validate_target_config()
    
    def test_validate_config_missing_chromadb(self):
        """Test validation when ChromaDB is not installed."""
        # Mock find_spec to return None (module not found)
        self.mock_find_spec.return_value = None
        
        with self.assertRaises(TargetException) as context:
            self.target._validate_target_config()
        
        self.assertIn("ChromaDB is required", str(context.exception))
    
    def test_validate_config_missing_collection_name(self):
        """Test validation with missing collection name."""
        # Create config with missing collection name
        invalid_config = {
            "parameters": {
                "persist_directory": "/tmp/chromadb",
                "batch_size": 10
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Initialize target with invalid config
        with self.assertRaises(TargetException) as context:
            target = ChromaDBTarget(invalid_config)
            target._validate_target_config()
        
        self.assertIn("Collection name must be specified", str(context.exception))
    
    def test_initialize_client(self):
        """Test client initialization."""
        self.target._initialize_client()
        
        # Verify ChromaDB client was created with settings
        self.mock_chromadb.Client.assert_called_once()
        
        # Verify collection was created
        self.mock_client.get_or_create_collection.assert_called_once_with(
            name="test_collection",
            metadata={"description": "Collection created by NLP Pipeline"}
        )
    
    @patch('src.target.vector_targets.udf')
    def test_write_data(self, mock_udf):
        """Test the write_data method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF and foreach method
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Call the write_data method
        self.target.write_data(df)
        
        # Verify the UDF was created
        mock_udf.assert_called_once()
        
        # Verify that add method was called with the mocked collection
        self.mock_client.get_or_create_collection.assert_called_once()
    
    def test_write_data_missing_columns(self):
        """Test the write_data method with missing columns."""
        # Create a dataframe missing required columns
        df = self.spark.createDataFrame([{"id": "1", "text": "test"}])
        
        # Call should raise exception
        with self.assertRaises(TargetException):
            self.target.write_data(df)
    
    def test_close(self):
        """Test the close method."""
        # Call the close method
        self.target.close()
        
        # There's no specific action for closing ChromaDB, but the method should exist


class TestPostgresVectorTarget(TestVectorTarget):
    """Test the PostgresVectorTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "vectordb",
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
                "table": "embeddings",
                "batch_size": 100,
                "vector_dimensions": 384,
                "create_index": True,
                "index_type": "hnsw",
                "metadata_fields": ["id", "doc_id"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Patch psycopg2 import
        self.importlib_patcher = patch('src.target.vector_targets.importlib.util.find_spec')
        self.mock_find_spec = self.importlib_patcher.start()
        self.mock_find_spec.return_value = True
        
        # Patch psycopg2
        self.psycopg2_patcher = patch('src.target.vector_targets.psycopg2')
        self.mock_psycopg2 = self.psycopg2_patcher.start()
        
        # Setup mock connection and cursor
        self.mock_conn = MagicMock()
        self.mock_cursor = MagicMock()
        self.mock_psycopg2.connect.return_value = self.mock_conn
        self.mock_conn.cursor.return_value = self.mock_cursor
        
        self.target = PostgresVectorTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.importlib_patcher.stop()
        self.psycopg2_patcher.stop()
    
    def test_validate_config_valid(self):
        """Test that valid configuration passes validation."""
        self.target._validate_target_config()
    
    def test_validate_config_missing_psycopg2(self):
        """Test validation when psycopg2 is not installed."""
        # Mock find_spec to return None (module not found)
        self.mock_find_spec.return_value = None
        
        with self.assertRaises(TargetException) as context:
            self.target._validate_target_config()
        
        self.assertIn("psycopg2 is required", str(context.exception))
    
    def test_validate_config_missing_database(self):
        """Test validation with missing database."""
        # Create config with missing database
        invalid_config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
                "table": "embeddings"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Initialize target with invalid config
        with self.assertRaises(TargetException) as context:
            target = PostgresVectorTarget(invalid_config)
            target._validate_target_config()
        
        self.assertIn("Database name must be specified", str(context.exception))
    
    def test_create_vector_index(self):
        """Test creating vector index."""
        self.target._create_vector_index()
        
        # Verify connection was created
        self.mock_psycopg2.connect.assert_called_once_with(
            host="localhost",
            port=5432,
            dbname="vectordb",
            user="postgres",
            password="postgres"
        )
        
        # Verify cursor execution
        self.mock_cursor.execute.assert_called_once()
        args, _ = self.mock_cursor.execute.call_args
        
        # Check that index creation query contains expected components
        self.assertIn("DROP INDEX IF EXISTS", args[0])
        self.assertIn("CREATE INDEX", args[0])
        
        # Verify commit was called
        self.mock_conn.commit.assert_called_once()
        
        # Verify connection was closed
        self.mock_conn.close.assert_called_once()
    
    @patch('pyspark.sql.DataFrame.withColumn')
    @patch('pyspark.sql.DataFrame.write')
    def test_write_data(self, mock_write, mock_withColumn):
        """Test writing data to PostgreSQL."""
        df = self.create_test_dataframe()
        
        # Setup mock chain for write operations
        mock_writer = MagicMock()
        mock_write.return_value = mock_writer
        
        # Setup mock chain for withColumn
        mock_df_with_vector = MagicMock()
        mock_withColumn.return_value = mock_df_with_vector
        mock_df_with_vector.drop.return_value = mock_df_with_vector
        mock_df_with_vector.withColumnRenamed.return_value = mock_df_with_vector
        mock_df_with_vector.select.return_value = mock_df_with_vector
        
        # Call write_data
        self.target.write_data(df)
        
        # Verify write was called
        mock_write.assert_called_once()
        mock_writer.format.assert_called_once_with("jdbc")


class TestNeo4jTarget(TestVectorTarget):
    """Test the Neo4jTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "uri": "bolt://localhost:7687",
                "user": "neo4j",
                "password": "password",
                "database": "neo4j",
                "node_label": "Document",
                "chunk_node_label": "Chunk",
                "relationship_type": "HAS_CHUNK",
                "batch_size": 10,
                "create_indices": True,
                "create_constraints": True,
                "metadata_fields": ["id", "doc_id"],
                "vector_dimension": 384,
                "vector_property": "embedding",
                "index_name": "chunk_embedding_index",
                "similarity_metric": "cosine"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Patch Neo4j import
        self.importlib_patcher = patch('src.target.vector_targets.importlib.util.find_spec')
        self.mock_find_spec = self.importlib_patcher.start()
        self.mock_find_spec.return_value = True
        
        # Patch Neo4j driver
        self.neo4j_patcher = patch('src.target.vector_targets.neo4j')
        self.mock_neo4j = self.neo4j_patcher.start()
        
        # Setup mock driver and session
        self.mock_driver = MagicMock()
        self.mock_session = MagicMock()
        self.mock_neo4j.GraphDatabase.driver.return_value = self.mock_driver
        self.mock_driver.session.return_value = self.mock_session
        
        self.target = Neo4jTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.importlib_patcher.stop()
        self.neo4j_patcher.stop()
    
    def test_validate_config_valid(self):
        """Test that valid configuration passes validation."""
        self.target._validate_target_config()
    
    def test_validate_config_missing_neo4j(self):
        """Test validation when Neo4j driver is not installed."""
        # Mock find_spec to return None (module not found)
        self.mock_find_spec.return_value = None
        
        with self.assertRaises(TargetException) as context:
            self.target._validate_target_config()
        
        self.assertIn("Neo4j Python driver is required", str(context.exception))
    
    def test_validate_config_missing_password(self):
        """Test validation with missing password."""
        # Create config with missing password
        invalid_config = {
            "parameters": {
                "uri": "bolt://localhost:7687",
                "user": "neo4j",
                "database": "neo4j"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Initialize target with invalid config
        with self.assertRaises(TargetException) as context:
            target = Neo4jTarget(invalid_config)
            target._validate_target_config()
        
        self.assertIn("Password must be specified", str(context.exception))
    
    def test_initialize_driver(self):
        """Test driver initialization."""
        self.target._initialize_driver()
        
        # Verify Neo4j driver was created
        self.mock_neo4j.GraphDatabase.driver.assert_called_once_with(
            "bolt://localhost:7687",
            auth=("neo4j", "password")
        )
        
        # Verify session was created for testing connection
        self.mock_driver.session.assert_called_with(database="neo4j")
        
        # Verify test query was run
        self.mock_session.run.assert_called_with("RETURN 1 AS test")
    
    def test_create_indices(self):
        """Test creating indices in Neo4j."""
        self.target._driver = self.mock_driver
        
        # Setup mock results for index check
        mock_record = MagicMock()
        mock_record.__getitem__.side_effect = lambda x: "vector" if x == "provider" else None
        self.mock_session.run.return_value = [mock_record]
        
        # Call method
        self.target._create_indices()
        
        # Verify constraint creation query was executed
        constraint_call = any(
            "CREATE CONSTRAINT" in str(call) for call in self.mock_session.run.call_args_list
        )
        self.assertTrue(constraint_call, "Constraint creation query not found")
    
    def test_close(self):
        """Test the close method."""
        self.target._driver = self.mock_driver
        
        # Call close
        self.target.close()
        
        # Verify driver.close was called
        self.mock_driver.close.assert_called_once()
        
        # Verify driver is cleared
        self.assertIsNone(self.target._driver)


if __name__ == "__main__":
    unittest.main() 