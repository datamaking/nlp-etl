"""
Main pipeline module for the NLP processing pipeline.
Coordinates data extraction, preprocessing, chunking, embedding, and loading into vector databases.
"""

import os
import time
from typing import Dict, Any, Optional, List, Union
from pyspark.sql import SparkSession, DataFrame

from .config import PipelineConfig
from .exception import (
    PipelineException, ConfigurationException, DataSourceException, 
    PreprocessingException, ChunkingException, EmbeddingException, TargetException
)
from .logging_module.logger import setup_logger, get_logger
from .data_source import create_source
from .preprocessing import create_preprocessor
from .chunking import create_chunker
from .embedding import create_embedder
from .target import create_target

# Get logger for this module
logger = get_logger(__name__)

class NLPPipeline:
    """
    Main pipeline class for end-to-end NLP processing.
    Manages the flow of data from source through processing steps to vector storage.
    """
    
    def __init__(self, config_path: str, use_checkpoints: bool = False, verbose: bool = False):
        """
        Initialize the NLP Pipeline with the given configuration.
        
        Args:
            config_path: Path to the YAML configuration file
            use_checkpoints: Whether to use intermediate checkpoints
            verbose: Whether to enable verbose logging
        """
        # Set up logging
        log_level = "DEBUG" if verbose else "INFO"
        setup_logger(log_level=log_level)
        
        # Start timing pipeline initialization
        start_time = time.time()
        logger.info(f"Initializing NLP Pipeline from config: {config_path}")
        
        # Load configuration
        self.config = PipelineConfig(config_path)
        self.use_checkpoints = use_checkpoints
        self.verbose = verbose
        
        # Initialize Spark session
        self.spark = self.config.build_spark_session()
        
        # Set pipeline components to None initially
        self.source = None
        self.preprocessor = None
        self.chunker = None
        self.embedder = None
        self.target = None
        
        # Initialize pipeline components based on configuration
        self._initialize_components()
        
        # Log initialization complete
        init_time = time.time() - start_time
        logger.info(f"Pipeline initialization completed in {init_time:.2f} seconds")
        
    def _initialize_components(self) -> None:
        """Initialize pipeline components based on configuration."""
        logger.info("Initializing pipeline components")
        
        # Initialize source
        source_config = self.config.get_source_config()
        if source_config:
            self.source = create_source(source_config, self.spark)
            logger.info(f"Data source initialized: {source_config.get('type')}")
        
        # Initialize preprocessor if configured
        preprocessing_config = self.config.get_preprocessing_config()
        if preprocessing_config:
            self.preprocessor = create_preprocessor(preprocessing_config)
            logger.info(f"Preprocessor initialized with operations: {preprocessing_config.get('operations', [])}")
        
        # Initialize chunker if configured
        chunking_config = self.config.get_chunking_config()
        if chunking_config:
            self.chunker = create_chunker(chunking_config)
            logger.info(f"Chunker initialized: {chunking_config.get('type')}")
        
        # Initialize embedder if configured
        embedding_config = self.config.get_embedding_config()
        if embedding_config:
            self.embedder = create_embedder(embedding_config)
            logger.info(f"Embedder initialized: {embedding_config.get('type')} - {embedding_config.get('model')}")
        
        # Initialize target
        target_config = self.config.get_target_config()
        if target_config:
            self.target = create_target(target_config)
            logger.info(f"Target initialized: {target_config.get('type')}")
    
    def run(self, step: Optional[str] = None) -> None:
        """
        Run the pipeline, either completely or a specific step.
        
        Args:
            step: Specific pipeline step to run (extract, preprocess, chunk, embed, load, all)
                 If None, run all steps.
        """
        start_time = time.time()
        pipeline_name = self.config.get_pipeline_name()
        logger.info(f"Starting pipeline: {pipeline_name}")
        
        try:
            # Run specific step or all steps
            if step == "extract":
                self._extract()
            elif step == "preprocess":
                df = self._load_checkpoint("extraction")
                self._preprocess(df)
            elif step == "chunk":
                df = self._load_checkpoint("preprocessing")
                self._chunk(df)
            elif step == "embed":
                df = self._load_checkpoint("chunking")
                self._embed(df)
            elif step == "load":
                df = self._load_checkpoint("embedding")
                self._load(df)
            else:
                # Run all steps
                df = self._extract()
                if df is not None and self.preprocessor:
                    df = self._preprocess(df)
                if df is not None and self.chunker:
                    df = self._chunk(df)
                if df is not None and self.embedder:
                    df = self._embed(df)
                if df is not None and self.target:
                    self._load(df)
            
            # Log successful completion
            total_time = time.time() - start_time
            logger.info(f"Pipeline completed successfully in {total_time:.2f} seconds")
            
        except Exception as e:
            total_time = time.time() - start_time
            logger.error(f"Pipeline failed after {total_time:.2f} seconds: {str(e)}")
            if isinstance(e, PipelineException):
                raise e
            else:
                raise PipelineException(f"Unhandled error in pipeline: {str(e)}") from e
    
    def _extract(self) -> Optional[DataFrame]:
        """Extract data from the configured source."""
        if not self.source:
            logger.warning("No data source configured, skipping extraction step")
            return None
        
        try:
            logger.info("Starting data extraction")
            start_time = time.time()
            
            # Extract data
            df = self.source.read_data()
            
            # Save checkpoint if enabled
            if self.use_checkpoints:
                self._save_checkpoint(df, "extraction")
            
            # Log statistics
            extract_time = time.time() - start_time
            row_count = df.count()
            logger.info(f"Data extraction completed in {extract_time:.2f} seconds, {row_count} rows extracted")
            
            return df
        except Exception as e:
            logger.error(f"Data extraction failed: {str(e)}")
            if isinstance(e, DataSourceException):
                raise e
            else:
                raise DataSourceException(f"Error during data extraction: {str(e)}") from e
    
    def _preprocess(self, df: DataFrame) -> Optional[DataFrame]:
        """Apply preprocessing to the data."""
        if not self.preprocessor:
            logger.warning("No preprocessor configured, skipping preprocessing step")
            return df
        
        if df is None:
            logger.warning("No data to preprocess, skipping preprocessing step")
            return None
        
        try:
            logger.info("Starting text preprocessing")
            start_time = time.time()
            
            # Apply preprocessing
            processed_df = self.preprocessor.process(df)
            
            # Save checkpoint if enabled
            if self.use_checkpoints:
                self._save_checkpoint(processed_df, "preprocessing")
            
            # Log statistics
            preprocess_time = time.time() - start_time
            logger.info(f"Text preprocessing completed in {preprocess_time:.2f} seconds")
            
            return processed_df
        except Exception as e:
            logger.error(f"Text preprocessing failed: {str(e)}")
            if isinstance(e, PreprocessingException):
                raise e
            else:
                raise PreprocessingException(f"Error during text preprocessing: {str(e)}") from e
    
    def _chunk(self, df: DataFrame) -> Optional[DataFrame]:
        """Apply chunking to the data."""
        if not self.chunker:
            logger.warning("No chunker configured, skipping chunking step")
            return df
        
        if df is None:
            logger.warning("No data to chunk, skipping chunking step")
            return None
        
        try:
            logger.info("Starting text chunking")
            start_time = time.time()
            
            # Apply chunking
            chunked_df = self.chunker.process(df)
            
            # Save checkpoint if enabled
            if self.use_checkpoints:
                self._save_checkpoint(chunked_df, "chunking")
            
            # Log statistics
            chunk_time = time.time() - start_time
            chunk_count = chunked_df.count()
            logger.info(f"Text chunking completed in {chunk_time:.2f} seconds, generated {chunk_count} chunks")
            
            return chunked_df
        except Exception as e:
            logger.error(f"Text chunking failed: {str(e)}")
            if isinstance(e, ChunkingException):
                raise e
            else:
                raise ChunkingException(f"Error during text chunking: {str(e)}") from e
    
    def _embed(self, df: DataFrame) -> Optional[DataFrame]:
        """Generate embeddings for the data."""
        if not self.embedder:
            logger.warning("No embedder configured, skipping embedding step")
            return df
        
        if df is None:
            logger.warning("No data to embed, skipping embedding step")
            return None
        
        try:
            logger.info("Starting embedding generation")
            start_time = time.time()
            
            # Generate embeddings
            embedded_df = self.embedder.process(df)
            
            # Save checkpoint if enabled
            if self.use_checkpoints:
                self._save_checkpoint(embedded_df, "embedding")
            
            # Log statistics
            embed_time = time.time() - start_time
            logger.info(f"Embedding generation completed in {embed_time:.2f} seconds")
            
            return embedded_df
        except Exception as e:
            logger.error(f"Embedding generation failed: {str(e)}")
            if isinstance(e, EmbeddingException):
                raise e
            else:
                raise EmbeddingException(f"Error during embedding generation: {str(e)}") from e
    
    def _load(self, df: DataFrame) -> None:
        """Load data into the target."""
        if not self.target:
            logger.warning("No target configured, skipping loading step")
            return
        
        if df is None:
            logger.warning("No data to load, skipping loading step")
            return
        
        try:
            logger.info("Starting data loading to target")
            start_time = time.time()
            
            # Load data to target
            self.target.write_data(df)
            
            # Log statistics
            load_time = time.time() - start_time
            logger.info(f"Data loading completed in {load_time:.2f} seconds")
        except Exception as e:
            logger.error(f"Data loading failed: {str(e)}")
            if isinstance(e, TargetException):
                raise e
            else:
                raise TargetException(f"Error during data loading: {str(e)}") from e
    
    def _save_checkpoint(self, df: DataFrame, stage: str) -> None:
        """Save a checkpoint for the given stage."""
        checkpoint_path = self.config.create_checkpoint_path(stage)
        if not checkpoint_path:
            logger.warning(f"No checkpoint path configured for stage '{stage}', skipping checkpoint")
            return
        
        try:
            logger.info(f"Saving checkpoint for stage '{stage}' to {checkpoint_path}")
            df.write.mode("overwrite").parquet(checkpoint_path)
            logger.info(f"Checkpoint saved successfully for stage '{stage}'")
        except Exception as e:
            logger.error(f"Failed to save checkpoint for stage '{stage}': {str(e)}")
            # Don't raise exception, continue pipeline execution
    
    def _load_checkpoint(self, stage: str) -> Optional[DataFrame]:
        """Load a checkpoint for the given stage."""
        checkpoint_path = self.config.create_checkpoint_path(stage)
        if not checkpoint_path:
            logger.warning(f"No checkpoint path configured for stage '{stage}'")
            return None
        
        try:
            # Check if checkpoint exists
            if not os.path.exists(checkpoint_path):
                logger.warning(f"Checkpoint for stage '{stage}' not found at {checkpoint_path}")
                return None
            
            logger.info(f"Loading checkpoint for stage '{stage}' from {checkpoint_path}")
            df = self.spark.read.parquet(checkpoint_path)
            logger.info(f"Checkpoint loaded successfully for stage '{stage}'")
            return df
        except Exception as e:
            logger.error(f"Failed to load checkpoint for stage '{stage}': {str(e)}")
            return None
    
    def shutdown(self) -> None:
        """Shutdown the pipeline and free resources."""
        logger.info("Shutting down pipeline")
        
        # Close any open resources in components
        if hasattr(self.source, 'close') and callable(self.source.close):
            self.source.close()
        
        if hasattr(self.embedder, 'close') and callable(self.embedder.close):
            self.embedder.close()
        
        if hasattr(self.target, 'close') and callable(self.target.close):
            self.target.close()
        
        # Stop Spark session
        if self.spark:
            self.spark.stop()
            logger.info("Spark session stopped")
        
        logger.info("Pipeline shutdown complete") 