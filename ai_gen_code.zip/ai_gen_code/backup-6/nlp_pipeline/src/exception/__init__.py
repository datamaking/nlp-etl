"""
Exception module for NLP Pipeline.
Provides custom exceptions for various pipeline stages.
"""

# Base exception class
class NLPPipelineException(Exception):
    """Base exception for NLP Pipeline."""
    pass

# Data source exceptions
class DataSourceException(NLPPipelineException):
    """Exception raised when there is an error with a data source."""
    pass

# Preprocessing exceptions
class PreprocessingException(NLPPipelineException):
    """Exception raised when there is an error in preprocessing."""
    pass

# Chunking exceptions
class ChunkingException(NLPPipelineException):
    """Exception raised when there is an error in text chunking."""
    pass

# Embedding exceptions
class EmbeddingException(NLPPipelineException):
    """Exception raised when there is an error in embedding generation."""
    pass

# Target exceptions
class TargetException(NLPPipelineException):
    """Exception raised when there is an error with a target."""
    pass

# Pipeline exceptions
class PipelineException(NLPPipelineException):
    """Exception raised when there is an error in the pipeline execution."""
    pass

# Configuration exceptions
class ConfigurationException(NLPPipelineException):
    """Exception raised when there is an error in configuration."""
    pass

__all__ = [
    'NLPPipelineException',
    'DataSourceException',
    'PreprocessingException',
    'ChunkingException',
    'EmbeddingException',
    'TargetException',
    'PipelineException',
    'ConfigurationException'
] 