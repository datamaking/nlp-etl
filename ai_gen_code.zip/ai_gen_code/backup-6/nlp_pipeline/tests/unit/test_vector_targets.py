"""
Unit tests for vector target components.
"""

import unittest
from unittest.mock import patch, MagicMock, call

import pytest
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import (
    ChromaDBTarget,
    PostgresVectorTarget,
    Neo4jTarget
)
from src.exception import TargetException


class TestVectorTarget(unittest.TestCase):
    """Base test class for vector targets."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-vector-target") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        cls.spark.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for vector storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("chunk_index", StringType(), False),
            StructField("id", StringType(), False),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "chunk_id": "1-0", 
                "chunk_text": "This is a test chunk.", 
                "chunk_index": "0", 
                "id": "1", 
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5] * 10  # 50-dimensional embedding
            },
            {
                "chunk_id": "2-0", 
                "chunk_text": "Another test chunk for vector storage.", 
                "chunk_index": "0", 
                "id": "2", 
                "embedding": [0.2, 0.3, 0.4, 0.5, 0.6] * 10
            },
            {
                "chunk_id": "3-0", 
                "chunk_text": "A third chunk to store.", 
                "chunk_index": "0", 
                "id": "3", 
                "embedding": [0.3, 0.4, 0.5, 0.6, 0.7] * 10
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df


class TestChromaDBTarget(TestVectorTarget):
    """Test the ChromaDBTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "collection_name": "test_collection",
                "persist_directory": "/tmp/chromadb",
                "batch_size": 10,
                "metadata_fields": ["id", "chunk_index"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Mock ChromaDB client
        self.patcher = patch('src.target.vector_targets.chromadb')
        self.mock_chromadb = self.patcher.start()
        
        # Setup mock client and collection
        self.mock_client = MagicMock()
        self.mock_collection = MagicMock()
        self.mock_chromadb.PersistentClient.return_value = self.mock_client
        self.mock_client.get_or_create_collection.return_value = self.mock_collection
        
        self.target = ChromaDBTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.patcher.stop()
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.target._validate_target_config()
        
        # Test missing collection name
        invalid_config = {
            "parameters": {
                "persist_directory": "/tmp/chromadb"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        with self.assertRaises(TargetException):
            ChromaDBTarget(invalid_config)
    
    def test_initialize_client(self):
        """Test client initialization."""
        self.target._initialize_client()
        
        # Check that the ChromaDB client was created
        self.mock_chromadb.PersistentClient.assert_called_once_with(path="/tmp/chromadb")
        
        # Check that the collection was created
        self.mock_client.get_or_create_collection.assert_called_once_with(
            name="test_collection",
            metadata={"hnsw:space": "cosine"}
        )
    
    @patch('src.target.vector_targets.udf')
    def test_write_data(self, mock_udf):
        """Test the write_data method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF and foreach method
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Call the write_data method
        self.target.write_data(df)
        
        # Verify the UDF was created
        mock_udf.assert_called_once()
        
        # Verify that add method was called with the mocked collection
        self.mock_client.get_or_create_collection.assert_called_once()
    
    def test_close(self):
        """Test the close method."""
        # Call the close method
        self.target.close()
        
        # There's no specific action for closing ChromaDB, but the method should exist


class TestPostgresVectorTarget(TestVectorTarget):
    """Test the PostgresVectorTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "vectordb",
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
                "document_table": "documents",
                "chunk_table": "chunks",
                "vector_dimension": 50,
                "vector_extension": "pgvector",
                "index_type": "hnsw",
                "batch_size": 10
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Mock psycopg2
        self.patcher = patch('src.target.vector_targets.psycopg2')
        self.mock_psycopg2 = self.patcher.start()
        
        # Setup mock connection and cursor
        self.mock_conn = MagicMock()
        self.mock_cursor = MagicMock()
        self.mock_psycopg2.connect.return_value = self.mock_conn
        self.mock_conn.cursor.return_value = self.mock_cursor
        
        self.target = PostgresVectorTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.patcher.stop()
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.target._validate_target_config()
        
        # Test missing database connection parameters
        invalid_config = {
            "parameters": {
                "host": "localhost",
                "port": 5432
                # Missing other required params
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        with self.assertRaises(TargetException):
            PostgresVectorTarget(invalid_config)
    
    def test_initialize_connection(self):
        """Test connection initialization."""
        self.target._initialize_connection()
        
        # Check that the PostgreSQL connection was created
        self.mock_psycopg2.connect.assert_called_once_with(
            host="localhost",
            port=5432,
            database="vectordb",
            user="postgres",
            password="postgres"
        )
    
    def test_create_tables(self):
        """Test table creation."""
        # Call the create_tables method
        self.target._create_tables()
        
        # Check that execute was called multiple times to create the tables
        self.assertTrue(self.mock_cursor.execute.call_count >= 3)  # At least 3 calls for creating tables and extension
    
    @patch('src.target.vector_targets.udf')
    def test_write_data(self, mock_udf):
        """Test the write_data method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF and foreach method
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Call the write_data method
        self.target.write_data(df)
        
        # Verify the UDF was created
        mock_udf.assert_called_once()
    
    def test_close(self):
        """Test the close method."""
        # Call the close method
        self.target.close()
        
        # Verify that the connection was closed
        self.mock_conn.close.assert_called_once()


class TestNeo4jTarget(TestVectorTarget):
    """Test the Neo4jTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "uri": "neo4j://localhost:7687",
                "user": "neo4j",
                "password": "password",
                "database": "neo4j",
                "node_label": "Chunk",
                "document_label": "Document",
                "relationship_type": "PART_OF",
                "batch_size": 10,
                "vector_dimension": 50
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Mock Neo4j driver
        self.patcher_driver = patch('src.target.vector_targets.GraphDatabase')
        self.mock_driver = self.patcher_driver.start()
        
        # Mock Neo4j
        self.patcher_neo4j = patch('src.target.vector_targets.neo4j')
        self.mock_neo4j = self.patcher_neo4j.start()
        
        # Setup mock driver and session
        self.mock_driver_instance = MagicMock()
        self.mock_session = MagicMock()
        self.mock_driver.driver.return_value = self.mock_driver_instance
        self.mock_driver_instance.session.return_value = self.mock_session
        
        self.target = Neo4jTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.patcher_driver.stop()
        self.patcher_neo4j.stop()
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.target._validate_target_config()
        
        # Test missing connection parameters
        invalid_config = {
            "parameters": {
                "uri": "neo4j://localhost:7687"
                # Missing other required params
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        with self.assertRaises(TargetException):
            Neo4jTarget(invalid_config)
    
    def test_initialize_driver(self):
        """Test driver initialization."""
        self.target._initialize_driver()
        
        # Check that the Neo4j driver was created
        self.mock_driver.driver.assert_called_once_with(
            "neo4j://localhost:7687",
            auth=("neo4j", "password")
        )
    
    def test_create_indices(self):
        """Test index creation."""
        # Call the create_indices method
        self.target._create_indices()
        
        # Check that the session run method was called for creating indices
        self.assertTrue(self.mock_session.run.call_count >= 2)  # At least 2 calls for creating indices
    
    @patch('src.target.vector_targets.udf')
    def test_write_data(self, mock_udf):
        """Test the write_data method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF and foreach method
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Call the write_data method
        self.target.write_data(df)
        
        # Verify the UDF was created
        mock_udf.assert_called_once()
    
    def test_close(self):
        """Test the close method."""
        # Call the close method
        self.target.close()
        
        # Verify that the driver was closed
        self.mock_driver_instance.close.assert_called_once()


if __name__ == "__main__":
    unittest.main() 