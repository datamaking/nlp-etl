# NLP Pipeline

A flexible end-to-end NLP data processing pipeline built on Apache Spark for efficient document processing, text embedding, and vector database integration.

## Features

- Modular document processing pipeline
- Support for various document formats (CSV, JSON, JSONL, PDF, etc.)
- Configurable text preprocessing options
- Document chunking with various strategies
- Integration with multiple embedding models
- Support for vector databases including ChromaDB, PostgreSQL with pgvector, and Neo4j

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/nlp_pipeline.git
cd nlp_pipeline

# Install dependencies
pip install -r requirements.txt
```

## Usage

The pipeline is configured through YAML files and can be run using the command-line script:

```bash
python src/run_pipeline.py --config examples/pipeline_config.yaml
```

### Command-line Options

- `--config, -c`: Path to YAML configuration file (required)
- `--step, -s`: Specific pipeline step to run (options: extract, preprocess, chunk, embed, load, all)
- `--checkpoint, -p`: Use checkpoints if available
- `--verbose, -v`: Enable verbose logging

### Example Configuration

See `examples/pipeline_config.yaml` for a complete configuration example. The file includes detailed settings for:

- Pipeline name and description
- Spark configuration (memory, partitions, etc.)
- Intermediate storage for checkpoints
- Data source configuration (CSV, JSON, etc.)
- Text preprocessing operations
- Document chunking strategies
- Embedding model settings
- Vector database target configuration

You can use this file as a template for your own pipelines.

## Configuration Structure

```yaml
# Pipeline name
name: "Document Processing Pipeline"

# Spark configuration
spark:
  app_name: "NLP Pipeline"
  master: "local[*]"
  executor_memory: "4g"
  driver_memory: "8g"

# Intermediate storage for checkpoints
intermediate:
  extraction_checkpoint: "data/checkpoints/extraction"
  preprocessing_checkpoint: "data/checkpoints/preprocessing"
  chunking_checkpoint: "data/checkpoints/chunking"
  embedding_checkpoint: "data/checkpoints/embedding"

# Data source configuration
source:
  type: "csv"  # csv, json, jsonl, pdf, etc.
  parameters:
    path: "data/documents/*.csv"
    format: "csv"
    header: true
    delimiter: ","
    inferSchema: true
  text_column: "content"
  id_column: "doc_id"
  metadata_columns:
    - "title"
    - "author"
    - "publish_date"
    - "source"

# Preprocessing configuration
preprocessing:
  operations:
    - "clean_text"
    - "remove_html_tags"
    - "normalize_unicode"
    - "remove_extra_whitespace"
    - "remove_special_characters"
  parameters:
    lowercase: true
    remove_punctuation: true
    remove_stopwords: true
    language: "english"

# Chunking configuration  
chunking:
  type: "recursive"  # recursive, sentence, paragraph, fixed
  parameters:
    chunk_size: 512
    chunk_overlap: 50
    min_chunk_size: 100
    separators: ["\n\n", "\n", ". ", " ", ""]

# Embedding configuration
embedding:
  type: "huggingface"  # huggingface, openai, cohere, etc.
  model: "sentence-transformers/all-MiniLM-L6-v2"
  parameters:
    batch_size: 32
    max_tokens: 512
    normalize: true

# Target configuration
target:
  type: "chromadb"  # chromadb, postgres, neo4j
  parameters:
    collection_name: "documents"
    persist_directory: "data/chromadb"
    metadata_fields:
      - "title"
      - "author"
      - "publish_date"
      - "source"
    text_column: "chunk"
    embedding_column: "embedding"
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details. 