# Vector Targets for NLP Pipeline

This module provides implementations for storing vector embeddings in various databases with vector search capabilities.

## Overview

The vector targets module supports the following databases:

1. **ChromaDB** - An open-source embedding database optimized for similarity search
2. **PostgreSQL with pgvector** - Adds vector similarity search to PostgreSQL
3. **Neo4j with vector index** - Graph database with vector search capabilities

Each implementation follows a common interface defined by the `Target` base class, making it easy to switch between different vector stores.

## Requirements

Each vector target has specific requirements:

### ChromaDB

```
pip install chromadb
```

### PostgreSQL with pgvector

```
pip install psycopg2-binary
```

You also need a PostgreSQL server with the pgvector extension installed.

### Neo4j

```
pip install neo4j
```

You need a Neo4j server (version 5.11+ for vector index support).

## Configuration Examples

### ChromaDB

```yaml
target:
  type: chroma_db
  parameters:
    collection_name: my_documents
    persist_directory: /path/to/chromadb
    chroma_db_impl: duckdb+parquet
    batch_size: 100
    metadata_fields:
      - doc_id
      - filename
  embedding_column: embedding
  text_column: chunk_text
  id_column: chunk_id
```

### PostgreSQL with pgvector

```yaml
target:
  type: postgres_vector
  parameters:
    host: localhost
    port: 5432
    database: vectordb
    schema: public
    table: embeddings
    user: postgres
    password: secretpassword
    batch_size: 100
    vector_dimensions: 384
    create_index: true
    index_type: hnsw
    enable_extension: true
    overwrite: false
    metadata_fields:
      - doc_id
      - filename
  embedding_column: embedding
  text_column: chunk_text
  id_column: chunk_id
```

### Neo4j

```yaml
target:
  type: neo4j
  parameters:
    uri: bolt://localhost:7687
    user: neo4j
    password: secretpassword
    database: neo4j
    node_label: Document
    chunk_node_label: Chunk
    relationship_type: HAS_CHUNK
    batch_size: 100
    create_indices: true
    create_constraints: true
    vector_dimension: 384
    vector_property: embedding
    index_name: vector_index
    similarity_metric: cosine
    document_mapping:
      id: id
      title: filename
      text: content
      filepath: path
    chunk_mapping:
      id: chunk_id
      text: chunk_text
    metadata_fields:
      - doc_id
      - filename
  embedding_column: embedding
  text_column: chunk_text
  id_column: id
```

## Usage in Code

Here's an example of how to use a vector target in Python code:

```python
from pyspark.sql import SparkSession
from src.target.vector_targets import ChromaDBTarget

# Initialize Spark
spark = SparkSession.builder \
    .appName("vector-example") \
    .getOrCreate()

# Load data
df = spark.read.parquet("path/to/embeddings.parquet")

# Configure target
config = {
    "parameters": {
        "collection_name": "documents",
        "persist_directory": "./chroma_db",
        "batch_size": 100,
        "metadata_fields": ["doc_id", "filename"]
    },
    "embedding_column": "embedding",
    "text_column": "chunk_text",
    "id_column": "chunk_id"
}

# Create and use target
target = ChromaDBTarget(config)
try:
    target.write_data(df)
finally:
    target.close()
```

## Query Examples

### ChromaDB

```python
import chromadb

client = chromadb.Client(chromadb.config.Settings(
    persist_directory="./chroma_db"
))

collection = client.get_collection("documents")

# Query by vector similarity
results = collection.query(
    query_embeddings=[[0.1, 0.2, 0.3, ...]],
    n_results=5
)

print(results["documents"])  # List of matching documents
print(results["distances"])  # Similarity scores
```

### PostgreSQL

```sql
-- Create an embedding vector
WITH query_embedding AS (
  SELECT '[0.1, 0.2, 0.3, ...]'::vector(384) AS embedding
)

-- Find the 5 most similar documents using cosine distance
SELECT chunk_id, chunk_text, 1 - (embedding <=> query_embedding.embedding) AS similarity
FROM embeddings, query_embedding
ORDER BY embedding <=> query_embedding.embedding
LIMIT 5;
```

### Neo4j

```cypher
// Find the 5 most similar documents using vector similarity
MATCH (c:Chunk)
WITH c, gds.similarity.cosine(c.embedding, $embedding) AS similarity
WHERE similarity > 0.7
RETURN c.id, c.text, similarity
ORDER BY similarity DESC
LIMIT 5;
```

## Running Tests

### Unit Tests

```
python -m pytest tests/unit/test_vector_targets.py -v
```

### Integration Tests

```
INTEGRATION_TESTS=1 python -m pytest tests/integration/test_vector_targets_integration.py -v
```

Note: Integration tests require actual database connections. 