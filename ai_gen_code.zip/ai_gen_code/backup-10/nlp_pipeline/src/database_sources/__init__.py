"""
Database sources module for NLP Pipeline.
Provides classes for reading data from various database sources.
"""

from typing import Dict, Any

from ..data_source.data_source_base import DataSource

class SQLSource(DataSource):
    """
    Data source for SQL databases.
    
    Supports reading data from any JDBC-compatible database.
    """
    
    def _validate_source_config(self) -> None:
        """Validate SQL source configuration."""
        if "jdbc_url" not in self.parameters:
            raise ValueError("JDBC URL must be specified for SQL source")
        
        if "query" not in self.parameters and "table" not in self.parameters:
            raise ValueError("Either query or table must be specified for SQL source")
    
    def read_data(self):
        """Read data from SQL database."""
        jdbc_url = self.parameters["jdbc_url"]
        jdbc_driver = self.parameters.get("driver", "org.postgresql.Driver")
        user = self.parameters.get("user")
        password = self.parameters.get("password")
        
        # Create JDBC options
        jdbc_options = {
            "driver": jdbc_driver
        }
        
        # Add credentials if provided
        if user:
            jdbc_options["user"] = user
        if password:
            jdbc_options["password"] = password
        
        # Add any additional options
        for key, value in self.parameters.items():
            if key not in ["jdbc_url", "driver", "user", "password", "query", "table"]:
                jdbc_options[key] = value
        
        # Read from database using query or table
        if "query" in self.parameters:
            query = self.parameters["query"]
            df = self.spark.read.format("jdbc") \
                .options(**jdbc_options) \
                .option("url", jdbc_url) \
                .option("query", query) \
                .load()
        else:
            table = self.parameters["table"]
            df = self.spark.read.format("jdbc") \
                .options(**jdbc_options) \
                .option("url", jdbc_url) \
                .option("dbtable", table) \
                .load()
        
        return df


class MongoSource(DataSource):
    """
    Data source for MongoDB.
    
    Requires the MongoDB Spark Connector.
    """
    
    def _validate_source_config(self) -> None:
        """Validate MongoDB source configuration."""
        if "uri" not in self.parameters:
            raise ValueError("MongoDB URI must be specified")
        
        if "database" not in self.parameters:
            raise ValueError("MongoDB database must be specified")
        
        if "collection" not in self.parameters:
            raise ValueError("MongoDB collection must be specified")
    
    def read_data(self):
        """Read data from MongoDB."""
        # Get MongoDB parameters
        uri = self.parameters["uri"]
        database = self.parameters["database"]
        collection = self.parameters["collection"]
        
        # Create options for MongoDB connector
        options = {
            "uri": uri,
            "database": database,
            "collection": collection
        }
        
        # Add any additional options
        for key, value in self.parameters.items():
            if key not in ["uri", "database", "collection"]:
                options[key] = value
        
        # Read from MongoDB
        df = self.spark.read.format("mongo") \
            .options(**options) \
            .load()
        
        return df

__all__ = [
    'SQLSource',
    'MongoSource'
] 