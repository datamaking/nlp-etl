"""
NLP Pipeline - A flexible document processing pipeline with vector database integration.
"""

__version__ = "0.1.0"
__author__ = "NLP Pipeline Team" 