"""
Configuration classes for the NLP ETL Pipeline
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Union, Any
import os
import yaml
import json
import logging
from pyspark.sql import SparkSession
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables
load_dotenv()

class Department(Enum):
    """Enum for departments"""
    ADMIN = "ADMIN"
    HR = "HR"
    FINANCE = "FINANCE"
    IT_HELPDESK = "IT_HELPDESK"


class SourceType(Enum):
    """Enum for data source types"""
    HIVE = "HIVE"
    HDFS = "HDFS"
    LOCAL_FILE = "LOCAL_FILE"
    RDBMS = "RDBMS"


class FileFormat(Enum):
    """Enum for file formats"""
    TEXT = "TEXT"
    HTML = "HTML"
    JSON = "JSON"
    CSV = "CSV"


class TargetType(Enum):
    """Enum for data target types"""
    HIVE = "HIVE"
    HDFS = "HDFS"
    LOCAL_FILE = "LOCAL_FILE"
    RDBMS = "RDBMS"
    CHROMADB = "CHROMADB"
    POSTGRES_VECTOR = "POSTGRES_VECTOR"
    NEO4J = "NEO4J"


class LoadType(Enum):
    """Enum for data load types"""
    FULL = "FULL"
    INCREMENTAL_SCD2 = "INCREMENTAL_SCD2"
    INCREMENTAL_CDC = "INCREMENTAL_CDC"


class PreprocessingType(Enum):
    """Enum for preprocessing types"""
    HTML_PARSING = "HTML_PARSING"
    DATA_CLEANING = "DATA_CLEANING"
    STOPWORD_REMOVAL = "STOPWORD_REMOVAL"
    STEMMING = "STEMMING"
    LEMMATIZATION = "LEMMATIZATION"


class ChunkingStrategy(Enum):
    """Enum for chunking strategies"""
    FIXED_SIZE = "FIXED_SIZE"
    SENTENCE = "SENTENCE"
    PARAGRAPH = "PARAGRAPH"
    RECURSIVE = "RECURSIVE"
    SEMANTIC = "SEMANTIC"


class EmbeddingType(Enum):
    """Enum for embedding types"""
    TFIDF = "TFIDF"
    SENTENCE_ST5 = "SENTENCE_ST5"


@dataclass
class BaseConfig(ABC):
    """Abstract base configuration class"""
    name: str
    department: Department
    
    @abstractmethod
    def validate(self) -> bool:
        """Validate configuration"""
        pass
    
    def to_dict(self) -> Dict:
        """Convert config to dictionary"""
        return {k: (v.value if isinstance(v, Enum) else v) 
                for k, v in self.__dict__.items()}


@dataclass
class SourceConfig(BaseConfig):
    """Configuration for data sources"""
    source_type: SourceType
    file_format: Optional[FileFormat] = None
    tables: List[str] = field(default_factory=list)
    queries: List[str] = field(default_factory=list)
    join_columns: Optional[Dict[str, str]] = None
    connection_params: Optional[Dict[str, str]] = None
    file_paths: List[str] = field(default_factory=list)
    text_column: Optional[str] = None
    
    def validate(self) -> bool:
        """Validate source configuration"""
        if self.source_type in [SourceType.HIVE, SourceType.RDBMS] and not (self.tables or self.queries):
            return False
        if self.source_type in [SourceType.HDFS, SourceType.LOCAL_FILE] and not self.file_paths:
            return False
        if self.source_type == SourceType.RDBMS and not self.connection_params:
            return False
        return True


@dataclass
class PreprocessingConfig(BaseConfig):
    """Configuration for preprocessing"""
    preprocessing_types: List[PreprocessingType]
    params: Dict[str, Any] = field(default_factory=dict)
    
    def validate(self) -> bool:
        """Validate preprocessing configuration"""
        if not self.preprocessing_types:
            return False
        return True


@dataclass
class ChunkingConfig(BaseConfig):
    """Configuration for chunking"""
    chunking_strategy: ChunkingStrategy
    chunk_size: int = 512
    chunk_overlap: int = 50
    enable_smoothing: bool = True
    
    def validate(self) -> bool:
        """Validate chunking configuration"""
        if self.chunk_size <= 0:
            return False
        if self.chunk_overlap >= self.chunk_size:
            return False
        return True


@dataclass
class EmbeddingConfig(BaseConfig):
    """Configuration for embedding generation"""
    embedding_type: EmbeddingType
    model_path: Optional[str] = None
    batch_size: int = 32
    max_sequence_length: int = 512
    
    def validate(self) -> bool:
        """Validate embedding configuration"""
        if self.embedding_type == EmbeddingType.SENTENCE_ST5 and not self.model_path:
            return False
        if self.batch_size <= 0:
            return False
        return True


@dataclass
class TargetConfig(BaseConfig):
    """Configuration for data targets"""
    target_type: TargetType
    load_type: LoadType
    file_format: Optional[FileFormat] = None
    table_name: Optional[str] = None
    file_path: Optional[str] = None
    connection_params: Optional[Dict[str, str]] = None
    partition_columns: List[str] = field(default_factory=list)
    
    def validate(self) -> bool:
        """Validate target configuration"""
        if self.target_type in [TargetType.HIVE, TargetType.RDBMS] and not self.table_name:
            return False
        if self.target_type in [TargetType.HDFS, TargetType.LOCAL_FILE] and not self.file_path:
            return False
        if self.target_type in [TargetType.RDBMS, TargetType.CHROMADB, 
                               TargetType.POSTGRES_VECTOR, TargetType.NEO4J] and not self.connection_params:
            return False
        return True


class PipelineConfig:
    """
    Configuration manager for the NLP Pipeline.
    
    Handles loading, validation, and access to pipeline configuration.
    """
    
    def __init__(self, config_path: str):
        """
        Initialize the pipeline configuration.
        
        Args:
            config_path: Path to the YAML configuration file
        """
        self.config_path = config_path
        
        # Load and validate configuration
        self.config = self._load_config()
        
        # Extract basic info
        self.pipeline_name = self.get_value("pipeline.name", "nlp-pipeline")
        self.pipeline_version = self.get_value("pipeline.version", "1.0.0")
        
        # Additional validation
        self._validate_pipeline_config()
        
        logger.info(f"Pipeline configuration initialized: {self.pipeline_name} v{self.pipeline_version}")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        Load configuration from the YAML file and apply any environment variables.
        
        Returns:
            Dict containing configuration settings
        """
        try:
            with open(self.config_path, 'r', encoding='utf-8') as file:
                config = yaml.safe_load(file)
                
            # Process environment variable placeholders in the config
            self._process_env_vars(config)
            
            return config
        except Exception as e:
            raise ValueError(f"Failed to load configuration from {self.config_path}: {e}")
    
    def _process_env_vars(self, config: Any) -> None:
        """
        Replace environment variable placeholders in the config with actual values.
        Processes the config in-place.
        
        Args:
            config: Configuration object to process
        """
        if isinstance(config, dict):
            for key, value in config.items():
                config[key] = self._process_env_vars(value)
        elif isinstance(config, list):
            for i, item in enumerate(config):
                config[i] = self._process_env_vars(item)
        elif isinstance(config, str) and config.startswith("${") and config.endswith("}"):
            env_var = config[2:-1]
            env_value = os.environ.get(env_var)
            if env_value is None:
                raise ValueError(f"Environment variable {env_var} not found")
            return env_value
        return config
    
    def _validate_pipeline_config(self):
        """Perform additional validation on the pipeline configuration."""
        # Check source configuration
        source_config = self.get_source_config()
        if not source_config:
            raise ConfigurationException("Source configuration not found")
        
        if "type" not in source_config:
            raise ConfigurationException("Source type must be specified")
        
        # Check target configuration
        target_config = self.get_target_config()
        if not target_config:
            raise ConfigurationException("Target configuration not found")
        
        if "type" not in target_config:
            raise ConfigurationException("Target type must be specified")
        
        # Check embedding configuration
        embedding_config = self.get_embedding_config()
        if embedding_config and "type" not in embedding_config:
            raise ConfigurationException("Embedding type must be specified if embedding is configured")
    
    def build_spark_session(self) -> SparkSession:
        """
        Build a SparkSession using the configuration.
        
        Returns:
            Configured SparkSession
        """
        spark_config = self.config.get("spark", {})
        
        # Extract Spark configuration values
        app_name = spark_config.get("app_name", "nlp-pipeline")
        master = spark_config.get("master", "local[*]")
        log_level = spark_config.get("log_level", "WARN")
        
        # Create Spark builder
        builder = SparkSession.builder \
            .appName(app_name) \
            .master(master)
        
        # Add additional configuration
        spark_additional_config = spark_config.get("config", {})
        for key, value in spark_additional_config.items():
            builder = builder.config(key, value)
        
        # Build the session
        spark = builder.getOrCreate()
        
        # Set log level
        spark.sparkContext.setLogLevel(log_level)
        
        logger.info(f"Created Spark session: {app_name} on {master}")
        return spark
    
    def get_pipeline_name(self) -> str:
        """
        Get the pipeline name.
        
        Returns:
            Pipeline name
        """
        return self.pipeline_name
    
    def get_pipeline_version(self) -> str:
        """
        Get the pipeline version.
        
        Returns:
            Pipeline version
        """
        return self.pipeline_version
    
    def get_source_config(self) -> Dict[str, Any]:
        """
        Get the data source configuration.
        
        Returns:
            Data source configuration dictionary
        """
        return self.config.get("source", {})
    
    def get_preprocessing_config(self) -> Dict[str, Any]:
        """
        Get the preprocessing configuration.
        
        Returns:
            Preprocessing configuration dictionary or empty dict if not configured
        """
        return self.config.get("preprocessing", {})
    
    def get_chunking_config(self) -> Dict[str, Any]:
        """
        Get the chunking configuration.
        
        Returns:
            Chunking configuration dictionary or empty dict if not configured
        """
        return self.config.get("chunking", {})
    
    def get_embedding_config(self) -> Dict[str, Any]:
        """
        Get the embedding configuration.
        
        Returns:
            Embedding configuration dictionary or empty dict if not configured
        """
        return self.config.get("embedding", {})
    
    def get_target_config(self) -> Dict[str, Any]:
        """
        Get the target configuration.
        
        Returns:
            Target configuration dictionary
        """
        return self.config.get("target", {})
    
    def get_intermediate_storage_config(self) -> Dict[str, Any]:
        """
        Get the intermediate storage configuration.
        
        Returns:
            Intermediate storage configuration dictionary or empty dict if not configured
        """
        storage_config = self.config.get("intermediate_storage", {})
        
        # Set default values if not specified
        if "enabled" not in storage_config:
            storage_config["enabled"] = True
        
        if "format" not in storage_config:
            storage_config["format"] = "parquet"
        
        if "path" not in storage_config:
            storage_config["path"] = "data/intermediate"
        
        if "mode" not in storage_config:
            storage_config["mode"] = "overwrite"
        
        return storage_config
    
    def get_checkpoint_path(self, stage: str) -> str:
        """
        Get the path for a specific checkpoint stage.
        
        Args:
            stage: Pipeline stage name ('extraction', 'preprocessing', 'chunking', 'embedding')
            
        Returns:
            Path to the checkpoint directory
        """
        base_path = self.get_intermediate_storage_config().get("path", "data/intermediate")
        return os.path.join(base_path, stage)
    
    def get_value(self, path: str, default: Any = None) -> Any:
        """
        Get a configuration value using a dot-separated path.
        
        Args:
            path: Dot-separated path to the value
            default: Default value if path doesn't exist
            
        Returns:
            Configuration value or default
        """
        return get_config_value(self.config, path, default)
    
    def get_full_config(self) -> Dict[str, Any]:
        """
        Get the full configuration dictionary.
        
        Returns:
            Complete configuration dictionary
        """
        return self.config


class ConfigurationFactory:
    """Factory class for creating configurations"""
    
    @staticmethod
    def create_source_config(
        name: str,
        department: Department,
        source_type: SourceType,
        **kwargs
    ) -> SourceConfig:
        """Create a source configuration"""
        return SourceConfig(
            name=name,
            department=department,
            source_type=source_type,
            **kwargs
        )
    
    @staticmethod
    def create_preprocessing_config(
        name: str,
        department: Department,
        preprocessing_types: List[PreprocessingType],
        **kwargs
    ) -> PreprocessingConfig:
        """Create a preprocessing configuration"""
        return PreprocessingConfig(
            name=name,
            department=department,
            preprocessing_types=preprocessing_types,
            **kwargs
        )
    
    @staticmethod
    def create_chunking_config(
        name: str,
        department: Department,
        chunking_strategy: ChunkingStrategy,
        **kwargs
    ) -> ChunkingConfig:
        """Create a chunking configuration"""
        return ChunkingConfig(
            name=name,
            department=department,
            chunking_strategy=chunking_strategy,
            **kwargs
        )
    
    @staticmethod
    def create_embedding_config(
        name: str,
        department: Department,
        embedding_type: EmbeddingType,
        **kwargs
    ) -> EmbeddingConfig:
        """Create an embedding configuration"""
        return EmbeddingConfig(
            name=name,
            department=department,
            embedding_type=embedding_type,
            **kwargs
        )
    
    @staticmethod
    def create_target_config(
        name: str,
        department: Department,
        target_type: TargetType,
        load_type: LoadType,
        **kwargs
    ) -> TargetConfig:
        """Create a target configuration"""
        return TargetConfig(
            name=name,
            department=department,
            target_type=target_type,
            load_type=load_type,
            **kwargs
        )
    
    @staticmethod
    def create_pipeline_config(
        pipeline_name: str,
        department: Department,
        **kwargs
    ) -> PipelineConfig:
        """Create a pipeline configuration"""
        return PipelineConfig(
            config_path=pipeline_name
        )

# Make PipelineConfig available at the package level
__all__ = ['PipelineConfig'] 