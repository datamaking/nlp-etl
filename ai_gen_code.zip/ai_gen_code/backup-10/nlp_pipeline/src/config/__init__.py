"""
Configuration module for NLP Pipeline.
Provides utilities for loading and validating configurations.
"""

import os
import yaml
from typing import Dict, Any, Optional

from ..exception import ConfigurationException
from ..logging_module import get_logger

logger = get_logger(__name__)

def load_config(config_path: str) -> Dict[str, Any]:
    """
    Load configuration from a YAML file.
    
    Args:
        config_path: Path to the configuration file
        
    Returns:
        Dictionary containing the configuration
        
    Raises:
        ConfigurationException: If the configuration file cannot be loaded
    """
    logger.info(f"Loading configuration from {config_path}")
    
    try:
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        # Validate the configuration
        validate_config(config)
        
        # Expand environment variables
        config = expand_env_vars(config)
        
        logger.info("Configuration loaded successfully")
        return config
    
    except yaml.YAMLError as e:
        raise ConfigurationException(f"Error parsing YAML configuration: {str(e)}") from e
    except FileNotFoundError:
        raise ConfigurationException(f"Configuration file not found: {config_path}")
    except Exception as e:
        raise ConfigurationException(f"Error loading configuration: {str(e)}") from e

def validate_config(config: Dict[str, Any]) -> None:
    """
    Validate configuration structure.
    
    Args:
        config: Configuration dictionary
        
    Raises:
        ConfigurationException: If the configuration is invalid
    """
    # Check required top-level sections
    required_sections = ["spark", "data_source", "target"]
    missing_sections = [section for section in required_sections if section not in config]
    
    if missing_sections:
        raise ConfigurationException(f"Missing required configuration sections: {', '.join(missing_sections)}")
    
    # Check Spark configuration
    if not isinstance(config["spark"], dict):
        raise ConfigurationException("Spark configuration must be a dictionary")
    
    if "app_name" not in config["spark"]:
        raise ConfigurationException("Spark application name must be specified")
    
    # Check data source configuration
    if not isinstance(config["data_source"], dict):
        raise ConfigurationException("Data source configuration must be a dictionary")
    
    if "type" not in config["data_source"]:
        raise ConfigurationException("Data source type must be specified")
    
    # Check target configuration
    if not isinstance(config["target"], dict):
        raise ConfigurationException("Target configuration must be a dictionary")
    
    if "type" not in config["target"]:
        raise ConfigurationException("Target type must be specified")

def expand_env_vars(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Expand environment variables in configuration values.
    
    Environment variables can be referenced using the ${VAR_NAME} syntax.
    
    Args:
        config: Configuration dictionary
        
    Returns:
        Configuration with environment variables expanded
    """
    if isinstance(config, dict):
        return {key: expand_env_vars(value) for key, value in config.items()}
    elif isinstance(config, list):
        return [expand_env_vars(item) for item in config]
    elif isinstance(config, str):
        # Expand environment variables in string
        if "${" in config and "}" in config:
            import re
            
            # Find all environment variable references
            env_vars = re.findall(r'\${([^}]+)}', config)
            
            # Replace each reference with its value
            result = config
            for var in env_vars:
                env_value = os.environ.get(var, "")
                result = result.replace(f"${{{var}}}", env_value)
            
            return result
        else:
            return config
    else:
        return config

def get_config_value(config: Dict[str, Any], path: str, default: Any = None) -> Any:
    """
    Get a value from the configuration using a dot-separated path.
    
    Args:
        config: Configuration dictionary
        path: Dot-separated path to the configuration value
        default: Default value to return if the path doesn't exist
        
    Returns:
        Configuration value or default
    """
    keys = path.split('.')
    value = config
    
    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return default
    
    return value

__all__ = [
    'load_config',
    'validate_config',
    'expand_env_vars',
    'get_config_value'
] 