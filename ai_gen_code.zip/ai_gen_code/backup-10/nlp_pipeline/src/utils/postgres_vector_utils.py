"""
Utility functions for working with PostgreSQL and vector operations.
"""

import json
import re
from typing import Dict, Any, List, Optional, Union, Tuple
import logging

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, udf, struct, to_json, array, expr, lit

from ..exception.exceptions import TargetException
from ..logging_module import get_logger

logger = get_logger(__name__)


def prepare_vector_sql_type(
    vector_extension: str, 
    dimension: int
) -> str:
    """
    Prepare the SQL type for vector storage based on the extension.
    
    Args:
        vector_extension: The PostgreSQL vector extension to use (pgvector, vector, pg_embedding)
        dimension: The dimension of the embedding vectors
        
    Returns:
        SQL type string for the vector column
    """
    vector_extension = vector_extension.lower()
    
    if vector_extension in ["pgvector", "vector"]:
        return f"vector({dimension})"
    elif vector_extension == "pg_embedding":
        return "real[]"
    else:
        logger.warning(f"Unknown vector extension {vector_extension}, defaulting to pgvector")
        return f"vector({dimension})"


def generate_vector_index_sql(
    schema: str,
    table: str,
    column: str,
    index_type: str,
    dimension: int
) -> str:
    """
    Generate SQL for creating a vector index.
    
    Args:
        schema: Database schema
        table: Table name
        column: Column name for the vector
        index_type: Type of index (hnsw, ivfflat, ivfpq, or null for no index)
        dimension: Vector dimension
        
    Returns:
        SQL for creating the appropriate vector index
    """
    index_name = f"idx_{table}_{column}_vector"
    
    # Default to no index if type is null or empty
    if not index_type:
        return ""
    
    index_type = index_type.lower()
    
    if index_type == "hnsw":
        return f"""
        CREATE INDEX IF NOT EXISTS {index_name}
        ON {schema}.{table}
        USING hnsw ({column} vector_l2_ops)
        WITH (m=16, ef_construction=64)
        """
    elif index_type == "ivfflat":
        # Recommended lists = sqrt(row_count)
        return f"""
        CREATE INDEX IF NOT EXISTS {index_name}
        ON {schema}.{table}
        USING ivfflat ({column} vector_l2_ops)
        WITH (lists=100)
        """
    elif index_type == "ivfpq":
        # Product quantization for very large vectors
        return f"""
        CREATE INDEX IF NOT EXISTS {index_name}
        ON {schema}.{table}
        USING ivfpq ({column} vector_l2_ops)
        WITH (lists=100, m=4, code_size=8)
        """
    else:
        # Default to regular index if unknown type
        return f"""
        CREATE INDEX IF NOT EXISTS {index_name}
        ON {schema}.{table}
        USING btree ({column})
        """


def generate_similarity_search_sql(
    schema: str,
    table: str,
    vector_column: str,
    return_columns: List[str],
    similarity_metric: str = "cosine",
    limit: int = 10,
    filter_condition: Optional[str] = None
) -> str:
    """
    Generate SQL for vector similarity search.

    Args:
        schema: Database schema
        table: Table name
        vector_column: Column name for the vector
        return_columns: Columns to return in the results
        similarity_metric: Similarity metric (cosine, l2, inner)
        limit: Maximum number of results to return
        filter_condition: Additional SQL WHERE condition
        
    Returns:
        SQL for vector similarity search
    """
    # Determine the operator based on similarity metric
    if similarity_metric.lower() == "cosine":
        operator = "<=>"  # Cosine distance
    elif similarity_metric.lower() in ["l2", "euclidean"]:
        operator = "<->"  # L2 distance
    elif similarity_metric.lower() in ["inner", "dot"]:
        operator = "<#>"  # Negative inner product
    else:
        operator = "<=>"  # Default to cosine
    
    # Construct the SQL with parameter placeholder
    columns_str = ", ".join(return_columns)
    
    sql = f"""
    SELECT {columns_str}, ({vector_column} {operator} $1) AS distance
    FROM {schema}.{table}
    """
    
    # Add filter condition if provided
    if filter_condition:
        sql += f" WHERE {filter_condition}"
    
    # Add order by and limit
    sql += f"""
    ORDER BY distance ASC
    LIMIT {limit}
    """
    
    return sql


def convert_embedding_to_pgvector(embedding_list: List[float]) -> str:
    """
    Convert a list of floats to a pgvector compatible string.
    
    Args:
        embedding_list: List of float values representing an embedding
        
    Returns:
        String representation of the embedding for pgvector
    """
    if not embedding_list:
        return "[]"
    
    # Convert to a string with brackets
    vector_str = str(embedding_list).replace(' ', '')
    
    return vector_str


def generate_upsert_sql(
    schema: str,
    table: str,
    columns: List[str],
    primary_key: str,
    update_columns: Optional[List[str]] = None
) -> str:
    """
    Generate SQL for upserting (INSERT ... ON CONFLICT ... DO UPDATE) data.
    
    Args:
        schema: Database schema
        table: Table name
        columns: List of column names
        primary_key: Primary key column for conflict resolution
        update_columns: Columns to update on conflict (defaults to all except primary key)
        
    Returns:
        SQL for upserting data
    """
    if update_columns is None:
        update_columns = [col for col in columns if col != primary_key]
    
    # Create placeholders for values
    placeholders = ", ".join([f"%s" for _ in columns])
    
    # Create column string
    columns_str = ", ".join(columns)
    
    # Create SET clause for UPDATE
    set_clause = ", ".join([f"{col} = EXCLUDED.{col}" for col in update_columns])
    
    sql = f"""
    INSERT INTO {schema}.{table} ({columns_str})
    VALUES ({placeholders})
    ON CONFLICT ({primary_key}) DO UPDATE
    SET {set_clause}
    """
    
    return sql


def create_table_sql(
    schema: str,
    table: str,
    columns: Dict[str, str],
    if_not_exists: bool = True
) -> str:
    """
    Generate SQL for creating a table.
    
    Args:
        schema: Database schema
        table: Table name
        columns: Dictionary mapping column names to their SQL data types
        if_not_exists: Whether to add IF NOT EXISTS to the CREATE TABLE statement
        
    Returns:
        SQL for creating the table
    """
    # Create column definitions
    column_defs = []
    for col_name, col_type in columns.items():
        column_defs.append(f"{col_name} {col_type}")
    
    column_defs_str = ",\n    ".join(column_defs)
    
    # Build the SQL
    sql = f"""
    CREATE TABLE {"IF NOT EXISTS " if if_not_exists else ""}{schema}.{table} (
    {column_defs_str}
    )
    """
    
    return sql 