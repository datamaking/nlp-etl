"""
Utility functions for working with Neo4j and Spark.
"""

import json
from typing import Dict, Any, List, Optional, Union, Tuple
import logging

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, struct, to_json, from_json, explode, array, lit
from pyspark.sql.types import ArrayType, StructType, StringType

from ..exception.exceptions import TargetException
from ..logging_module import get_logger

logger = get_logger(__name__)


def prepare_neo4j_batch(
    df: DataFrame, 
    batch_size: int,
    node_label: str,
    id_column: str,
    text_column: str,
    embedding_column: str,
    property_columns: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """
    Prepare a batch of Neo4j nodes from a Spark DataFrame.
    
    This function converts a Spark DataFrame into a format suitable for
    batch loading into Neo4j.
    
    Args:
        df: Spark DataFrame to convert
        batch_size: Size of the batch
        node_label: Neo4j node label to use
        id_column: Column containing the node ID
        text_column: Column containing the text
        embedding_column: Column containing the embedding
        property_columns: Additional columns to include as node properties
        
    Returns:
        List of dictionaries suitable for Neo4j batch loading
    """
    if property_columns is None:
        property_columns = []
    
    # Validate required columns
    required_columns = [id_column, text_column, embedding_column]
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        raise TargetException(f"Missing required columns: {', '.join(missing_columns)}")
    
    # Select only the columns we need
    columns_to_select = required_columns + property_columns
    df_selected = df.select(*columns_to_select)
    
    # Convert to list of dictionaries
    rows = df_selected.limit(batch_size).collect()
    
    # Convert to Neo4j format
    nodes = []
    for row in rows:
        node = {
            "labels": [node_label],
            "properties": {
                id_column: row[id_column],
                text_column: row[text_column],
                embedding_column: row[embedding_column]
            }
        }
        
        # Add additional properties
        for prop in property_columns:
            if prop in row.__fields__:
                node["properties"][prop] = row[prop]
        
        nodes.append(node)
    
    return nodes


def create_neo4j_relationships(
    df: DataFrame,
    source_label: str,
    target_label: str,
    relationship_type: str,
    source_id_column: str,
    target_id_column: str,
    batch_size: int = 1000
) -> List[Dict[str, Any]]:
    """
    Create Neo4j relationships from a Spark DataFrame.
    
    Args:
        df: Spark DataFrame containing relationship data
        source_label: Label for the source node
        target_label: Label for the target node
        relationship_type: Type of relationship to create
        source_id_column: Column containing the source node ID
        target_id_column: Column containing the target node ID
        batch_size: Size of the batch
        
    Returns:
        List of relationship dictionaries suitable for Neo4j batch loading
    """
    # Validate required columns
    required_columns = [source_id_column, target_id_column]
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        raise TargetException(f"Missing required columns: {', '.join(missing_columns)}")
    
    # Select only the columns we need and distinct values
    df_selected = df.select(source_id_column, target_id_column).distinct()
    
    # Convert to list of dictionaries
    rows = df_selected.limit(batch_size).collect()
    
    # Convert to Neo4j relationship format
    relationships = []
    for row in rows:
        relationship = {
            "start": {
                "labels": [source_label],
                "properties": {
                    "id": row[source_id_column]
                }
            },
            "end": {
                "labels": [target_label],
                "properties": {
                    "id": row[target_id_column]
                }
            },
            "type": relationship_type
        }
        relationships.append(relationship)
    
    return relationships


def generate_cypher_for_vector_search(
    node_label: str,
    embedding_column: str,
    similarity_metric: str = "cosine",
    limit: int = 10,
    return_columns: Optional[List[str]] = None
) -> str:
    """
    Generate a Cypher query for vector similarity search.
    
    Args:
        node_label: Label of the node to search
        embedding_column: Name of the embedding column
        similarity_metric: Similarity metric to use (cosine, euclidean, dot)
        limit: Maximum number of results to return
        return_columns: List of columns to return in the results
        
    Returns:
        Cypher query string for vector similarity search
    """
    if return_columns is None:
        return_columns = ["id", "text"]
    
    # Choose the right similarity function
    if similarity_metric.lower() == "cosine":
        similarity_function = "vector.similarity"
    elif similarity_metric.lower() in ["euclidean", "l2"]:
        similarity_function = "vector.distance"
    elif similarity_metric.lower() in ["dot", "dotproduct"]:
        similarity_function = "vector.dotProduct"
    else:
        similarity_function = "vector.similarity"  # Default to cosine
    
    # Build the return clause
    return_clause = ", ".join([f"n.{col}" for col in return_columns])
    
    # Build the query
    query = f"""
    MATCH (n:{node_label})
    WITH n, {similarity_function}(n.{embedding_column}, $query_vector) AS score
    ORDER BY score {'DESC' if similarity_function != 'vector.distance' else 'ASC'}
    LIMIT {limit}
    RETURN {return_clause}, score
    """
    
    return query


def convert_to_neo4j_properties(properties: Dict[str, Any]) -> Dict[str, str]:
    """
    Convert a dictionary of properties to Neo4j property definitions.
    
    Args:
        properties: Dictionary of property names and types
        
    Returns:
        Dictionary with property definitions for Neo4j
    """
    neo4j_properties = {}
    for prop_name, prop_type in properties.items():
        # Map common Python/SQL types to Neo4j
        if prop_type.lower() in ["str", "string", "text", "varchar"]:
            neo4j_properties[prop_name] = "String"
        elif prop_type.lower() in ["int", "integer", "long", "bigint"]:
            neo4j_properties[prop_name] = "Integer"
        elif prop_type.lower() in ["float", "double", "decimal"]:
            neo4j_properties[prop_name] = "Float"
        elif prop_type.lower() in ["bool", "boolean"]:
            neo4j_properties[prop_name] = "Boolean"
        elif prop_type.lower() in ["date", "datetime", "timestamp"]:
            neo4j_properties[prop_name] = "DateTime"
        elif prop_type.lower() in ["list", "array"]:
            neo4j_properties[prop_name] = "List"
        elif prop_type.lower() in ["dict", "map", "json", "jsonb"]:
            neo4j_properties[prop_name] = "Map"
        else:
            # Default to string for unknown types
            neo4j_properties[prop_name] = "String"
    
    return neo4j_properties 