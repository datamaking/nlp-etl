"""
Exceptions module for the NLP Pipeline.
Provides custom exceptions for different pipeline components.
"""

# Make exceptions available at the package level
from .exceptions import (
    PipelineException,
    ConfigurationException,
    DataSourceException,
    PreprocessingException,
    ChunkingException,
    EmbeddingException,
    TargetException
)

__all__ = [
    'PipelineException',
    'ConfigurationException',
    'DataSourceException',
    'PreprocessingException',
    'ChunkingException',
    'EmbeddingException',
    'TargetException'
] 