"""
Chunking module for NLP Pipeline.
Handles text chunking using various strategies.
"""

from typing import Dict, Any

from .chunker_base import Chunker
from .chunkers import RecursiveChunker, SentenceChunker, ParagraphChunker, FixedSizeChunker

def create_chunker(config: Dict[str, Any]) -> Chunker:
    """
    Create a chunker based on configuration.
    
    Args:
        config: Chunker configuration
        
    Returns:
        Chunker instance
    
    Raises:
        ValueError: If chunker type is not supported
    """
    chunker_type = config.get("type", "").lower()
    
    if chunker_type == "recursive":
        return RecursiveChunker(config)
    elif chunker_type == "sentence":
        return SentenceChunker(config)
    elif chunker_type == "paragraph":
        return ParagraphChunker(config)
    elif chunker_type == "fixed_size":
        return FixedSizeChunker(config)
    else:
        raise ValueError(f"Unsupported chunker type: {chunker_type}")

__all__ = [
    'Chunker',
    'RecursiveChunker',
    'SentenceChunker',
    'ParagraphChunker',
    'FixedSizeChunker',
    'create_chunker'
] 