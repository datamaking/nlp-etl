"""
Base class for text chunkers in the NLP Pipeline.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pyspark.sql import DataFrame

from ..exception import ChunkingException
from ..logging_module import get_logger

logger = get_logger(__name__)

class Chunker(ABC):
    """
    Abstract base class for text chunking strategies.
    
    All chunker implementations should inherit from this class
    and implement the required methods.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the chunker with the given configuration.
        
        Args:
            config: Configuration dictionary for the chunker
        """
        self.config = config
        self.parameters = config.get("parameters", {})
        
        # Input and output column names
        self.input_column = self.parameters.get("input_column", "text")
        self.output_column = self.parameters.get("output_column", "chunks")
        
        # Validate configuration
        self._validate_chunker_config()
    
    @abstractmethod
    def _validate_chunker_config(self) -> None:
        """
        Validate chunker specific configuration.
        
        Each chunker implementation should override this method to perform
        validation specific to its configuration parameters.
        
        Raises:
            ChunkingException: If the configuration is invalid
        """
        pass
    
    @abstractmethod
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data using this chunking strategy.
        
        Args:
            df: DataFrame containing the data to process
            
        Returns:
            DataFrame with exploded chunks
            
        Raises:
            ChunkingException: If processing fails
        """
        pass
    
    def validate_df(self, df: DataFrame) -> None:
        """
        Validate input DataFrame.
        
        Args:
            df: DataFrame to validate
            
        Raises:
            ChunkingException: If validation fails
        """
        if not df.columns:
            raise ChunkingException("Input DataFrame is empty")
        
        if self.input_column not in df.columns:
            raise ChunkingException(f"Input column '{self.input_column}' not found in DataFrame")

    def _validate_config(self) -> None:
        """
        Validate the chunker configuration.
        
        Raises:
            ChunkingException: If configuration is invalid
        """
        if not self.input_column:
            raise ChunkingException("Input column must be specified")
        
        if not self.output_column:
            raise ChunkingException("Output column must be specified")
        
        # Chunker-specific validation
        self._validate_chunker_config()
        
        logger.info(f"Initialized {self.__class__.__name__}") 