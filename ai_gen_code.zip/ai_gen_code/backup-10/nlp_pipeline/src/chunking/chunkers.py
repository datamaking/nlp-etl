"""
Chunking implementations for the NLP Pipeline.
"""

import re
from typing import Dict, Any, List, Callable, Iterator, Union

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType, StringType, StructType, StructField, IntegerType

from .chunker_base import Chunker
from ..exception import ChunkingException
from ..logging_module import get_logger

logger = get_logger(__name__)


class RecursiveChunker(Chunker):
    """
    Chunker that recursively splits text based on separators.
    """
    
    def _validate_chunker_config(self) -> None:
        """Validate recursive chunker configuration."""
        # Required parameters
        if "chunk_size" not in self.parameters:
            raise ChunkingException("chunk_size must be specified for recursive chunker")
        
        if "separators" not in self.parameters:
            raise ChunkingException("separators must be specified for recursive chunker")
        
        # Parameter validation
        chunk_size = self.parameters.get("chunk_size")
        chunk_overlap = self.parameters.get("chunk_overlap", 0)
        min_chunk_size = self.parameters.get("min_chunk_size", 0)
        separators = self.parameters.get("separators")
        
        if not isinstance(chunk_size, int) or chunk_size <= 0:
            raise ChunkingException("chunk_size must be a positive integer")
        
        if not isinstance(chunk_overlap, int) or chunk_overlap < 0:
            raise ChunkingException("chunk_overlap must be a non-negative integer")
        
        if not isinstance(min_chunk_size, int) or min_chunk_size < 0:
            raise ChunkingException("min_chunk_size must be a non-negative integer")
        
        if not isinstance(separators, list) or not separators:
            raise ChunkingException("separators must be a non-empty list")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data using recursive chunking.
        
        Args:
            df: DataFrame containing the data to process
            
        Returns:
            DataFrame with exploded chunks
        """
        # Validate input DataFrame
        self.validate_df(df)
        
        # Get parameters
        chunk_size = self.parameters.get("chunk_size")
        chunk_overlap = self.parameters.get("chunk_overlap", 0)
        min_chunk_size = self.parameters.get("min_chunk_size", chunk_size // 4)
        separators = self.parameters.get("separators")
        
        # Log parameters
        logger.info(f"Processing with RecursiveChunker: size={chunk_size}, overlap={chunk_overlap}, min_size={min_chunk_size}")
        logger.info(f"Using separators: {separators}")
        
        # Register UDF for recursive chunking
        recursive_chunk_udf = F.udf(
            lambda text: self._recursive_chunk(text, chunk_size, chunk_overlap, min_chunk_size, separators),
            ArrayType(StringType())
        )
        
        # Generate chunks
        chunked_df = df.withColumn("_chunks", recursive_chunk_udf(F.col(self.input_column)))
        
        # Explode chunks and add index
        chunked_df = chunked_df.select(
            "*",
            F.posexplode("_chunks").alias("chunk_index", "chunk_text")
        ).drop("_chunks")
        
        # Log chunking results
        chunk_count = chunked_df.count()
        logger.info(f"Created {chunk_count} chunks using recursive chunking")
        
        return chunked_df
    
    def _recursive_chunk(
        self, 
        text: str, 
        chunk_size: int, 
        chunk_overlap: int, 
        min_chunk_size: int, 
        separators: List[str]
    ) -> List[str]:
        """
        Recursively split text into chunks based on separators.
        
        Args:
            text: Text to chunk
            chunk_size: Maximum chunk size in characters
            chunk_overlap: Overlap between chunks
            min_chunk_size: Minimum chunk size
            separators: List of separators to try, in order of preference
            
        Returns:
            List of text chunks
        """
        # If text is short enough, return it as a single chunk
        if len(text) <= chunk_size:
            return [text]
        
        # Try each separator in order
        for separator in separators:
            # Split text by separator
            segments = text.split(separator)
            
            # If splitting produces reasonable chunks, use it
            if len(segments) > 1:
                chunks = []
                current_chunk = []
                current_length = 0
                
                for segment in segments:
                    segment_with_sep = segment + separator
                    segment_length = len(segment_with_sep)
                    
                    # If adding this segment exceeds chunk size
                    if current_length + segment_length > chunk_size and current_length > min_chunk_size:
                        # Add current chunk to list
                        chunks.append(separator.join(current_chunk))
                        
                        # Start new chunk with overlap
                        if chunk_overlap > 0 and current_chunk:
                            # Calculate how many segments to include for overlap
                            overlap_length = 0
                            overlap_segments = []
                            
                            for seg in reversed(current_chunk):
                                seg_len = len(seg) + len(separator)
                                if overlap_length + seg_len <= chunk_overlap:
                                    overlap_segments.insert(0, seg)
                                    overlap_length += seg_len
                                else:
                                    break
                            
                            current_chunk = overlap_segments
                            current_length = overlap_length
                        else:
                            current_chunk = []
                            current_length = 0
                    
                    # Add segment to current chunk
                    current_chunk.append(segment)
                    current_length += segment_length
                
                # Add final chunk if not empty
                if current_chunk:
                    chunks.append(separator.join(current_chunk))
                
                # If chunks were created, return them
                if chunks:
                    # Recursively chunk any chunks that are still too large
                    final_chunks = []
                    for chunk in chunks:
                        if len(chunk) > chunk_size:
                            # Try with next level of separators
                            next_separators = separators[1:] if len(separators) > 1 else [" "]
                            final_chunks.extend(
                                self._recursive_chunk(chunk, chunk_size, chunk_overlap, min_chunk_size, next_separators)
                            )
                        else:
                            final_chunks.append(chunk)
                    
                    return final_chunks
        
        # If no good splits found with separators, fall back to character-based splitting
        chunks = []
        for i in range(0, len(text), chunk_size - chunk_overlap):
            chunk = text[i:i + chunk_size]
            if len(chunk) >= min_chunk_size:
                chunks.append(chunk)
        
        return chunks


class SentenceChunker(Chunker):
    """
    Chunker that splits text into sentences and groups them into chunks.
    """
    
    def _validate_chunker_config(self) -> None:
        """Validate sentence chunker configuration."""
        # Required parameters
        if "chunk_size" not in self.parameters:
            raise ChunkingException("chunk_size must be specified for sentence chunker")
        
        # Parameter validation
        chunk_size = self.parameters.get("chunk_size")
        chunk_overlap = self.parameters.get("chunk_overlap", 0)
        min_chunk_size = self.parameters.get("min_chunk_size", 0)
        
        if not isinstance(chunk_size, int) or chunk_size <= 0:
            raise ChunkingException("chunk_size must be a positive integer")
        
        if not isinstance(chunk_overlap, int) or chunk_overlap < 0:
            raise ChunkingException("chunk_overlap must be a non-negative integer")
        
        if not isinstance(min_chunk_size, int) or min_chunk_size < 0:
            raise ChunkingException("min_chunk_size must be a non-negative integer")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data using sentence chunking.
        
        Args:
            df: DataFrame containing the data to process
            
        Returns:
            DataFrame with exploded chunks
        """
        # Validate input DataFrame
        self.validate_df(df)
        
        # Get parameters
        chunk_size = self.parameters.get("chunk_size")
        chunk_overlap = self.parameters.get("chunk_overlap", 0)
        min_chunk_size = self.parameters.get("min_chunk_size", chunk_size // 4)
        
        # Log parameters
        logger.info(f"Processing with SentenceChunker: size={chunk_size}, overlap={chunk_overlap}, min_size={min_chunk_size}")
        
        # Register UDF for sentence chunking
        sentence_chunk_udf = F.udf(
            lambda text: self._sentence_chunk(text, chunk_size, chunk_overlap, min_chunk_size),
            ArrayType(StringType())
        )
        
        # Generate chunks
        chunked_df = df.withColumn("_chunks", sentence_chunk_udf(F.col(self.input_column)))
        
        # Explode chunks and add index
        chunked_df = chunked_df.select(
            "*",
            F.posexplode("_chunks").alias("chunk_index", "chunk_text")
        ).drop("_chunks")
        
        # Log chunking results
        chunk_count = chunked_df.count()
        logger.info(f"Created {chunk_count} chunks using sentence chunking")
        
        return chunked_df
    
    def _sentence_chunk(
        self, 
        text: str, 
        chunk_size: int, 
        chunk_overlap: int, 
        min_chunk_size: int
    ) -> List[str]:
        """
        Split text into sentences and group them into chunks.
        
        Args:
            text: Text to chunk
            chunk_size: Maximum chunk size in characters
            chunk_overlap: Overlap between chunks
            min_chunk_size: Minimum chunk size
            
        Returns:
            List of text chunks
        """
        # If text is short enough, return it as a single chunk
        if len(text) <= chunk_size:
            return [text]
        
        # Split text into sentences
        sentences = self._split_into_sentences(text)
        
        chunks = []
        current_chunk = []
        current_length = 0
        
        for sentence in sentences:
            sentence_length = len(sentence)
            
            # If adding this sentence exceeds chunk size
            if current_length + sentence_length > chunk_size and current_length > min_chunk_size:
                # Add current chunk to list
                chunks.append(" ".join(current_chunk))
                
                # Start new chunk with overlap
                if chunk_overlap > 0 and current_chunk:
                    # Calculate how many sentences to include for overlap
                    overlap_length = 0
                    overlap_sentences = []
                    
                    for sent in reversed(current_chunk):
                        sent_len = len(sent) + 1  # +1 for space
                        if overlap_length + sent_len <= chunk_overlap:
                            overlap_sentences.insert(0, sent)
                            overlap_length += sent_len
                        else:
                            break
                    
                    current_chunk = overlap_sentences
                    current_length = overlap_length
                else:
                    current_chunk = []
                    current_length = 0
            
            # Add sentence to current chunk
            current_chunk.append(sentence)
            current_length += sentence_length + 1  # +1 for space
        
        # Add final chunk if not empty
        if current_chunk:
            chunks.append(" ".join(current_chunk))
        
        return chunks
    
    def _split_into_sentences(self, text: str) -> List[str]:
        """
        Split text into sentences.
        
        Args:
            text: Text to split
            
        Returns:
            List of sentences
        """
        # Simple sentence splitting using regex
        # This is a simplified version - consider using a more robust NLP library in production
        sentences = re.split(r'(?<=[.!?])\s+', text)
        return [s.strip() for s in sentences if s.strip()]


class ParagraphChunker(Chunker):
    """
    Chunker that splits text into paragraphs and groups them into chunks.
    """
    
    def _validate_chunker_config(self) -> None:
        """Validate paragraph chunker configuration."""
        # Required parameters
        if "max_size" not in self.parameters:
            raise ChunkingException("max_size must be specified for paragraph chunker")
        
        if "min_size" not in self.parameters:
            raise ChunkingException("min_size must be specified for paragraph chunker")
        
        # Parameter validation
        max_size = self.parameters.get("max_size")
        min_size = self.parameters.get("min_size")
        separator = self.parameters.get("separator", "\n\n")
        
        if not isinstance(max_size, int) or max_size <= 0:
            raise ChunkingException("max_size must be a positive integer")
        
        if not isinstance(min_size, int) or min_size <= 0:
            raise ChunkingException("min_size must be a positive integer")
        
        if min_size > max_size:
            raise ChunkingException("min_size must be less than or equal to max_size")
        
        if not isinstance(separator, str):
            raise ChunkingException("separator must be a string")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data using paragraph chunking.
        
        Args:
            df: DataFrame containing the data to process
            
        Returns:
            DataFrame with exploded chunks
        """
        # Validate input DataFrame
        self.validate_df(df)
        
        # Get parameters
        max_size = self.parameters.get("max_size")
        min_size = self.parameters.get("min_size")
        separator = self.parameters.get("separator", "\n\n")
        
        # Log parameters
        logger.info(f"Processing with ParagraphChunker: max_size={max_size}, min_size={min_size}, separator='{separator}'")
        
        # Register UDF for paragraph chunking
        paragraph_chunk_udf = F.udf(
            lambda text: self._paragraph_chunk(text, max_size, min_size, separator),
            ArrayType(StringType())
        )
        
        # Generate chunks
        chunked_df = df.withColumn("_chunks", paragraph_chunk_udf(F.col(self.input_column)))
        
        # Explode chunks and add index
        chunked_df = chunked_df.select(
            "*",
            F.posexplode("_chunks").alias("chunk_index", "chunk_text")
        ).drop("_chunks")
        
        # Log chunking results
        chunk_count = chunked_df.count()
        logger.info(f"Created {chunk_count} chunks using paragraph chunking")
        
        return chunked_df
    
    def _paragraph_chunk(
        self, 
        text: str, 
        max_size: int, 
        min_size: int, 
        separator: str
    ) -> List[str]:
        """
        Split text into paragraphs and group them into chunks.
        
        Args:
            text: Text to chunk
            max_size: Maximum chunk size in characters
            min_size: Minimum chunk size in characters
            separator: Paragraph separator
            
        Returns:
            List of text chunks
        """
        # If text is short enough, return it as a single chunk
        if len(text) <= max_size:
            return [text]
        
        # Split text into paragraphs
        paragraphs = [p.strip() for p in text.split(separator) if p.strip()]
        
        chunks = []
        current_chunk = []
        current_length = 0
        
        for paragraph in paragraphs:
            paragraph_length = len(paragraph)
            
            # If paragraph is too large, split it
            if paragraph_length > max_size:
                # If we have an existing chunk, add it first
                if current_chunk:
                    chunks.append(separator.join(current_chunk))
                    current_chunk = []
                    current_length = 0
                
                # Split the paragraph
                for i in range(0, paragraph_length, max_size):
                    sub_para = paragraph[i:i + max_size]
                    if len(sub_para) >= min_size:
                        chunks.append(sub_para)
                
                continue
            
            # If adding this paragraph exceeds max size
            if current_length + paragraph_length + len(separator) > max_size and current_length >= min_size:
                # Add current chunk to list
                chunks.append(separator.join(current_chunk))
                
                # Start new chunk
                current_chunk = [paragraph]
                current_length = paragraph_length
            else:
                # Add paragraph to current chunk
                if current_chunk:
                    current_length += len(separator)
                current_chunk.append(paragraph)
                current_length += paragraph_length
        
        # Add final chunk if not empty
        if current_chunk:
            chunks.append(separator.join(current_chunk))
        
        return chunks


class FixedSizeChunker(Chunker):
    """
    Chunker that splits text into fixed-size chunks with optional overlap.
    """
    
    def _validate_chunker_config(self) -> None:
        """Validate fixed-size chunker configuration."""
        # Required parameters
        if "chunk_size" not in self.parameters:
            raise ChunkingException("chunk_size must be specified for fixed-size chunker")
        
        # Parameter validation
        chunk_size = self.parameters.get("chunk_size")
        chunk_overlap = self.parameters.get("chunk_overlap", 0)
        
        if not isinstance(chunk_size, int) or chunk_size <= 0:
            raise ChunkingException("chunk_size must be a positive integer")
        
        if not isinstance(chunk_overlap, int) or chunk_overlap < 0:
            raise ChunkingException("chunk_overlap must be a non-negative integer")
        
        if chunk_overlap >= chunk_size:
            raise ChunkingException("chunk_overlap must be less than chunk_size")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data using fixed-size chunking.
        
        Args:
            df: DataFrame containing the data to process
            
        Returns:
            DataFrame with exploded chunks
        """
        # Validate input DataFrame
        self.validate_df(df)
        
        # Get parameters
        chunk_size = self.parameters.get("chunk_size")
        chunk_overlap = self.parameters.get("chunk_overlap", 0)
        respect_sentences = self.parameters.get("respect_sentences", True)
        
        # Log parameters
        logger.info(f"Processing with FixedSizeChunker: size={chunk_size}, overlap={chunk_overlap}, respect_sentences={respect_sentences}")
        
        # Register UDF for fixed-size chunking
        fixed_size_chunk_udf = F.udf(
            lambda text: self._fixed_size_chunk(text, chunk_size, chunk_overlap, respect_sentences),
            ArrayType(StringType())
        )
        
        # Generate chunks
        chunked_df = df.withColumn("_chunks", fixed_size_chunk_udf(F.col(self.input_column)))
        
        # Explode chunks and add index
        chunked_df = chunked_df.select(
            "*",
            F.posexplode("_chunks").alias("chunk_index", "chunk_text")
        ).drop("_chunks")
        
        # Log chunking results
        chunk_count = chunked_df.count()
        logger.info(f"Created {chunk_count} chunks using fixed-size chunking")
        
        return chunked_df
    
    def _fixed_size_chunk(
        self, 
        text: str, 
        chunk_size: int, 
        chunk_overlap: int, 
        respect_sentences: bool
    ) -> List[str]:
        """
        Split text into fixed-size chunks.
        
        Args:
            text: Text to chunk
            chunk_size: Chunk size in characters
            chunk_overlap: Overlap between chunks
            respect_sentences: Whether to avoid breaking sentences
            
        Returns:
            List of text chunks
        """
        # If text is short enough, return it as a single chunk
        if len(text) <= chunk_size:
            return [text]
        
        # If respecting sentence boundaries
        if respect_sentences:
            sentences = self._split_into_sentences(text)
            
            chunks = []
            current_chunk = []
            current_length = 0
            
            for sentence in sentences:
                sentence_length = len(sentence)
                
                # If single sentence is longer than chunk size, we have to split it
                if sentence_length > chunk_size:
                    # Add current chunk if not empty
                    if current_chunk:
                        chunks.append(" ".join(current_chunk))
                        current_chunk = []
                        current_length = 0
                    
                    # Split the sentence into fixed-size pieces
                    for i in range(0, sentence_length, chunk_size - chunk_overlap):
                        chunk = sentence[i:i + chunk_size]
                        if chunk:
                            chunks.append(chunk)
                    
                    continue
                
                # If adding this sentence exceeds chunk size
                if current_length + sentence_length + 1 > chunk_size:
                    # Add current chunk
                    chunks.append(" ".join(current_chunk))
                    
                    # If overlap is specified, keep some sentences
                    if chunk_overlap > 0:
                        # Keep sentences that fit within overlap
                        overlap_sentences = []
                        overlap_length = 0
                        
                        for i in range(len(current_chunk) - 1, -1, -1):
                            sent = current_chunk[i]
                            sent_len = len(sent) + 1  # +1 for space
                            
                            if overlap_length + sent_len <= chunk_overlap:
                                overlap_sentences.insert(0, sent)
                                overlap_length += sent_len
                            else:
                                break
                        
                        current_chunk = overlap_sentences
                        current_length = overlap_length
                    else:
                        current_chunk = []
                        current_length = 0
                
                # Add sentence to current chunk
                current_chunk.append(sentence)
                if current_length > 0:
                    current_length += 1  # Space between sentences
                current_length += sentence_length
            
            # Add final chunk if not empty
            if current_chunk:
                chunks.append(" ".join(current_chunk))
            
            return chunks
        
        # Simple character-based chunking if not respecting sentences
        else:
            chunks = []
            for i in range(0, len(text), chunk_size - chunk_overlap):
                chunk = text[i:i + chunk_size]
                if chunk:
                    chunks.append(chunk)
            
            return chunks
    
    def _split_into_sentences(self, text: str) -> List[str]:
        """
        Split text into sentences.
        
        Args:
            text: Text to split
            
        Returns:
            List of sentences
        """
        # Simple sentence splitting using regex
        sentences = re.split(r'(?<=[.!?])\s+', text)
        return [s.strip() for s in sentences if s.strip()] 