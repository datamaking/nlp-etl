#!/usr/bin/env python
"""
Command-line interface for the NLP Pipeline.
Provides a simple way to run the pipeline from the command line.
"""

import sys
import argparse
from typing import List, Optional

from src.pipeline import NLPPipeline
from src.logging_module import setup_logger, get_logger
from src.exception import PipelineException

logger = get_logger(__name__)

def parse_args(args: Optional[List[str]] = None) -> argparse.Namespace:
    """
    Parse command-line arguments.
    
    Args:
        args: List of command-line arguments (used for testing)
    
    Returns:
        Parsed arguments
    """
    parser = argparse.ArgumentParser(
        description="NLP Pipeline - Process documents and store in vector databases"
    )
    
    parser.add_argument(
        "-c", "--config",
        required=True,
        help="Path to YAML configuration file"
    )
    
    parser.add_argument(
        "-s", "--step",
        choices=["extract", "preprocess", "chunk", "embed", "load", "all"],
        default="all",
        help="Specific pipeline step to run"
    )
    
    parser.add_argument(
        "-p", "--checkpoint",
        action="store_true",
        help="Use checkpoints if available"
    )
    
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose logging"
    )
    
    return parser.parse_args(args)

def main(args: Optional[List[str]] = None) -> int:
    """
    Main entry point for the NLP Pipeline CLI.
    
    Args:
        args: Command-line arguments (used for testing)
    
    Returns:
        Exit code (0 for success, non-zero for failure)
    """
    # Parse command line arguments
    parsed_args = parse_args(args)
    
    # Set up logging
    log_level = "DEBUG" if parsed_args.verbose else "INFO"
    setup_logger(log_level=log_level)
    
    try:
        # Log startup information
        logger.info(f"Starting NLP Pipeline with config: {parsed_args.config}")
        
        # Create pipeline instance
        pipeline = NLPPipeline(
            config_path=parsed_args.config,
            use_checkpoints=parsed_args.checkpoint,
            verbose=parsed_args.verbose
        )
        
        # Run the pipeline
        step = None if parsed_args.step == "all" else parsed_args.step
        pipeline.run(step)
        
        # Shutdown
        pipeline.shutdown()
        
        logger.info("Pipeline execution completed successfully")
        return 0
    
    except PipelineException as e:
        logger.error(f"Pipeline execution failed: {e}")
        return 1
    
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return 2

if __name__ == "__main__":
    sys.exit(main()) 