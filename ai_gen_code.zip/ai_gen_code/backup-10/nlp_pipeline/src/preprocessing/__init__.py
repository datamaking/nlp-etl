"""
Preprocessing module for NLP Pipeline.
Handles text cleaning, normalization, and other preprocessing operations.
"""

from typing import Dict, Any

from .preprocessor_base import Preprocessor
from .text_preprocessor import TextPreprocessor

def create_preprocessor(config: Dict[str, Any]) -> Preprocessor:
    """
    Create a preprocessor based on configuration.
    
    Args:
        config: Preprocessor configuration
        
    Returns:
        Preprocessor instance
    
    Raises:
        ValueError: If preprocessor type is not supported
    """
    # Currently we only have one preprocessor type
    return TextPreprocessor(config)

__all__ = [
    'Preprocessor',
    'TextPreprocessor',
    'create_preprocessor'
] 