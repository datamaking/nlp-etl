"""
Text preprocessing implementations for the NLP Pipeline.
"""

import re
import html
import unicodedata
from typing import Dict, Any, List, Callable, Optional

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StringType

from ..exception import PreprocessingException
from ..logging_module import get_logger

logger = get_logger(__name__)


class TextPreprocessor:
    """
    Text preprocessor that applies a sequence of operations to text data.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the text preprocessor.
        
        Args:
            config: Preprocessor configuration
        """
        self.config = config
        self.parameters = config.get("parameters", {})
        self.operations = config.get("operations", [])
        
        # Columns
        self.input_column = config.get("input_column", "text")
        self.output_column = config.get("output_column", "processed_text")
        
        # Validate config
        self._validate_config()
        
        # Create operation mapping
        self.operation_functions = {
            "clean_text": self._clean_text,
            "normalize_unicode": self._normalize_unicode,
            "remove_html_tags": self._remove_html_tags,
            "remove_urls": self._remove_urls,
            "remove_punctuation": self._remove_punctuation,
            "remove_extra_whitespace": self._remove_extra_whitespace,
            "lowercase": self._lowercase,
            "remove_numbers": self._remove_numbers,
            "remove_stopwords": self._remove_stopwords,
            "lemmatize": self._lemmatize,
            "replace_patterns": self._replace_patterns
        }
        
        # Log initialization
        logger.info(f"Initialized TextPreprocessor with operations: {self.operations}")
    
    def _validate_config(self) -> None:
        """Validate preprocessor configuration."""
        if not self.operations:
            logger.warning("No preprocessing operations specified")
        
        if not self.input_column:
            raise PreprocessingException("Input column must be specified")
        
        if not self.output_column:
            raise PreprocessingException("Output column must be specified")
        
        # Validate operations
        for op in self.operations:
            if op not in self.operation_functions and not op.startswith("custom_"):
                logger.warning(f"Unknown preprocessing operation: {op}")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data through the preprocessing pipeline.
        
        Args:
            df: DataFrame containing text to preprocess
            
        Returns:
            DataFrame with processed text
        """
        # Check if input column exists
        if self.input_column not in df.columns:
            raise PreprocessingException(f"Input column '{self.input_column}' not found in DataFrame")
        
        # Create initial processed column if needed
        if self.input_column != self.output_column:
            df = df.withColumn(self.output_column, F.col(self.input_column))
        
        # Apply each operation in sequence
        for operation in self.operations:
            if operation in self.operation_functions:
                # Apply standard operation
                df = self.operation_functions[operation](df)
                logger.info(f"Applied preprocessing operation: {operation}")
            elif operation.startswith("custom_"):
                # Apply custom operation if defined
                custom_func = self.parameters.get(operation)
                if custom_func and callable(custom_func):
                    df = self._apply_custom_function(df, custom_func)
                    logger.info(f"Applied custom preprocessing operation: {operation}")
                else:
                    logger.warning(f"Custom preprocessing function '{operation}' not defined or not callable")
            else:
                logger.warning(f"Skipping unknown preprocessing operation: {operation}")
        
        return df
    
    def _clean_text(self, df: DataFrame) -> DataFrame:
        """
        General text cleaning.
        
        Combines multiple basic cleaning operations:
        - Converts to lowercase
        - Removes extra whitespace
        """
        df = df.withColumn(
            self.output_column,
            F.lower(F.regexp_replace(F.col(self.output_column), r'\s+', ' '))
        )
        return df
    
    def _normalize_unicode(self, df: DataFrame) -> DataFrame:
        """Normalize Unicode characters."""
        # Using UDF since this operation is not directly available in Spark SQL
        @F.udf(returnType=StringType())
        def normalize_unicode_udf(text):
            if not text:
                return text
            return unicodedata.normalize('NFKD', text)
        
        df = df.withColumn(self.output_column, normalize_unicode_udf(F.col(self.output_column)))
        return df
    
    def _remove_html_tags(self, df: DataFrame) -> DataFrame:
        """Remove HTML tags and decode HTML entities."""
        @F.udf(returnType=StringType())
        def remove_html_udf(text):
            if not text:
                return text
            # First decode HTML entities
            text = html.unescape(text)
            # Then remove HTML tags
            text = re.sub(r'<[^>]+>', '', text)
            return text
        
        df = df.withColumn(self.output_column, remove_html_udf(F.col(self.output_column)))
        return df
    
    def _remove_urls(self, df: DataFrame) -> DataFrame:
        """Remove URLs."""
        df = df.withColumn(
            self.output_column,
            F.regexp_replace(F.col(self.output_column), r'https?://\S+|www\.\S+', '')
        )
        return df
    
    def _remove_punctuation(self, df: DataFrame) -> DataFrame:
        """Remove punctuation."""
        df = df.withColumn(
            self.output_column,
            F.regexp_replace(F.col(self.output_column), r'[^\w\s]', '')
        )
        return df
    
    def _remove_extra_whitespace(self, df: DataFrame) -> DataFrame:
        """Remove extra whitespace."""
        df = df.withColumn(
            self.output_column,
            F.trim(F.regexp_replace(F.col(self.output_column), r'\s+', ' '))
        )
        return df
    
    def _lowercase(self, df: DataFrame) -> DataFrame:
        """Convert text to lowercase."""
        df = df.withColumn(
            self.output_column,
            F.lower(F.col(self.output_column))
        )
        return df
    
    def _remove_numbers(self, df: DataFrame) -> DataFrame:
        """Remove numbers."""
        df = df.withColumn(
            self.output_column,
            F.regexp_replace(F.col(self.output_column), r'\d+', '')
        )
        return df
    
    def _remove_stopwords(self, df: DataFrame) -> DataFrame:
        """Remove stopwords."""
        language = self.parameters.get("language", "english")
        
        # Try to load stopwords
        try:
            import nltk
            try:
                nltk.data.find(f'corpora/stopwords')
            except LookupError:
                logger.info("Downloading NLTK stopwords")
                nltk.download('stopwords', quiet=True)
            
            from nltk.corpus import stopwords
            stop_words = set(stopwords.words(language))
            
            @F.udf(returnType=StringType())
            def remove_stopwords_udf(text):
                if not text:
                    return text
                
                words = text.split()
                filtered_words = [word for word in words if word.lower() not in stop_words]
                return ' '.join(filtered_words)
            
            df = df.withColumn(self.output_column, remove_stopwords_udf(F.col(self.output_column)))
            
        except ImportError:
            logger.warning("NLTK not installed. Install with 'pip install nltk' to use stopword removal.")
        
        return df
    
    def _lemmatize(self, df: DataFrame) -> DataFrame:
        """Lemmatize text."""
        language = self.parameters.get("language", "english")
        
        # Try to load lemmatizer
        try:
            import nltk
            try:
                nltk.data.find('tokenizers/punkt')
                nltk.data.find('corpora/wordnet')
            except LookupError:
                logger.info("Downloading NLTK resources for lemmatization")
                nltk.download('punkt', quiet=True)
                nltk.download('wordnet', quiet=True)
            
            from nltk.stem import WordNetLemmatizer
            from nltk.tokenize import word_tokenize
            
            lemmatizer = WordNetLemmatizer()
            
            @F.udf(returnType=StringType())
            def lemmatize_udf(text):
                if not text:
                    return text
                
                words = word_tokenize(text)
                lemmatized_words = [lemmatizer.lemmatize(word) for word in words]
                return ' '.join(lemmatized_words)
            
            df = df.withColumn(self.output_column, lemmatize_udf(F.col(self.output_column)))
            
        except ImportError:
            logger.warning("NLTK not installed. Install with 'pip install nltk' to use lemmatization.")
        
        return df
    
    def _replace_patterns(self, df: DataFrame) -> DataFrame:
        """Replace text patterns using regular expressions."""
        patterns = self.parameters.get("patterns", [])
        
        if not patterns:
            logger.warning("No patterns specified for replace_patterns operation")
            return df
        
        # Apply each pattern replacement in sequence
        for pattern_obj in patterns:
            if 'pattern' in pattern_obj and 'replacement' in pattern_obj:
                pattern = pattern_obj['pattern']
                replacement = pattern_obj['replacement']
                
                df = df.withColumn(
                    self.output_column,
                    F.regexp_replace(F.col(self.output_column), pattern, replacement)
                )
                logger.info(f"Applied pattern replacement: {pattern} -> {replacement}")
        
        return df
    
    def _apply_custom_function(self, df: DataFrame, func: Callable) -> DataFrame:
        """
        Apply a custom preprocessing function.
        
        Args:
            df: DataFrame to process
            func: Custom preprocessing function
            
        Returns:
            Processed DataFrame
        """
        # Convert to UDF
        custom_udf = F.udf(func, StringType())
        
        # Apply to DataFrame
        df = df.withColumn(self.output_column, custom_udf(F.col(self.output_column)))
        
        return df
