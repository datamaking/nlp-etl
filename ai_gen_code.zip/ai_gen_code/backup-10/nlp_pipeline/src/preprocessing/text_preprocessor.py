"""
Text preprocessor implementation for the NLP Pipeline.
"""

import re
import string
from typing import Dict, Any, List, Optional, Callable
import pyspark.sql.functions as F
from pyspark.sql import DataFrame
from pyspark.sql.types import StringType
from pyspark.ml.feature import StopWordsRemover

from .preprocessor_base import Preprocessor
from ..exception import PreprocessingException
from ..logging_module import get_logger

logger = get_logger(__name__)

class TextPreprocessor(Preprocessor):
    """
    Text preprocessor implementation.
    
    Applies a series of text preprocessing operations to clean and normalize text.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the text preprocessor.
        
        Args:
            config: Configuration dictionary for the preprocessor
        """
        super().__init__(config)
        
        # Get preprocessing parameters with defaults
        self.lowercase = self.parameters.get("lowercase", True)
        self.remove_punctuation = self.parameters.get("remove_punctuation", False)
        self.remove_numbers = self.parameters.get("remove_numbers", False)
        self.remove_stopwords = self.parameters.get("remove_stopwords", False)
        self.language = self.parameters.get("language", "english")
        
        # Map operation names to functions
        self.operation_map = {
            "clean_text": self._create_clean_text_udf,
            "normalize_unicode": self._create_normalize_unicode_udf,
            "remove_html_tags": self._create_remove_html_tags_udf,
            "remove_urls": self._create_remove_urls_udf,
            "remove_extra_whitespace": self._create_remove_extra_whitespace_udf,
            "remove_special_chars": self._create_remove_special_chars_udf,
            "expand_contractions": self._create_expand_contractions_udf,
            "remove_numbers": self._create_remove_numbers_udf,
        }
        
    def _validate_preprocessor_config(self) -> None:
        """Validate text preprocessor configuration."""
        # Check if all operations are supported
        for op in self.operations:
            if op not in self.operation_map:
                raise PreprocessingException(f"Unsupported preprocessing operation: {op}")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Apply preprocessing operations to the input text.
        
        Args:
            df: DataFrame containing the input text
            
        Returns:
            DataFrame with processed text
        """
        # Make sure the input column exists
        if self.input_column not in df.columns:
            raise PreprocessingException(f"Input column '{self.input_column}' not found in DataFrame")
        
        # Start with the input DataFrame
        processed_df = df
        
        # Create a temporary column to avoid overwriting the input
        temp_col = f"{self.output_column}_temp"
        processed_df = processed_df.withColumn(temp_col, F.col(self.input_column))
        
        # Apply lowercase if needed
        if self.lowercase:
            processed_df = processed_df.withColumn(temp_col, F.lower(F.col(temp_col)))
            logger.info("Applied lowercase transformation")
        
        # Apply configured operations in order
        for operation in self.operations:
            logger.info(f"Applying preprocessing operation: {operation}")
            
            if operation in self.operation_map:
                # Get the UDF creation function
                udf_creator = self.operation_map[operation]
                # Create the UDF
                operation_udf = udf_creator()
                # Apply the UDF
                processed_df = processed_df.withColumn(temp_col, operation_udf(F.col(temp_col)))
            else:
                logger.warning(f"Unknown preprocessing operation: {operation}, skipping")
        
        # Apply stopword removal if configured (using ML library)
        if self.remove_stopwords:
            logger.info("Removing stopwords")
            # Create a stop words remover
            remover = StopWordsRemover(
                inputCol=temp_col,
                outputCol=f"{temp_col}_no_stopwords",
                stopWords=StopWordsRemover.loadDefaultStopWords(self.language)
            )
            # Apply the remover and join words back into a string
            processed_df = remover.transform(processed_df)
            processed_df = processed_df.withColumn(
                temp_col, 
                F.concat_ws(" ", F.col(f"{temp_col}_no_stopwords"))
            )
            # Drop the temporary column
            processed_df = processed_df.drop(f"{temp_col}_no_stopwords")
        
        # Move the result to the output column
        processed_df = processed_df.withColumn(self.output_column, F.col(temp_col))
        processed_df = processed_df.drop(temp_col)
        
        logger.info(f"Text preprocessing completed, output in column '{self.output_column}'")
        return processed_df
    
    # UDF creator functions
    def _create_clean_text_udf(self) -> F.udf:
        """Create UDF for basic text cleaning."""
        def clean_text(text):
            if text is None:
                return None
            
            # Replace line breaks with spaces
            text = text.replace('\n', ' ').replace('\r', ' ')
            
            # Handle punctuation if configured
            if self.remove_punctuation:
                text = text.translate(str.maketrans('', '', string.punctuation))
            
            return text
        
        return F.udf(clean_text, StringType())
    
    def _create_normalize_unicode_udf(self) -> F.udf:
        """Create UDF for Unicode normalization."""
        import unicodedata
        
        def normalize_unicode(text):
            if text is None:
                return None
            # Normalize to NFKD form and handle unicode
            return unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
        
        return F.udf(normalize_unicode, StringType())
    
    def _create_remove_html_tags_udf(self) -> F.udf:
        """Create UDF for removing HTML tags."""
        def remove_html_tags(text):
            if text is None:
                return None
            # Simple regex to remove HTML tags
            clean_text = re.sub(r'<.*?>', '', text)
            # Also handle HTML entities
            clean_text = re.sub(r'&[a-zA-Z]+;', ' ', clean_text)
            return clean_text
        
        return F.udf(remove_html_tags, StringType())
    
    def _create_remove_urls_udf(self) -> F.udf:
        """Create UDF for removing URLs."""
        def remove_urls(text):
            if text is None:
                return None
            # Regex to match URLs
            return re.sub(r'https?://\S+|www\.\S+', '', text)
        
        return F.udf(remove_urls, StringType())
    
    def _create_remove_extra_whitespace_udf(self) -> F.udf:
        """Create UDF for removing extra whitespace."""
        def remove_extra_whitespace(text):
            if text is None:
                return None
            # Replace multiple spaces with a single space
            return re.sub(r'\s+', ' ', text).strip()
        
        return F.udf(remove_extra_whitespace, StringType())
    
    def _create_remove_special_chars_udf(self) -> F.udf:
        """Create UDF for removing special characters."""
        def remove_special_chars(text):
            if text is None:
                return None
            # Keep only alphanumeric and whitespace
            return re.sub(r'[^a-zA-Z0-9\s]', '', text)
        
        return F.udf(remove_special_chars, StringType())
    
    def _create_expand_contractions_udf(self) -> F.udf:
        """Create UDF for expanding contractions."""
        # Common English contractions
        contractions = {
            "ain't": "am not",
            "aren't": "are not",
            "can't": "cannot",
            "couldn't": "could not",
            "didn't": "did not",
            "doesn't": "does not",
            "don't": "do not",
            "hadn't": "had not",
            "hasn't": "has not",
            "haven't": "have not",
            "he'd": "he would",
            "he'll": "he will",
            "he's": "he is",
            "i'd": "I would",
            "i'll": "I will",
            "i'm": "I am",
            "i've": "I have",
            "isn't": "is not",
            "it's": "it is",
            "let's": "let us",
            "mustn't": "must not",
            "shan't": "shall not",
            "she'd": "she would",
            "she'll": "she will",
            "she's": "she is",
            "shouldn't": "should not",
            "that's": "that is",
            "there's": "there is",
            "they'd": "they would",
            "they'll": "they will",
            "they're": "they are",
            "they've": "they have",
            "we'd": "we would",
            "we're": "we are",
            "we've": "we have",
            "weren't": "were not",
            "what'll": "what will",
            "what're": "what are",
            "what's": "what is",
            "what've": "what have",
            "where's": "where is",
            "who's": "who is",
            "who'll": "who will",
            "who're": "who are",
            "who've": "who have",
            "won't": "will not",
            "wouldn't": "would not",
            "you'd": "you would",
            "you'll": "you will",
            "you're": "you are",
            "you've": "you have"
        }
        
        def expand_contractions(text):
            if text is None:
                return None
            
            # Create a regex pattern for all contractions
            pattern = re.compile(r'\b({})\b'.format('|'.join(contractions.keys())), 
                                flags=re.IGNORECASE)
            
            def replace(match):
                match_text = match.group(0)
                if match_text.lower() in contractions:
                    return contractions[match_text.lower()]
                else:
                    return match_text
            
            # Apply the replacements
            return pattern.sub(replace, text)
        
        return F.udf(expand_contractions, StringType())
    
    def _create_remove_numbers_udf(self) -> F.udf:
        """Create UDF for removing numbers."""
        def remove_numbers(text):
            if text is None:
                return None
            # Replace digits with spaces
            return re.sub(r'\d+', '', text)
        
        return F.udf(remove_numbers, StringType()) 