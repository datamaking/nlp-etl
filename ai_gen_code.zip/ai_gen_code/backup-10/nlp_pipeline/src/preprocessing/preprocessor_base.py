"""
Base class for text preprocessors in the NLP Pipeline.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pyspark.sql import DataFrame

from ..exception import PreprocessingException
from ..logging_module import get_logger

logger = get_logger(__name__)

class Preprocessor(ABC):
    """
    Abstract base class for all preprocessors.
    
    Preprocessors are responsible for cleaning and normalizing text data
    before chunking and embedding.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the preprocessor.
        
        Args:
            config: Configuration dictionary for the preprocessor
        """
        self.config = config
        self.parameters = config.get("parameters", {})
        self.operations = config.get("operations", [])
        self.input_column = config.get("input_column", "text")
        self.output_column = config.get("output_column", "processed_text")
        
        # Validate configuration
        self._validate_config()
        
        logger.info(f"Initialized {self.__class__.__name__} with operations: {self.operations}")
    
    def _validate_config(self) -> None:
        """
        Validate the preprocessor configuration.
        
        Raises:
            PreprocessingException: If configuration is invalid
        """
        if not self.operations:
            logger.warning("No preprocessing operations specified")
        
        if not self.input_column:
            raise PreprocessingException("Input column must be specified")
        
        if not self.output_column:
            raise PreprocessingException("Output column must be specified")
        
        # Preprocessor-specific validation
        self._validate_preprocessor_config()
    
    def _validate_preprocessor_config(self) -> None:
        """
        Validate preprocessor-specific configuration.
        
        This method should be overridden by subclasses to provide
        preprocessor-specific validation.
        
        Raises:
            PreprocessingException: If configuration is invalid
        """
        pass
    
    @abstractmethod
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data using the configured preprocessing operations.
        
        Args:
            df: DataFrame containing the data to process
            
        Returns:
            DataFrame with processed data
            
        Raises:
            PreprocessingException: If processing fails
        """
        pass 