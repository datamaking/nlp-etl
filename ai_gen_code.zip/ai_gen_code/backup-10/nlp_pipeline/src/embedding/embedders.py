"""
Embedders implementation for the NLP Pipeline.
"""

import os
import importlib.util
from typing import Dict, Any, List, Optional, Union
import numpy as np

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType, FloatType, StringType

from .embedder_base import Embedder
from ..exception import EmbeddingException
from ..logging_module import get_logger

logger = get_logger(__name__)


class HuggingFaceEmbedder(Embedder):
    """
    Embedder using Hugging Face models.
    
    Supports various models from Hugging Face for generating text embeddings.
    """
    
    def _validate_embedder_config(self) -> None:
        """Validate Hugging Face embedder configuration."""
        # Check if required packages are installed
        if not importlib.util.find_spec("torch"):
            raise EmbeddingException("PyTorch is required for Hugging Face embeddings. Install with 'pip install torch'")
        
        if not importlib.util.find_spec("transformers"):
            raise EmbeddingException("Transformers is required for Hugging Face embeddings. Install with 'pip install transformers'")
        
        if not importlib.util.find_spec("sentence_transformers") and "sentence-transformers" in self.model:
            raise EmbeddingException("Sentence Transformers is required for this model. Install with 'pip install sentence-transformers'")
        
        # Get parameters
        self.max_tokens = self.parameters.get("max_tokens", 512)
        self.batch_size = self.parameters.get("batch_size", 8)
        self.normalize_embeddings = self.parameters.get("normalize_embeddings", True)
        
        # Validate parameters
        if not isinstance(self.max_tokens, int) or self.max_tokens <= 0:
            raise EmbeddingException("max_tokens must be a positive integer")
        
        if not isinstance(self.batch_size, int) or self.batch_size <= 0:
            raise EmbeddingException("batch_size must be a positive integer")
        
        # Log configuration
        logger.info(f"Initializing HuggingFace embedder with model: {self.model}")
        logger.info(f"Max tokens: {self.max_tokens}, Batch size: {self.batch_size}, Normalize: {self.normalize_embeddings}")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Generate embeddings using Hugging Face models.
        
        Args:
            df: DataFrame containing text to embed
            
        Returns:
            DataFrame with embeddings added
        """
        # Check if input column exists
        if self.input_column not in df.columns:
            raise EmbeddingException(f"Input column '{self.input_column}' not found in DataFrame")
        
        # Sample row to determine embedding dimension
        sample_text = df.select(self.input_column).limit(1).collect()
        if not sample_text or not sample_text[0][0]:
            logger.warning("Empty input dataframe or first row is empty")
            # Get embedding dimension from model directly
            try:
                embedding_dim = self._get_model_dimension()
                logger.info(f"Using embedding dimension {embedding_dim} from model specifications")
            except Exception as e:
                embedding_dim = 768  # Default for many HF models
                logger.warning(f"Could not determine embedding dimension: {str(e)}, using default: {embedding_dim}")
        else:
            # Get embedding dimension from a sample
            sample_embedding = self._embed_text(sample_text[0][0])
            embedding_dim = len(sample_embedding)
            logger.info(f"Embedding dimension: {embedding_dim}")
        
        # Register UDF for embedding
        @F.udf(returnType=ArrayType(FloatType()))
        def embed_text_udf(text):
            if not text:
                return [0.0] * embedding_dim
            
            try:
                return self._embed_text(text).tolist()
            except Exception as e:
                logger.error(f"Error generating embedding: {str(e)}")
                return [0.0] * embedding_dim
        
        # Apply UDF to generate embeddings
        logger.info(f"Generating embeddings for {df.count()} rows")
        df_with_embeddings = df.withColumn(self.output_column, embed_text_udf(F.col(self.input_column)))
        
        return df_with_embeddings
    
    def _get_model_dimension(self) -> int:
        """
        Get the embedding dimension from model specifications.
        
        Returns:
            Embedding dimension
        """
        # Use sentence-transformers if available
        if "sentence-transformers" in self.model or "sentence_transformers" in self.model:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer(self.model)
            return model.get_sentence_embedding_dimension()
        
        # For regular HF models
        from transformers import AutoModel, AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(self.model)
        model = AutoModel.from_pretrained(self.model)
        return model.config.hidden_size
    
    def _embed_text(self, text: str) -> np.ndarray:
        """
        Generate embedding for a single text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector as numpy array
        """
        # Check if using sentence-transformers
        if "sentence-transformers" in self.model or "sentence_transformers" in self.model:
            return self._embed_with_sentence_transformers(text)
        else:
            return self._embed_with_transformers(text)
    
    def _embed_with_sentence_transformers(self, text: str) -> np.ndarray:
        """
        Generate embedding using sentence-transformers.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        # Import here to avoid importing if not needed
        from sentence_transformers import SentenceTransformer
        
        # Load model lazily (only once)
        if not hasattr(self, '_st_model'):
            self._st_model = SentenceTransformer(self.model)
        
        # Generate embedding
        embedding = self._st_model.encode(
            text, 
            normalize_embeddings=self.normalize_embeddings,
            show_progress_bar=False
        )
        
        return embedding
    
    def _embed_with_transformers(self, text: str) -> np.ndarray:
        """
        Generate embedding using transformers.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        # Import here to avoid importing if not needed
        import torch
        from transformers import AutoTokenizer, AutoModel
        
        # Load model and tokenizer lazily (only once)
        if not hasattr(self, '_tokenizer') or not hasattr(self, '_model'):
            self._tokenizer = AutoTokenizer.from_pretrained(self.model)
            self._model = AutoModel.from_pretrained(self.model)
            
            # Move to GPU if available
            if torch.cuda.is_available():
                self._model = self._model.to('cuda')
        
        # Tokenize text
        inputs = self._tokenizer(
            text,
            return_tensors="pt",
            max_length=self.max_tokens,
            padding=True,
            truncation=True
        )
        
        # Move to GPU if available
        if torch.cuda.is_available():
            inputs = {k: v.to('cuda') for k, v in inputs.items()}
        
        # Generate embedding
        with torch.no_grad():
            outputs = self._model(**inputs)
        
        # Use mean of last hidden states as embedding
        embedding = outputs.last_hidden_state.mean(dim=1).squeeze().cpu().numpy()
        
        # Normalize if requested
        if self.normalize_embeddings:
            embedding = embedding / np.linalg.norm(embedding)
        
        return embedding
    
    def close(self) -> None:
        """Release resources used by the embedder."""
        # Clear model attributes to free memory
        if hasattr(self, '_st_model'):
            del self._st_model
        
        if hasattr(self, '_model'):
            del self._model
        
        if hasattr(self, '_tokenizer'):
            del self._tokenizer
        
        logger.info("HuggingFace embedder resources released")


class OpenAIEmbedder(Embedder):
    """
    Embedder using OpenAI API.
    
    Generates embeddings using OpenAI's embedding models.
    """
    
    def _validate_embedder_config(self) -> None:
        """Validate OpenAI embedder configuration."""
        # Check if required packages are installed
        if not importlib.util.find_spec("openai"):
            raise EmbeddingException("OpenAI is required for OpenAI embeddings. Install with 'pip install openai'")
        
        # Check for API key
        self.api_key = self.parameters.get("api_key") or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            raise EmbeddingException("OpenAI API key must be provided in parameters or as OPENAI_API_KEY environment variable")
        
        # Get parameters
        self.batch_size = self.parameters.get("batch_size", 20)
        self.max_tokens = self.parameters.get("max_tokens", 8191)
        self.retry_attempts = self.parameters.get("retry_attempts", 3)
        
        # Validate parameters
        if not isinstance(self.batch_size, int) or self.batch_size <= 0:
            raise EmbeddingException("batch_size must be a positive integer")
        
        if not isinstance(self.max_tokens, int) or self.max_tokens <= 0:
            raise EmbeddingException("max_tokens must be a positive integer")
        
        # Check valid model (text-embedding-ada-002 is deprecated)
        valid_models = ["text-embedding-3-small", "text-embedding-3-large", "text-embedding-ada-002"]
        if self.model not in valid_models:
            logger.warning(f"Model {self.model} may not be supported by OpenAI. Supported models: {', '.join(valid_models)}")
        
        # Log configuration
        logger.info(f"Initializing OpenAI embedder with model: {self.model}")
        logger.info(f"Batch size: {self.batch_size}, Max tokens: {self.max_tokens}")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Generate embeddings using OpenAI API.
        
        Args:
            df: DataFrame containing text to embed
            
        Returns:
            DataFrame with embeddings added
        """
        # Check if input column exists
        if self.input_column not in df.columns:
            raise EmbeddingException(f"Input column '{self.input_column}' not found in DataFrame")
        
        # Get embedding dimension based on model
        if self.model == "text-embedding-ada-002":
            embedding_dim = 1536
        elif self.model == "text-embedding-3-small":
            embedding_dim = 1536
        elif self.model == "text-embedding-3-large":
            embedding_dim = 3072
        else:
            # Sample row to determine embedding dimension
            sample_text = df.select(self.input_column).limit(1).collect()
            if not sample_text or not sample_text[0][0]:
                embedding_dim = 1536  # Default for OpenAI embeddings
                logger.warning(f"Could not determine embedding dimension, using default: {embedding_dim}")
            else:
                # Get embedding dimension from a sample
                sample_embedding = self._embed_text(sample_text[0][0])
                embedding_dim = len(sample_embedding)
            
        logger.info(f"Using embedding dimension: {embedding_dim}")
        
        # Import OpenAI here to avoid issues if not installed
        try:
            from openai import OpenAI
            client = OpenAI(api_key=self.api_key)
        except ImportError:
            raise EmbeddingException("Could not import OpenAI module")
        
        # Register UDF for embedding
        @F.udf(returnType=ArrayType(FloatType()))
        def embed_text_udf(text):
            if not text:
                return [0.0] * embedding_dim
            
            try:
                return self._embed_text(text).tolist()
            except Exception as e:
                logger.error(f"Error generating embedding: {str(e)}")
                return [0.0] * embedding_dim
        
        # Apply UDF to generate embeddings
        logger.info(f"Generating embeddings for {df.count()} rows")
        df_with_embeddings = df.withColumn(self.output_column, embed_text_udf(F.col(self.input_column)))
        
        return df_with_embeddings
    
    def _embed_text(self, text: str) -> np.ndarray:
        """
        Generate embedding for a single text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector as numpy array
        """
        from openai import OpenAI
        import time
        
        # Initialize client if not already done
        if not hasattr(self, '_client'):
            self._client = OpenAI(api_key=self.api_key)
        
        # Truncate text if needed
        if len(text) > self.max_tokens * 4:  # Rough approximation of token count
            text = text[:self.max_tokens * 4]
            logger.warning("Text truncated to fit within token limit")
        
        # Retry logic
        for attempt in range(self.retry_attempts):
            try:
                response = self._client.embeddings.create(
                    model=self.model,
                    input=text,
                    encoding_format="float"
                )
                
                # Extract embedding
                embedding = np.array(response.data[0].embedding)
                return embedding
            
            except Exception as e:
                logger.warning(f"Embedding attempt {attempt+1} failed: {str(e)}")
                
                if attempt < self.retry_attempts - 1:
                    # Exponential backoff
                    sleep_time = 2 ** attempt
                    logger.info(f"Retrying in {sleep_time} seconds...")
                    time.sleep(sleep_time)
                else:
                    # Last attempt failed
                    logger.error(f"Failed to generate embedding after {self.retry_attempts} attempts")
                    raise EmbeddingException(f"OpenAI embedding failed: {str(e)}")
        
        # This should never happen due to the exception in the loop
        raise EmbeddingException("Unexpected error in embedding generation")


class TensorflowEmbedder(Embedder):
    """
    Embedder using TensorFlow models.
    
    Generates embeddings using TensorFlow Hub models or custom TensorFlow models.
    """
    
    def _validate_embedder_config(self) -> None:
        """Validate TensorFlow embedder configuration."""
        # Check if required packages are installed
        if not importlib.util.find_spec("tensorflow"):
            raise EmbeddingException("TensorFlow is required for TF embeddings. Install with 'pip install tensorflow'")
        
        if "hub.tensorflow.google" in self.model and not importlib.util.find_spec("tensorflow_hub"):
            raise EmbeddingException("TensorFlow Hub is required for this model. Install with 'pip install tensorflow-hub'")
        
        # Get parameters
        self.batch_size = self.parameters.get("batch_size", 32)
        self.max_tokens = self.parameters.get("max_tokens", 512)
        self.use_preprocessing = self.parameters.get("use_preprocessing", True)
        
        # Validate parameters
        if not isinstance(self.batch_size, int) or self.batch_size <= 0:
            raise EmbeddingException("batch_size must be a positive integer")
        
        if not isinstance(self.max_tokens, int) or self.max_tokens <= 0:
            raise EmbeddingException("max_tokens must be a positive integer")
        
        # Log configuration
        logger.info(f"Initializing TensorFlow embedder with model: {self.model}")
        logger.info(f"Batch size: {self.batch_size}, Max tokens: {self.max_tokens}")
    
    def process(self, df: DataFrame) -> DataFrame:
        """
        Generate embeddings using TensorFlow models.
        
        Args:
            df: DataFrame containing text to embed
            
        Returns:
            DataFrame with embeddings added
        """
        # Check if input column exists
        if self.input_column not in df.columns:
            raise EmbeddingException(f"Input column '{self.input_column}' not found in DataFrame")
        
        # Sample row to determine embedding dimension
        sample_text = df.select(self.input_column).limit(1).collect()
        if not sample_text or not sample_text[0][0]:
            logger.warning("Empty input dataframe or first row is empty")
            # Get embedding dimension from model directly
            try:
                embedding_dim = self._get_model_dimension()
                logger.info(f"Using embedding dimension {embedding_dim} from model specifications")
            except Exception as e:
                embedding_dim = 512  # Default for many TF models
                logger.warning(f"Could not determine embedding dimension: {str(e)}, using default: {embedding_dim}")
        else:
            # Get embedding dimension from a sample
            sample_embedding = self._embed_text(sample_text[0][0])
            embedding_dim = len(sample_embedding)
            logger.info(f"Embedding dimension: {embedding_dim}")
        
        # Register UDF for embedding
        @F.udf(returnType=ArrayType(FloatType()))
        def embed_text_udf(text):
            if not text:
                return [0.0] * embedding_dim
            
            try:
                return self._embed_text(text).tolist()
            except Exception as e:
                logger.error(f"Error generating embedding: {str(e)}")
                return [0.0] * embedding_dim
        
        # Apply UDF to generate embeddings
        logger.info(f"Generating embeddings for {df.count()} rows")
        df_with_embeddings = df.withColumn(self.output_column, embed_text_udf(F.col(self.input_column)))
        
        return df_with_embeddings
    
    def _get_model_dimension(self) -> int:
        """
        Get the embedding dimension from model specifications.
        
        Returns:
            Embedding dimension
        """
        import tensorflow as tf
        
        # For TensorFlow Hub models
        if "hub.tensorflow.google" in self.model:
            import tensorflow_hub as hub
            model = hub.load(self.model)
            
            # Try to get signature information
            try:
                sig = model.signatures["default"]
                output_shape = sig.structured_outputs["default"].shape
                return output_shape[1]
            except:
                # Fallback: Test with a dummy input
                dummy_result = model(tf.constant(["test"]))
                return dummy_result.shape[1]
        
        # For local TensorFlow models
        try:
            model = tf.saved_model.load(self.model)
            dummy_result = model(tf.constant(["test"]))
            return dummy_result.shape[1]
        except:
            # Cannot determine, use default
            return 512
    
    def _embed_text(self, text: str) -> np.ndarray:
        """
        Generate embedding for a single text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector as numpy array
        """
        import tensorflow as tf
        
        # Load model lazily (only once)
        if not hasattr(self, '_model'):
            # TensorFlow Hub model
            if "hub.tensorflow.google" in self.model:
                import tensorflow_hub as hub
                self._model = hub.load(self.model)
            # Local TensorFlow model
            else:
                self._model = tf.saved_model.load(self.model)
        
        # Preprocess text if needed
        if self.use_preprocessing:
            # Simple preprocessing for TF models
            text = text.lower()
            text = ' '.join(text.split()[:self.max_tokens])  # Simple token limiting
        
        # Convert to tensor
        input_tensor = tf.constant([text])
        
        # Generate embedding
        embedding = self._model(input_tensor)
        
        # Convert to numpy array
        if isinstance(embedding, dict):
            # Some models return dictionaries
            if "default" in embedding:
                embedding = embedding["default"]
            elif "embedding" in embedding:
                embedding = embedding["embedding"]
            else:
                # Take the first item
                embedding = list(embedding.values())[0]
        
        # Extract the first (only) embedding and ensure it's a 1D array
        embedding = embedding.numpy()[0]
        
        return embedding
    
    def close(self) -> None:
        """Release resources used by the embedder."""
        # Clear model attributes to free memory
        if hasattr(self, '_model'):
            del self._model
        
        logger.info("TensorFlow embedder resources released")
