"""
Embedding module for NLP Pipeline.
Handles text embedding using various models and strategies.
"""

from typing import Dict, Any

from .embedder_base import Embedder
from .embedders import HuggingFaceEmbedder, OpenAIEmbedder, TensorflowEmbedder

def create_embedder(config: Dict[str, Any]) -> Embedder:
    """
    Create an embedder based on configuration.
    
    Args:
        config: Embedder configuration
        
    Returns:
        Embedder instance
    
    Raises:
        ValueError: If embedder type is not supported
    """
    embedder_type = config.get("type", "").lower()
    
    if embedder_type == "huggingface":
        return HuggingFaceEmbedder(config)
    elif embedder_type == "openai":
        return OpenAIEmbedder(config)
    elif embedder_type == "tensorflow":
        return TensorflowEmbedder(config)
    else:
        raise ValueError(f"Unsupported embedder type: {embedder_type}")

__all__ = [
    'Embedder',
    'HuggingFaceEmbedder',
    'OpenAIEmbedder',
    'TensorflowEmbedder',
    'create_embedder'
] 