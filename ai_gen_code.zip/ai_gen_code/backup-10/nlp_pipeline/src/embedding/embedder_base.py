"""
Base class for text embedders in the NLP Pipeline.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pyspark.sql import DataFrame

from ..exception import EmbeddingException
from ..logging_module import get_logger

logger = get_logger(__name__)

class Embedder(ABC):
    """
    Abstract base class for all embedders.
    
    Embedders are responsible for generating vector representations (embeddings)
    of text chunks that can be stored in vector databases.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the embedder.
        
        Args:
            config: Configuration dictionary for the embedder
        """
        self.config = config
        self.parameters = config.get("parameters", {})
        self.model = config.get("model")
        self.input_column = config.get("input_column", "chunk_text")
        self.output_column = config.get("output_column", "embedding")
        
        # Validate configuration
        self._validate_config()
        
        logger.info(f"Initialized {self.__class__.__name__} with model: {self.model}")
    
    def _validate_config(self) -> None:
        """
        Validate the embedder configuration.
        
        Raises:
            EmbeddingException: If configuration is invalid
        """
        if not self.model:
            raise EmbeddingException("Embedding model must be specified")
        
        if not self.input_column:
            raise EmbeddingException("Input column must be specified")
        
        if not self.output_column:
            raise EmbeddingException("Output column must be specified")
        
        # Embedder-specific validation
        self._validate_embedder_config()
    
    def _validate_embedder_config(self) -> None:
        """
        Validate embedder-specific configuration.
        
        This method should be overridden by subclasses to provide
        embedder-specific validation.
        
        Raises:
            EmbeddingException: If configuration is invalid
        """
        pass
    
    @abstractmethod
    def process(self, df: DataFrame) -> DataFrame:
        """
        Process data by generating embeddings.
        
        Args:
            df: DataFrame containing the data to process
            
        Returns:
            DataFrame with embeddings
            
        Raises:
            EmbeddingException: If processing fails
        """
        pass
    
    def close(self) -> None:
        """
        Close any resources used by the embedder.
        
        Override this method if the embedder needs to clean up resources.
        """
        pass 