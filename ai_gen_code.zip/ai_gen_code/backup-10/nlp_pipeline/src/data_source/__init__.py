"""
Data source module for NLP Pipeline.
Provides classes for reading data from various sources.
"""

from typing import Dict, Any
from pyspark.sql import SparkSession

from .data_source_base import DataSource
from .file_sources import CSVSource, JSONSource, TextFileSource, ParquetSource, PDFSource
from .database_sources import SQLSource, MongoSource

def create_source(config: Dict[str, Any], spark: SparkSession) -> DataSource:
    """
    Create a data source based on configuration.
    
    Args:
        config: Data source configuration
        spark: Spark session
        
    Returns:
        DataSource instance
    
    Raises:
        ValueError: If source type is not supported
    """
    source_type = config.get("type", "").lower()
    
    if source_type == "csv":
        return CSVSource(config, spark)
    elif source_type == "json" or source_type == "jsonl":
        return JSONSource(config, spark)
    elif source_type == "text_files":
        return TextFileSource(config, spark)
    elif source_type == "parquet":
        return ParquetSource(config, spark)
    elif source_type == "pdf":
        return PDFSource(config, spark)
    elif source_type == "sql" or source_type == "jdbc":
        return SQLSource(config, spark)
    elif source_type == "mongo":
        return MongoSource(config, spark)
    else:
        raise ValueError(f"Unsupported data source type: {source_type}")

__all__ = [
    'DataSource',
    'CSVSource',
    'JSONSource',
    'TextFileSource',
    'ParquetSource',
    'PDFSource',
    'SQLSource',
    'MongoSource',
    'create_source'
] 