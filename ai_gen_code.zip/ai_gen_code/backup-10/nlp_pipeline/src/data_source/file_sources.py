"""
File-based data source implementations for the NLP Pipeline.
"""

import os
import glob
from typing import Dict, Any, List

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType

from .data_source_base import DataSource
from ..exception import DataSourceException
from ..logging_module import get_logger

logger = get_logger(__name__)


class TextFileSource(DataSource):
    """
    Data source for reading text files.
    Supports reading from directories with glob patterns.
    """
    
    def _validate_source_config(self) -> None:
        """Validate text file source configuration."""
        if "path" not in self.parameters:
            raise DataSourceException("Path must be specified for text file source")
    
    def read_data(self) -> DataFrame:
        """
        Read text files from the specified path.
        
        Returns:
            DataFrame with text content and metadata
        """
        path = self.parameters.get("path")
        recursive = self.parameters.get("recursive", False)
        file_pattern = self.parameters.get("file_pattern", "*")
        
        logger.info(f"Reading text files from {path} with pattern {file_pattern}")
        
        # Get list of files
        if recursive:
            file_search_path = os.path.join(path, "**", file_pattern)
            files = glob.glob(file_search_path, recursive=True)
        else:
            file_search_path = os.path.join(path, file_pattern)
            files = glob.glob(file_search_path, recursive=False)
        
        # Check if files were found
        if not files:
            logger.warning(f"No files found at {file_search_path}")
            
            # Return empty DataFrame with expected schema
            schema = StructType([
                StructField(self.id_column, StringType(), False),
                StructField(self.text_column, StringType(), True),
                StructField("filename", StringType(), True),
                StructField("filepath", StringType(), True),
                StructField("file_size", IntegerType(), True),
                StructField("last_modified", TimestampType(), True)
            ])
            
            return self.spark.createDataFrame([], schema)
        
        logger.info(f"Found {len(files)} files")
        
        # Read files as a single text column DataFrame
        df = self.spark.read.text(files, wholetext=True)
        
        # Add filename as a column
        df = df.withColumn("filepath", F.input_file_name())
        
        # Extract filename from path
        df = df.withColumn("filename", F.element_at(F.split(F.col("filepath"), "/"), -1))
        
        # Get file metadata
        df = df.withColumn("file_size", F.lit(None).cast(IntegerType()))
        df = df.withColumn("last_modified", F.lit(None).cast(TimestampType()))
        
        # Generate document IDs
        df = df.withColumn(self.id_column, 
                           F.concat(F.lit("doc_"), F.monotonically_increasing_id()))
        
        # Rename the default column 'value' to the configured text column
        df = df.withColumnRenamed("value", self.text_column)
        
        # Update file metadata using UDF if available metadata columns
        if "file_size" in self.metadata_columns or "last_modified" in self.metadata_columns:
            @F.udf(returnType=StructType([
                StructField("file_size", IntegerType(), True),
                StructField("last_modified", TimestampType(), True)
            ]))
            def get_file_metadata(filepath):
                try:
                    stats = os.stat(filepath)
                    return (stats.st_size, F.to_timestamp(stats.st_mtime))
                except Exception:
                    return (None, None)
            
            metadata_df = df.withColumn("metadata", get_file_metadata(F.col("filepath")))
            df = metadata_df.withColumn("file_size", F.col("metadata.file_size")) \
                          .withColumn("last_modified", F.col("metadata.last_modified")) \
                          .drop("metadata")
        
        logger.info(f"Loaded {df.count()} documents")
        return df


class PDFSource(DataSource):
    """
    Data source for reading PDF files.
    """
    
    def _validate_source_config(self) -> None:
        """Validate PDF source configuration."""
        if "path" not in self.parameters:
            raise DataSourceException("Path must be specified for PDF source")
        
        # Check if required packages are installed
        try:
            import importlib
            if not importlib.util.find_spec("pyspark.ml"):
                raise DataSourceException("PySpark ML library is required for PDF extraction")
            
            if not importlib.util.find_spec("pdf2image"):
                raise DataSourceException("pdf2image package is required for PDF extraction")
            
            if not importlib.util.find_spec("pytesseract"):
                raise DataSourceException("pytesseract package is required for PDF extraction")
        except ImportError:
            raise DataSourceException("Required packages not found for PDF extraction")
    
    def read_data(self) -> DataFrame:
        """
        Read PDF files from the specified path.
        
        Returns:
            DataFrame with text content and metadata
        """
        # Similar to TextFileSource but with PDF processing logic
        path = self.parameters.get("path")
        recursive = self.parameters.get("recursive", False)
        file_pattern = self.parameters.get("file_pattern", "*.pdf")
        
        logger.info(f"Reading PDF files from {path} with pattern {file_pattern}")
        
        # Get list of files
        if recursive:
            file_search_path = os.path.join(path, "**", file_pattern)
            files = glob.glob(file_search_path, recursive=True)
        else:
            file_search_path = os.path.join(path, file_pattern)
            files = glob.glob(file_search_path, recursive=False)
        
        # Check if files were found
        if not files:
            logger.warning(f"No PDF files found at {file_search_path}")
            
            # Return empty DataFrame with expected schema
            schema = StructType([
                StructField(self.id_column, StringType(), False),
                StructField(self.text_column, StringType(), True),
                StructField("filename", StringType(), True),
                StructField("filepath", StringType(), True),
                StructField("file_size", IntegerType(), True),
                StructField("last_modified", TimestampType(), True),
                StructField("page_number", IntegerType(), True),
                StructField("total_pages", IntegerType(), True)
            ])
            
            return self.spark.createDataFrame([], schema)
        
        logger.info(f"Found {len(files)} PDF files")
        
        # Create DataFrame with file paths
        filepath_df = self.spark.createDataFrame([(f,) for f in files], ["filepath"])
        
        # Extract text from PDFs using a UDF
        @F.udf(returnType=StructType([
            StructField("text", StringType(), True),
            StructField("page_number", IntegerType(), True),
            StructField("total_pages", IntegerType(), True)
        ]))
        def extract_pdf_text(filepath):
            try:
                import PyPDF2
                
                with open(filepath, "rb") as pdf_file:
                    pdf_reader = PyPDF2.PdfReader(pdf_file)
                    total_pages = len(pdf_reader.pages)
                    pages = []
                    
                    for page_num, page in enumerate(pdf_reader.pages):
                        text = page.extract_text()
                        pages.append((text, page_num + 1, total_pages))
                    
                    return pages
            except Exception as e:
                logger.error(f"Error extracting text from PDF {filepath}: {str(e)}")
                return []
        
        # Apply UDF and explode results
        pdf_df = filepath_df.withColumn("pdf_data", extract_pdf_text(F.col("filepath")))
        pdf_df = pdf_df.select(
            "filepath",
            F.explode("pdf_data").alias("pdf_data")
        )
        
        # Extract columns from struct
        df = pdf_df.select(
            "filepath",
            F.col("pdf_data.text").alias(self.text_column),
            F.col("pdf_data.page_number").alias("page_number"),
            F.col("pdf_data.total_pages").alias("total_pages")
        )
        
        # Extract filename from path
        df = df.withColumn("filename", F.element_at(F.split(F.col("filepath"), "/"), -1))
        
        # Generate document IDs
        df = df.withColumn(self.id_column, 
                           F.concat(F.lit("pdf_"), 
                                   F.col("filename"), 
                                   F.lit("_p"), 
                                   F.col("page_number")))
        
        # Add file metadata
        if "file_size" in self.metadata_columns or "last_modified" in self.metadata_columns:
            @F.udf(returnType=StructType([
                StructField("file_size", IntegerType(), True),
                StructField("last_modified", TimestampType(), True)
            ]))
            def get_file_metadata(filepath):
                try:
                    stats = os.stat(filepath)
                    return (stats.st_size, F.to_timestamp(stats.st_mtime))
                except Exception:
                    return (None, None)
            
            metadata_df = df.withColumn("metadata", get_file_metadata(F.col("filepath")))
            df = metadata_df.withColumn("file_size", F.col("metadata.file_size")) \
                          .withColumn("last_modified", F.col("metadata.last_modified")) \
                          .drop("metadata")
        else:
            df = df.withColumn("file_size", F.lit(None).cast(IntegerType()))
            df = df.withColumn("last_modified", F.lit(None).cast(TimestampType()))
        
        logger.info(f"Loaded {df.count()} pages from PDF documents")
        return df


class CSVSource(DataSource):
    """
    Data source for reading CSV files.
    """
    
    def _validate_source_config(self) -> None:
        """Validate CSV source configuration."""
        if "path" not in self.parameters:
            raise DataSourceException("Path must be specified for CSV source")
    
    def read_data(self) -> DataFrame:
        """
        Read CSV files from the specified path.
        
        Returns:
            DataFrame with CSV content
        """
        path = self.parameters.get("path")
        header = self.parameters.get("header", True)
        delimiter = self.parameters.get("delimiter", ",")
        
        logger.info(f"Reading CSV files from {path}")
        
        # Read CSV files
        df = self.spark.read.option("header", str(header).lower()) \
                            .option("delimiter", delimiter) \
                            .option("inferSchema", "true") \
                            .csv(path)
        
        # Validate text column exists
        if self.text_column not in df.columns:
            raise DataSourceException(f"Text column '{self.text_column}' not found in CSV")
        
        # Generate ID column if it doesn't exist
        if self.id_column not in df.columns:
            df = df.withColumn(self.id_column, 
                               F.concat(F.lit("row_"), F.monotonically_increasing_id()))
        
        # Add metadata
        df = df.withColumn("filepath", F.input_file_name())
        df = df.withColumn("filename", F.element_at(F.split(F.col("filepath"), "/"), -1))
        
        logger.info(f"Loaded {df.count()} rows from CSV")
        return df


class ParquetSource(DataSource):
    """
    Data source for reading Parquet files.
    """
    
    def _validate_source_config(self) -> None:
        """Validate Parquet source configuration."""
        if "path" not in self.parameters:
            raise DataSourceException("Path must be specified for Parquet source")
    
    def read_data(self) -> DataFrame:
        """
        Read Parquet files from the specified path.
        
        Returns:
            DataFrame with Parquet content
        """
        path = self.parameters.get("path")
        
        logger.info(f"Reading Parquet files from {path}")
        
        # Read Parquet files
        df = self.spark.read.parquet(path)
        
        # Validate text column exists
        if self.text_column not in df.columns:
            raise DataSourceException(f"Text column '{self.text_column}' not found in Parquet")
        
        # Generate ID column if it doesn't exist
        if self.id_column not in df.columns:
            df = df.withColumn(self.id_column, 
                               F.concat(F.lit("row_"), F.monotonically_increasing_id()))
        
        logger.info(f"Loaded {df.count()} rows from Parquet")
        return df


class JSONSource(DataSource):
    """
    Data source for reading JSON files.
    """
    
    def _validate_source_config(self) -> None:
        """Validate JSON source configuration."""
        if "path" not in self.parameters:
            raise DataSourceException("Path must be specified for JSON source")
    
    def read_data(self) -> DataFrame:
        """
        Read JSON files from the specified path.
        
        Returns:
            DataFrame with JSON content
        """
        path = self.parameters.get("path")
        multiline = self.parameters.get("multiline", False)
        
        logger.info(f"Reading JSON files from {path}")
        
        # Read JSON files
        df = self.spark.read.option("multiline", str(multiline).lower()).json(path)
        
        # Validate text column exists
        if self.text_column not in df.columns:
            raise DataSourceException(f"Text column '{self.text_column}' not found in JSON")
        
        # Generate ID column if it doesn't exist
        if self.id_column not in df.columns:
            df = df.withColumn(self.id_column, 
                               F.concat(F.lit("row_"), F.monotonically_increasing_id()))
        
        # Add metadata
        df = df.withColumn("filepath", F.input_file_name())
        df = df.withColumn("filename", F.element_at(F.split(F.col("filepath"), "/"), -1))
        
        logger.info(f"Loaded {df.count()} rows from JSON")
        return df 