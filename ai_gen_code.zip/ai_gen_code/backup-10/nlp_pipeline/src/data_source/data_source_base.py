"""
Base class for data sources in the NLP Pipeline.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from pyspark.sql import SparkSession, DataFrame

from ..exception import DataSourceException
from ..logging_module import get_logger

logger = get_logger(__name__)

class DataSource(ABC):
    """
    Abstract base class for all data sources.
    
    Data sources are responsible for reading data from various sources
    and returning it as a Spark DataFrame.
    """
    
    def __init__(self, config: Dict[str, Any], spark: SparkSession):
        """
        Initialize the data source.
        
        Args:
            config: Configuration dictionary for the data source
            spark: Spark session
        """
        self.config = config
        self.spark = spark
        self.parameters = config.get("parameters", {})
        self.text_column = config.get("text_column", "text")
        self.id_column = config.get("id_column", "id")
        self.metadata_columns = config.get("metadata_columns", [])
        
        # Validate configuration
        self._validate_config()
        
        logger.info(f"Initialized {self.__class__.__name__}")
    
    def _validate_config(self) -> None:
        """
        Validate the data source configuration.
        
        Raises:
            DataSourceException: If configuration is invalid
        """
        # Common validation for all data sources
        if not self.text_column:
            raise DataSourceException("Text column must be specified")
        
        if not self.id_column:
            raise DataSourceException("ID column must be specified")
        
        # Source-specific validation
        self._validate_source_config()
    
    def _validate_source_config(self) -> None:
        """
        Validate source-specific configuration.
        
        This method should be overridden by subclasses to provide
        source-specific validation.
        
        Raises:
            DataSourceException: If configuration is invalid
        """
        pass
    
    @abstractmethod
    def read_data(self) -> DataFrame:
        """
        Read data from the source.
        
        Returns:
            DataFrame containing the data
            
        Raises:
            DataSourceException: If reading data fails
        """
        pass
    
    def close(self) -> None:
        """
        Close any resources used by the data source.
        
        Override this method if the data source needs to clean up resources.
        """
        pass 