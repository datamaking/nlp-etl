"""
Unit tests for chunking components.
"""

import unittest
from unittest.mock import patch, MagicMock, call

import pytest
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import ArrayType, StringType, StructType, StructField

from src.chunking.chunkers import (
    RecursiveChunker, 
    SentenceChunker, 
    ParagraphChunker
)
from src.exception import ChunkingException


class TestChunker(unittest.TestCase):
    """Base test class for chunkers."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-chunker") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        cls.spark.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for chunking."""
        data = [
            {"id": "1", "text": "This is a test paragraph. It has multiple sentences. We want to split it into chunks."},
            {"id": "2", "text": "Another paragraph with some text. This one is also multi-sentence. But it's shorter."},
            {"id": "3", "text": "A very short text."}
        ]
        return self.spark.createDataFrame(data)


class TestRecursiveChunker(TestChunker):
    """Test the RecursiveChunker class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "chunk_size": 100,
                "chunk_overlap": 20,
                "min_chunk_size": 50,
                "separators": ["\n\n", "\n", ". ", ", ", " "]
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        self.chunker = RecursiveChunker(self.config)
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.chunker._validate_chunker_config()
        
        # Test missing parameters
        invalid_config = {
            "parameters": {},
            "text_column": "text",
            "id_column": "id"
        }
        
        with self.assertRaises(ChunkingException):
            RecursiveChunker(invalid_config)
    
    def test_recursive_chunk(self):
        """Test the recursive chunking algorithm."""
        text = "This is a test paragraph. It has multiple sentences. We want to split it into chunks."
        
        # Test with small chunk size to force splitting
        self.chunker.chunk_size = 20
        self.chunker.min_chunk_size = 10
        chunks = self.chunker._recursive_chunk(text, self.chunker.separators)
        
        # Check results
        self.assertIsNotNone(chunks)
        self.assertIsInstance(chunks, list)
        self.assertTrue(len(chunks) > 1)
        
        # Check that chunks are smaller than chunk_size
        for chunk in chunks:
            self.assertTrue(len(chunk) <= self.chunker.chunk_size or 
                           len(chunk) >= self.chunker.min_chunk_size)
    
    @patch('pyspark.sql.functions.udf')
    def test_process(self, mock_udf):
        """Test the process method with mocks."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Mock the withColumn and select methods
        mock_withcolumn = MagicMock()
        mock_select = MagicMock()
        
        df.withColumn = MagicMock(return_value=mock_withcolumn)
        mock_withcolumn.select = MagicMock(return_value=mock_select)
        
        # Call the process method
        result_df = self.chunker.process(df)
        
        # Verify the calls
        df.withColumn.assert_called_once()
        mock_withcolumn.select.assert_called_once()
        
        # Check that the UDF was created
        mock_udf.assert_called_once()
    
    def test_process_integration(self):
        """Integration test for the process method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Set smaller chunk size to ensure chunking occurs
        self.chunker.chunk_size = 20
        self.chunker.min_chunk_size = 10
        
        # Process the dataframe
        result_df = self.chunker.process(df)
        
        # Check the result
        self.assertIsNotNone(result_df)
        self.assertTrue(result_df.count() >= df.count())
        self.assertTrue("chunk_id" in result_df.columns)
        self.assertTrue("chunk_text" in result_df.columns)
        self.assertTrue("chunk_index" in result_df.columns)


class TestSentenceChunker(TestChunker):
    """Test the SentenceChunker class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "chunk_size": 2,  # Number of sentences per chunk
                "chunk_overlap": 1,
                "min_chunk_size": 1
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        self.chunker = SentenceChunker(self.config)
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.chunker._validate_chunker_config()
        
        # Test missing parameters
        invalid_config = {
            "parameters": {},
            "text_column": "text",
            "id_column": "id"
        }
        
        with self.assertRaises(ChunkingException):
            SentenceChunker(invalid_config)
    
    @patch('pyspark.sql.functions.udf')
    def test_process(self, mock_udf):
        """Test the process method with mocks."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Mock the withColumn and select methods
        mock_withcolumn = MagicMock()
        mock_select = MagicMock()
        
        df.withColumn = MagicMock(return_value=mock_withcolumn)
        mock_withcolumn.select = MagicMock(return_value=mock_select)
        
        # Call the process method
        result_df = self.chunker.process(df)
        
        # Verify the calls
        df.withColumn.assert_called_once()
        mock_withcolumn.select.assert_called_once()
        
        # Check that the UDF was created
        mock_udf.assert_called_once()
    
    def test_process_integration(self):
        """Integration test for the process method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Process the dataframe
        result_df = self.chunker.process(df)
        
        # Check the result
        self.assertIsNotNone(result_df)
        self.assertTrue(result_df.count() >= df.count())
        self.assertTrue("chunk_id" in result_df.columns)
        self.assertTrue("chunk_text" in result_df.columns)
        self.assertTrue("chunk_index" in result_df.columns)
        
        # Since each text has 3 sentences and chunk_size=2 with overlap=1,
        # we expect more chunks than original rows
        rows = result_df.collect()
        self.assertTrue(len(rows) >= 3)


class TestParagraphChunker(TestChunker):
    """Test the ParagraphChunker class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "min_size": 10,
                "max_size": 200,
                "separator": "\n\n"
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        self.chunker = ParagraphChunker(self.config)
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.chunker._validate_chunker_config()
        
        # Test missing parameters
        invalid_config = {
            "parameters": {
                "min_size": 10
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        with self.assertRaises(ChunkingException):
            ParagraphChunker(invalid_config)
    
    @patch('pyspark.sql.functions.udf')
    def test_process(self, mock_udf):
        """Test the process method with mocks."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Mock the withColumn and select methods
        mock_withcolumn = MagicMock()
        mock_select = MagicMock()
        
        df.withColumn = MagicMock(return_value=mock_withcolumn)
        mock_withcolumn.select = MagicMock(return_value=mock_select)
        
        # Call the process method
        result_df = self.chunker.process(df)
        
        # Verify the calls
        df.withColumn.assert_called_once()
        mock_withcolumn.select.assert_called_once()
        
        # Check that the UDF was created
        mock_udf.assert_called_once()
    
    def test_process_integration(self):
        """Integration test for the process method."""
        # Create a test dataframe with multi-paragraph text
        data = [
            {"id": "1", "text": "Paragraph 1.\n\nParagraph 2.\n\nParagraph 3."},
            {"id": "2", "text": "Single paragraph."}
        ]
        df = self.spark.createDataFrame(data)
        
        # Process the dataframe
        result_df = self.chunker.process(df)
        
        # Check the result
        self.assertIsNotNone(result_df)
        self.assertTrue(result_df.count() >= df.count())
        self.assertTrue("chunk_id" in result_df.columns)
        self.assertTrue("chunk_text" in result_df.columns)
        self.assertTrue("chunk_index" in result_df.columns)
        
        # The first text has 3 paragraphs, the second has 1
        rows = result_df.collect()
        self.assertTrue(len(rows) >= 4)


if __name__ == "__main__":
    unittest.main() 