"""
Unit tests for ChromaDB target.
"""

import unittest
from unittest.mock import patch, MagicMock, call

import pytest
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import ChromaDBTarget
from src.exception import TargetException


class TestChromaDBTarget(unittest.TestCase):
    """Test class for ChromaDBTarget implementation."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session for all tests."""
        cls.spark = SparkSession.builder \
            .appName("test-chromadb-target") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up the Spark session after all tests."""
        cls.spark.stop()
    
    def setUp(self):
        """Set up each test."""
        # Create a basic valid configuration
        self.config = {
            "parameters": {
                "collection_name": "test_collection",
                "persist_directory": "/tmp/chromadb",
                "chroma_db_impl": "duckdb+parquet",
                "batch_size": 10,
                "metadata_fields": ["id", "chunk_index"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Patch ChromaDB import
        self.chromadb_patcher = patch('src.target.vector_targets.importlib.util.find_spec', return_value=True)
        self.mock_find_spec = self.chromadb_patcher.start()
        
        # Patch ChromaDB client
        self.client_patcher = patch('src.target.vector_targets.chromadb')
        self.mock_chromadb = self.client_patcher.start()
        
        # Setup mock client and collection
        self.mock_client = MagicMock()
        self.mock_collection = MagicMock()
        self.mock_chromadb.Client.return_value = self.mock_client
        self.mock_client.get_or_create_collection.return_value = self.mock_collection
        
        # Initialize target
        self.target = ChromaDBTarget(self.config)
    
    def tearDown(self):
        """Clean up after each test."""
        self.chromadb_patcher.stop()
        self.client_patcher.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for ChromaDB storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("chunk_index", StringType(), False),
            StructField("id", StringType(), False),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "chunk_id": "1-0", 
                "chunk_text": "This is a test chunk.", 
                "chunk_index": "0", 
                "id": "1", 
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5] * 10  # 50-dimensional embedding
            },
            {
                "chunk_id": "2-0", 
                "chunk_text": "Another test chunk for vector storage.", 
                "chunk_index": "0", 
                "id": "2", 
                "embedding": [0.2, 0.3, 0.4, 0.5, 0.6] * 10
            },
            {
                "chunk_id": "3-0", 
                "chunk_text": "A third chunk to store.", 
                "chunk_index": "0", 
                "id": "3", 
                "embedding": [0.3, 0.4, 0.5, 0.6, 0.7] * 10
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df
    
    def test_validate_config_valid(self):
        """Test that valid configuration passes validation."""
        # This should not raise an exception
        self.target._validate_target_config()
    
    def test_validate_config_missing_chromadb(self):
        """Test validation when ChromaDB is not installed."""
        # Mock find_spec to return None (module not found)
        self.mock_find_spec.return_value = None
        
        # Should raise an exception
        with self.assertRaises(TargetException) as context:
            self.target._validate_target_config()
        
        self.assertIn("ChromaDB is required", str(context.exception))
    
    def test_validate_config_missing_collection_name(self):
        """Test validation with missing collection name."""
        # Create config with missing collection name
        invalid_config = {
            "parameters": {
                "persist_directory": "/tmp/chromadb",
                "batch_size": 10
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Initialize target with invalid config
        with self.assertRaises(TargetException) as context:
            invalid_target = ChromaDBTarget(invalid_config)
            invalid_target._validate_target_config()
        
        self.assertIn("Collection name must be specified", str(context.exception))
    
    def test_initialize_client(self):
        """Test client initialization."""
        # Initialize the client
        self.target._initialize_client()
        
        # Verify ChromaDB client was created with settings
        self.mock_chromadb.Client.assert_called_once()
        
        # Verify collection was created
        self.mock_client.get_or_create_collection.assert_called_once_with(
            name="test_collection",
            metadata={"description": "Collection created by NLP Pipeline"}
        )
    
    def test_initialize_client_with_persistence(self):
        """Test client initialization with persistence directory."""
        # Initialize the client
        self.target._initialize_client()
        
        # Check if Settings were created with persistence directory
        settings_calls = [call for call in self.mock_chromadb.Settings.mock_calls 
                          if "persist_directory" in str(call)]
        self.assertTrue(len(settings_calls) > 0, "Persist directory not set in settings")
    
    def test_write_data_valid(self):
        """Test writing valid data to ChromaDB."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Write data
        self.target.write_data(df)
        
        # Verify client was initialized
        self.mock_chromadb.Client.assert_called_once()
        
        # Verify data was added to collection
        self.mock_collection.add.assert_called()
        
        # Check that add was called with correct number of ids
        add_calls = self.mock_collection.add.call_args_list
        self.assertEqual(len(add_calls), 1, "Expected one batch of data")
        
        # Get the arguments from the add call
        args, kwargs = add_calls[0]
        
        # Check the number of items added
        self.assertEqual(len(kwargs.get('ids', [])), 3, "Expected 3 items to be added")
    
    def test_write_data_missing_columns(self):
        """Test writing data with missing columns."""
        # Create DataFrame missing required columns
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("text", StringType(), False)
        ])
        
        invalid_df = self.spark.createDataFrame([
            {"id": "1", "text": "Test text"}
        ], schema)
        
        # Should raise an exception
        with self.assertRaises(TargetException) as context:
            self.target.write_data(invalid_df)
        
        self.assertIn("not found in DataFrame", str(context.exception))
    
    def test_write_data_with_batching(self):
        """Test writing data with batching."""
        # Create a larger DataFrame to test batching
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("chunk_index", StringType(), False),
            StructField("id", StringType(), False),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create 25 rows (with batch_size=10, this should create 3 batches)
        data = []
        for i in range(25):
            data.append({
                "chunk_id": f"{i}-0",
                "chunk_text": f"Chunk {i} text",
                "chunk_index": "0",
                "id": str(i),
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5] * 10
            })
        
        large_df = self.spark.createDataFrame(data, schema)
        
        # Configure target with smaller batch size
        small_batch_config = self.config.copy()
        small_batch_config["parameters"] = self.config["parameters"].copy()
        small_batch_config["parameters"]["batch_size"] = 10
        
        target = ChromaDBTarget(small_batch_config)
        
        # Write data
        target.write_data(large_df)
        
        # Check that add was called 3 times
        add_calls = self.mock_collection.add.call_args_list
        self.assertEqual(len(add_calls), 3, "Expected 3 batches")
    
    def test_write_data_with_metadata(self):
        """Test writing data with metadata fields."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Set metadata fields in config
        metadata_config = self.config.copy()
        metadata_config["parameters"] = self.config["parameters"].copy()
        metadata_config["parameters"]["metadata_fields"] = ["id", "chunk_index"]
        
        target = ChromaDBTarget(metadata_config)
        
        # Write data
        target.write_data(df)
        
        # Verify metadata was included
        add_calls = self.mock_collection.add.call_args_list
        args, kwargs = add_calls[0]
        
        # Check that metadata was included
        self.assertIsNotNone(kwargs.get('metadatas', None), "Expected metadata to be included")
        metadatas = kwargs.get('metadatas', [])
        self.assertEqual(len(metadatas), 3, "Expected 3 metadata items")
    
    def test_write_data_exception_handling(self):
        """Test exception handling during write."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Make collection.add raise an exception
        self.mock_collection.add.side_effect = Exception("Test ChromaDB error")
        
        # Should propagate the exception as TargetException
        with self.assertRaises(TargetException) as context:
            self.target.write_data(df)
        
        self.assertIn("Error writing to ChromaDB", str(context.exception))
    
    def test_close(self):
        """Test the close method."""
        # Set up mock client
        self.target._client = self.mock_client
        self.target._collection = self.mock_collection
        
        # Call close
        self.target.close()
        
        # Verify client is cleared
        self.assertIsNone(self.target._client)
        self.assertIsNone(self.target._collection)


if __name__ == "__main__":
    unittest.main() 