"""
Unit tests for PostgreSQL vector target.
"""

import unittest
from unittest.mock import patch, MagicMock, call

import pytest
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf, expr
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import PostgresVectorTarget
from src.exception import TargetException


class TestPostgresVectorTarget(unittest.TestCase):
    """Test class for PostgresVectorTarget implementation."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session for all tests."""
        cls.spark = SparkSession.builder \
            .appName("test-postgres-vector-target") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up the Spark session after all tests."""
        cls.spark.stop()
    
    def setUp(self):
        """Set up each test."""
        # Create a basic valid configuration
        self.config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "vectordb",
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
                "table": "embeddings",
                "batch_size": 100,
                "vector_dimensions": 384,
                "create_index": True,
                "index_type": "hnsw",
                "metadata_fields": ["filename", "path", "last_modified"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Patch psycopg2 import
        self.psycopg2_patcher = patch('src.target.vector_targets.importlib.util.find_spec', return_value=True)
        self.mock_find_spec = self.psycopg2_patcher.start()
        
        # Patch psycopg2 
        self.conn_patcher = patch('src.target.vector_targets.psycopg2')
        self.mock_psycopg2 = self.conn_patcher.start()
        
        # Setup mock connection and cursor
        self.mock_conn = MagicMock()
        self.mock_cursor = MagicMock()
        self.mock_psycopg2.connect.return_value = self.mock_conn
        self.mock_conn.cursor.return_value = self.mock_cursor
        
        # Initialize target
        self.target = PostgresVectorTarget(self.config)
    
    def tearDown(self):
        """Clean up after each test."""
        self.psycopg2_patcher.stop()
        self.conn_patcher.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for PostgreSQL vector storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("document_id", StringType(), False),
            StructField("filename", StringType(), True),
            StructField("path", StringType(), True),
            StructField("last_modified", StringType(), True),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "chunk_id": "1-0", 
                "chunk_text": "This is a test chunk.", 
                "document_id": "1",
                "filename": "document1.txt", 
                "path": "/data/documents/",
                "last_modified": "2023-01-01T12:00:00",
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5] * 77  # 385-dimensional embedding
            },
            {
                "chunk_id": "2-0", 
                "chunk_text": "Another test chunk for vector storage.", 
                "document_id": "2",
                "filename": "document2.txt", 
                "path": "/data/documents/",
                "last_modified": "2023-01-02T12:00:00",
                "embedding": [0.2, 0.3, 0.4, 0.5, 0.6] * 77
            },
            {
                "chunk_id": "3-0", 
                "chunk_text": "A third chunk to store.", 
                "document_id": "3",
                "filename": "document3.txt", 
                "path": None,
                "last_modified": None,
                "embedding": [0.3, 0.4, 0.5, 0.6, 0.7] * 77
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df
    
    def test_validate_config_valid(self):
        """Test that valid configuration passes validation."""
        # This should not raise an exception
        self.target._validate_target_config()
    
    def test_validate_config_missing_database(self):
        """Test validation with missing database."""
        # Create config with missing database
        invalid_config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
                "table": "embeddings"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Initialize target with invalid config
        with self.assertRaises(TargetException) as context:
            invalid_target = PostgresVectorTarget(invalid_config)
            invalid_target._validate_target_config()
        
        self.assertIn("Database name must be specified", str(context.exception))
    
    def test_validate_config_missing_user(self):
        """Test validation with missing user."""
        # Create config with missing user
        invalid_config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "vectordb",
                "password": "postgres",
                "schema": "public",
                "table": "embeddings"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Initialize target with invalid config
        with self.assertRaises(TargetException) as context:
            invalid_target = PostgresVectorTarget(invalid_config)
            invalid_target._validate_target_config()
        
        self.assertIn("User must be specified", str(context.exception))
    
    def test_validate_config_missing_password(self):
        """Test validation with missing password."""
        # Create config with missing password
        invalid_config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "vectordb",
                "user": "postgres",
                "schema": "public",
                "table": "embeddings"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Initialize target with invalid config
        with self.assertRaises(TargetException) as context:
            invalid_target = PostgresVectorTarget(invalid_config)
            invalid_target._validate_target_config()
        
        self.assertIn("Password must be specified", str(context.exception))
    
    def test_setup_pgvector_extension(self):
        """Test setting up pgvector extension."""
        # Mock spark session
        mock_spark = MagicMock()
        mock_reader = MagicMock()
        mock_spark.read.return_value = mock_reader
        
        # Call method
        self.target._setup_pgvector_extension(mock_spark)
        
        # Verify reader options were set correctly
        mock_spark.read.assert_called_once()
        mock_reader.format.assert_called_once_with("jdbc")
        
        option_calls = mock_reader.option.call_args_list
        url_call = any("url" in str(call) for call in option_calls)
        self.assertTrue(url_call, "JDBC URL option not set")
        
        query_call = any("CREATE EXTENSION IF NOT EXISTS vector" in str(call) 
                         for call in option_calls)
        self.assertTrue(query_call, "Create extension query not set")
        
        # Verify load was called
        mock_reader.load.assert_called_once()
    
    def test_create_table_if_not_exists(self):
        """Test creating table if it doesn't exist."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Mock spark session and reader
        mock_reader = MagicMock()
        df.sparkSession.read.return_value = mock_reader
        
        # Call method
        self.target._create_table_if_not_exists(df)
        
        # Verify reader options were set correctly
        df.sparkSession.read.assert_called_once()
        mock_reader.format.assert_called_once_with("jdbc")
        
        option_calls = mock_reader.option.call_args_list
        query_call = any("CREATE TABLE IF NOT EXISTS" in str(call) for call in option_calls)
        self.assertTrue(query_call, "Create table query not set")
        
        # Check if vector column is defined correctly
        vector_call = any(f"{self.target.embedding_column} vector({self.target.vector_dimensions})" 
                         in str(call) for call in option_calls)
        self.assertTrue(vector_call, "Vector column definition not found")
        
        # Verify load was called
        mock_reader.load.assert_called_once()
    
    def test_create_vector_index(self):
        """Test creating vector index."""
        # Call method
        self.target._create_vector_index()
        
        # Verify connection was created
        self.mock_psycopg2.connect.assert_called_once_with(
            host="localhost",
            port=5432,
            dbname="vectordb",
            user="postgres",
            password="postgres"
        )
        
        # Verify cursor execution
        self.mock_cursor.execute.assert_called_once()
        args, _ = self.mock_cursor.execute.call_args
        
        # Check that index creation query contains expected components
        self.assertIn("DROP INDEX IF EXISTS", args[0])
        self.assertIn("CREATE INDEX", args[0])
        
        # Verify commit was called
        self.mock_conn.commit.assert_called_once()
        
        # Verify connection was closed
        self.mock_conn.close.assert_called_once()
    
    @patch('pyspark.sql.DataFrame.withColumn')
    @patch('pyspark.sql.DataFrame.write')
    def test_write_data(self, mock_write, mock_withColumn):
        """Test writing data to PostgreSQL."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Setup mock chain for write operations
        mock_writer = MagicMock()
        mock_write.return_value = mock_writer
        
        # Setup mock chain for withColumn
        mock_df_with_vector = MagicMock()
        mock_withColumn.return_value = mock_df_with_vector
        mock_df_with_vector.drop.return_value = mock_df_with_vector
        mock_df_with_vector.withColumnRenamed.return_value = mock_df_with_vector
        mock_df_with_vector.select.return_value = mock_df_with_vector
        
        # Call write_data
        self.target.write_data(df)
        
        # Verify pgvector extension setup was attempted
        mock_setup_call = any("_setup_pgvector_extension" in str(call) 
                             for call in mock_df_with_vector.method_calls)
        self.assertTrue(mock_setup_call, "pgvector extension setup not attempted")
        
        # Verify table creation was attempted
        mock_create_table_call = any("_create_table_if_not_exists" in str(call) 
                                    for call in mock_df_with_vector.method_calls)
        self.assertTrue(mock_create_table_call, "Table creation not attempted")
        
        # Verify index creation was attempted
        mock_create_index_call = any("_create_vector_index" in str(call) 
                                    for call in mock_df_with_vector.method_calls)
        self.assertTrue(mock_create_index_call, "Index creation not attempted")
    
    def test_write_data_missing_columns(self):
        """Test writing data with missing columns."""
        # Create DataFrame missing required columns
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("text", StringType(), False)
        ])
        
        invalid_df = self.spark.createDataFrame([
            {"id": "1", "text": "Test text"}
        ], schema)
        
        # Should raise an exception
        with self.assertRaises(TargetException) as context:
            self.target.write_data(invalid_df)
        
        self.assertIn("not found in DataFrame", str(context.exception))
    
    def test_write_data_jdbc_error(self):
        """Test handling of JDBC errors during write."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Make DataFrame.write raise an exception
        with patch.object(df, 'write', side_effect=Exception("JDBC connection error")):
            with self.assertRaises(TargetException) as context:
                self.target.write_data(df)
            
            self.assertIn("Error writing to PostgreSQL", str(context.exception))
    
    def test_close(self):
        """Test the close method."""
        # No specific action for close in PostgresVectorTarget
        # but method should exist and not raise exceptions
        self.target.close()


if __name__ == "__main__":
    unittest.main() 