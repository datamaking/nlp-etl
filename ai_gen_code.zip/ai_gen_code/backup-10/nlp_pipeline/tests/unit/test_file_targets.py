"""
Unit tests for file target components.
"""

import os
import tempfile
import unittest
import shutil
from unittest.mock import patch, MagicMock

import pytest
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, FloatType

from src.target.file_targets import (
    FileTarget,
    JSONTarget,
    ParquetTarget,
    CSVTarget
)
from src.exception import TargetException


class TestFileTarget(unittest.TestCase):
    """Base test class for file targets."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-file-target") \
            .master("local[2]") \
            .getOrCreate()
        
        # Create a temporary directory for output files
        cls.temp_dir = tempfile.mkdtemp()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up the Spark session and temporary files."""
        cls.spark.stop()
        
        # Remove temporary directory
        shutil.rmtree(cls.temp_dir)
    
    def create_test_dataframe(self):
        """Create a test DataFrame for file storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("text", StringType(), False),
            StructField("metadata", StringType(), True),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "id": "doc1", 
                "text": "This is a test document.", 
                "metadata": "sample metadata 1", 
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5]
            },
            {
                "id": "doc2", 
                "text": "Another test document for storage.", 
                "metadata": "sample metadata 2", 
                "embedding": [0.2, 0.3, 0.4, 0.5, 0.6]
            },
            {
                "id": "doc3", 
                "text": "A third document to store.", 
                "metadata": None, 
                "embedding": [0.3, 0.4, 0.5, 0.6, 0.7]
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df
    
    def test_file_target_validate_config_missing_path(self):
        """Test FileTarget validation with missing path."""
        config = {
            "parameters": {}
        }
        
        with self.assertRaises(TargetException) as context:
            FileTarget(config)
        
        self.assertIn("Output path must be specified", str(context.exception))
    
    def test_file_target_validate_config_invalid_mode(self):
        """Test FileTarget validation with invalid mode."""
        config = {
            "parameters": {
                "path": os.path.join(self.temp_dir, "output"),
                "mode": "invalid_mode"
            }
        }
        
        with self.assertRaises(TargetException) as context:
            FileTarget(config)
        
        self.assertIn("Invalid write mode", str(context.exception))


class TestJSONTarget(TestFileTarget):
    """Test the JSONTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.output_path = os.path.join(self.temp_dir, "output", "json")
        self.config = {
            "parameters": {
                "path": self.output_path,
                "mode": "overwrite",
                "lines": True,
                "compression": "none"
            },
            "embedding_column": "embedding",
            "text_column": "text",
            "id_column": "id"
        }
        
        self.target = JSONTarget(self.config)
    
    def test_json_write_data(self):
        """Test writing data to JSON."""
        df = self.create_test_dataframe()
        
        # Write data
        self.target.write_data(df)
        
        # Verify output exists
        output_files = [f for f in os.listdir(os.path.join(self.output_path)) if f.endswith(".json")]
        self.assertTrue(len(output_files) > 0, "No JSON files were written")
        
        # Read the data back to verify
        read_df = self.spark.read.json(self.output_path)
        
        # Verify schema and count
        self.assertEqual(read_df.count(), df.count())
        self.assertTrue("id" in read_df.columns)
        self.assertTrue("text" in read_df.columns)
        self.assertTrue("embedding" in read_df.columns)
    
    def test_json_write_data_with_partitioning(self):
        """Test writing JSON data with partitioning."""
        # Update config with partitioning
        config_with_partition = self.config.copy()
        config_with_partition["parameters"] = self.config["parameters"].copy()
        config_with_partition["parameters"]["partition_by"] = ["id"]
        
        partition_target = JSONTarget(config_with_partition)
        
        df = self.create_test_dataframe()
        
        # Write data
        partition_target.write_data(df)
        
        # Verify partitions were created
        partition_dirs = [d for d in os.listdir(self.output_path) if os.path.isdir(os.path.join(self.output_path, d))]
        self.assertTrue(len(partition_dirs) > 0, "No partition directories were created")
        
        # Check that each ID has its own partition
        unique_ids = df.select("id").distinct().collect()
        for row in unique_ids:
            id_value = row["id"]
            partition_path = os.path.join(self.output_path, f"id={id_value}")
            self.assertTrue(os.path.exists(partition_path), f"Partition for id={id_value} was not created")
    
    def test_json_write_data_exception(self):
        """Test handling of exceptions during JSON write."""
        df = self.create_test_dataframe()
        
        # Mock DataFrame.write to raise an exception
        with patch.object(df, 'write', side_effect=Exception("Mocked write exception")):
            with self.assertRaises(TargetException) as context:
                self.target.write_data(df)
            
            self.assertIn("Error writing to JSON files", str(context.exception))


class TestParquetTarget(TestFileTarget):
    """Test the ParquetTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.output_path = os.path.join(self.temp_dir, "output", "parquet")
        self.config = {
            "parameters": {
                "path": self.output_path,
                "mode": "overwrite",
                "compression": "snappy"
            },
            "embedding_column": "embedding",
            "text_column": "text",
            "id_column": "id"
        }
        
        self.target = ParquetTarget(self.config)
    
    def test_parquet_write_data(self):
        """Test writing data to Parquet."""
        df = self.create_test_dataframe()
        
        # Write data
        self.target.write_data(df)
        
        # Verify output exists
        output_files = [f for f in os.listdir(os.path.join(self.output_path)) if f.endswith(".parquet")]
        self.assertTrue(len(output_files) > 0, "No Parquet files were written")
        
        # Read the data back to verify
        read_df = self.spark.read.parquet(self.output_path)
        
        # Verify schema and count
        self.assertEqual(read_df.count(), df.count())
        self.assertTrue("id" in read_df.columns)
        self.assertTrue("text" in read_df.columns)
        self.assertTrue("embedding" in read_df.columns)
    
    def test_parquet_write_data_with_options(self):
        """Test writing Parquet data with additional options."""
        # Update config with additional options
        config_with_options = self.config.copy()
        config_with_options["parameters"] = self.config["parameters"].copy()
        config_with_options["parameters"]["options"] = {
            "maxRecordsPerFile": "1"
        }
        
        options_target = ParquetTarget(config_with_options)
        
        df = self.create_test_dataframe()
        
        # Write data
        options_target.write_data(df)
        
        # Verify more files were created due to maxRecordsPerFile
        files = [f for f in os.listdir(os.path.join(self.output_path)) if f.endswith(".parquet")]
        # With maxRecordsPerFile=1, we'd expect at least as many files as rows
        self.assertTrue(len(files) >= df.count(), "Expected at least one file per record")
    
    def test_parquet_write_data_exception(self):
        """Test handling of exceptions during Parquet write."""
        df = self.create_test_dataframe()
        
        # Mock DataFrame.write to raise an exception
        with patch.object(df, 'write', side_effect=Exception("Mocked write exception")):
            with self.assertRaises(TargetException) as context:
                self.target.write_data(df)
            
            self.assertIn("Error writing to Parquet files", str(context.exception))


class TestCSVTarget(TestFileTarget):
    """Test the CSVTarget class."""
    
    def setUp(self):
        """Set up each test."""
        self.output_path = os.path.join(self.temp_dir, "output", "csv")
        self.config = {
            "parameters": {
                "path": self.output_path,
                "mode": "overwrite",
                "delimiter": ",",
                "header": True,
                "quote": "\"",
                "escape": "\\"
            },
            "embedding_column": "embedding",
            "text_column": "text",
            "id_column": "id"
        }
        
        self.target = CSVTarget(self.config)
    
    def test_csv_write_data(self):
        """Test writing data to CSV."""
        df = self.create_test_dataframe()
        
        # Write data
        self.target.write_data(df)
        
        # Verify output exists
        output_files = [f for f in os.listdir(os.path.join(self.output_path)) if f.endswith(".csv")]
        self.assertTrue(len(output_files) > 0, "No CSV files were written")
        
        # Read the data back to verify
        read_df = self.spark.read.csv(self.output_path, header=True, inferSchema=True)
        
        # Verify schema and count
        self.assertEqual(read_df.count(), df.count())
        self.assertTrue("id" in read_df.columns)
        self.assertTrue("text" in read_df.columns)
        # Note: embedding in CSV will be stored as a string
        self.assertTrue("embedding" in read_df.columns)
    
    def test_csv_write_data_with_custom_delimiter(self):
        """Test writing CSV data with custom delimiter."""
        # Update config with different delimiter
        config_with_delimiter = self.config.copy()
        config_with_delimiter["parameters"] = self.config["parameters"].copy()
        config_with_delimiter["parameters"]["delimiter"] = "|"
        
        delimiter_target = CSVTarget(config_with_delimiter)
        
        df = self.create_test_dataframe()
        
        # Write data
        delimiter_target.write_data(df)
        
        # Read the data back with the custom delimiter
        read_df = self.spark.read.option("delimiter", "|").csv(self.output_path, header=True, inferSchema=True)
        
        # Verify count
        self.assertEqual(read_df.count(), df.count())
    
    def test_csv_write_data_without_header(self):
        """Test writing CSV data without header."""
        # Update config with no header
        config_no_header = self.config.copy()
        config_no_header["parameters"] = self.config["parameters"].copy()
        config_no_header["parameters"]["header"] = False
        
        no_header_target = CSVTarget(config_no_header)
        
        df = self.create_test_dataframe()
        
        # Write data
        no_header_target.write_data(df)
        
        # Read the data back without header
        read_df = self.spark.read.csv(self.output_path, header=False, inferSchema=True)
        
        # Verify count
        self.assertEqual(read_df.count(), df.count())
        # With no header, columns will be named _c0, _c1, etc.
        self.assertTrue("_c0" in read_df.columns)
    
    def test_csv_write_data_exception(self):
        """Test handling of exceptions during CSV write."""
        df = self.create_test_dataframe()
        
        # Mock DataFrame.write to raise an exception
        with patch.object(df, 'write', side_effect=Exception("Mocked write exception")):
            with self.assertRaises(TargetException) as context:
                self.target.write_data(df)
            
            self.assertIn("Error writing to CSV files", str(context.exception))


if __name__ == "__main__":
    unittest.main() 