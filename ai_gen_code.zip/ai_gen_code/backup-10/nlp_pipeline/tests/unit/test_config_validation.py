"""
Unit tests for configuration validation.
"""

import unittest
import yaml
import os
import tempfile
from unittest.mock import patch, MagicMock

import pytest

from src.target.vector_targets import (
    ChromaDBTarget,
    PostgresVectorTarget,
    Neo4jTarget
)
from src.exception.exceptions import TargetException


class TestNeo4jConfig(unittest.TestCase):
    """Test Neo4j configuration validation."""
    
    def setUp(self):
        """Set up each test."""
        self.valid_config = {
            "parameters": {
                "uri": "neo4j://localhost:7687",
                "user": "neo4j",
                "password": "password",
                "database": "neo4j",
                "node_label": "Chunk",
                "document_label": "Document",
                "relationship_type": "PART_OF",
                "batch_size": 50,
                "vector_dimension": 384,
                "create_vector_index": True,
                "vector_index_name": "chunk_vector_index",
                "similarity_metric": "cosine"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
    
    @patch('src.target.vector_targets.GraphDatabase')
    @patch('src.target.vector_targets.neo4j')
    def test_valid_config(self, mock_neo4j, mock_graph_db):
        """Test valid Neo4j configuration."""
        # Setup mock driver
        mock_driver = MagicMock()
        mock_session = MagicMock()
        mock_graph_db.driver.return_value = mock_driver
        mock_driver.session.return_value = mock_session
        
        # Create target with valid config
        target = Neo4jTarget(self.valid_config)
        
        # Validate config should not raise exception
        target._validate_target_config()
    
    @patch('src.target.vector_targets.GraphDatabase')
    @patch('src.target.vector_targets.neo4j')
    def test_missing_uri(self, mock_neo4j, mock_graph_db):
        """Test missing URI in configuration."""
        invalid_config = self.valid_config.copy()
        invalid_config["parameters"] = self.valid_config["parameters"].copy()
        invalid_config["parameters"].pop("uri")
        
        # Should use default URI
        target = Neo4jTarget(invalid_config)
        self.assertEqual(target.uri, "bolt://localhost:7687")
    
    @patch('src.target.vector_targets.GraphDatabase')
    @patch('src.target.vector_targets.neo4j')
    def test_missing_password(self, mock_neo4j, mock_graph_db):
        """Test missing password in configuration."""
        invalid_config = self.valid_config.copy()
        invalid_config["parameters"] = self.valid_config["parameters"].copy()
        invalid_config["parameters"].pop("password")
        
        # Should raise exception during validation
        with self.assertRaises(TargetException):
            Neo4jTarget(invalid_config)._validate_target_config()
    
    @patch('src.target.vector_targets.GraphDatabase')
    @patch('src.target.vector_targets.neo4j')
    def test_missing_columns(self, mock_neo4j, mock_graph_db):
        """Test missing column mappings in configuration."""
        # Missing embedding column
        invalid_config = self.valid_config.copy()
        invalid_config.pop("embedding_column")
        
        with self.assertRaises(TargetException):
            Neo4jTarget(invalid_config)._validate_target_config()
        
        # Missing text column
        invalid_config = self.valid_config.copy()
        invalid_config.pop("text_column")
        
        with self.assertRaises(TargetException):
            Neo4jTarget(invalid_config)._validate_target_config()
        
        # Missing ID column
        invalid_config = self.valid_config.copy()
        invalid_config.pop("id_column")
        
        with self.assertRaises(TargetException):
            Neo4jTarget(invalid_config)._validate_target_config()


class TestPostgresVectorConfig(unittest.TestCase):
    """Test PostgreSQL Vector configuration validation."""
    
    def setUp(self):
        """Set up each test."""
        self.valid_config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "vectordb",
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
                "document_table": "documents",
                "chunk_table": "chunks",
                "vector_dimension": 384,
                "vector_extension": "pgvector",
                "index_type": "hnsw",
                "batch_size": 50
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
    
    @patch('src.target.vector_targets.psycopg2')
    def test_valid_config(self, mock_psycopg2):
        """Test valid PostgreSQL configuration."""
        # Setup mock connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_psycopg2.connect.return_value = mock_conn
        mock_conn.cursor.return_value = mock_cursor
        
        # Create target with valid config
        target = PostgresVectorTarget(self.valid_config)
        
        # Validate config should not raise exception
        target._validate_target_config()
    
    @patch('src.target.vector_targets.psycopg2')
    def test_missing_host(self, mock_psycopg2):
        """Test missing host in configuration."""
        invalid_config = self.valid_config.copy()
        invalid_config["parameters"] = self.valid_config["parameters"].copy()
        invalid_config["parameters"].pop("host")
        
        # Should use default host
        target = PostgresVectorTarget(invalid_config)
        self.assertEqual(target.host, "localhost")
    
    @patch('src.target.vector_targets.psycopg2')
    def test_missing_database(self, mock_psycopg2):
        """Test missing database in configuration."""
        invalid_config = self.valid_config.copy()
        invalid_config["parameters"] = self.valid_config["parameters"].copy()
        invalid_config["parameters"].pop("database")
        
        # Should raise exception during validation
        with self.assertRaises(TargetException):
            PostgresVectorTarget(invalid_config)._validate_target_config()
    
    @patch('src.target.vector_targets.psycopg2')
    def test_missing_tables(self, mock_psycopg2):
        """Test missing table names in configuration."""
        invalid_config = self.valid_config.copy()
        invalid_config["parameters"] = self.valid_config["parameters"].copy()
        invalid_config["parameters"].pop("chunk_table")
        
        # Should use default table name
        target = PostgresVectorTarget(invalid_config)
        self.assertEqual(target.chunk_table, "chunks")
    
    @patch('src.target.vector_targets.psycopg2')
    def test_invalid_vector_extension(self, mock_psycopg2):
        """Test invalid vector extension in configuration."""
        invalid_config = self.valid_config.copy()
        invalid_config["parameters"] = self.valid_config["parameters"].copy()
        invalid_config["parameters"]["vector_extension"] = "invalid_extension"
        
        # Create target with invalid extension
        target = PostgresVectorTarget(invalid_config)
        
        # Should warn about unsupported extension but not fail
        # Since we can't easily test logging, we just make sure it doesn't raise an exception
        target._validate_target_config()


class TestYamlConfigLoading(unittest.TestCase):
    """Test loading YAML configuration files."""
    
    def setUp(self):
        """Set up each test."""
        self.neo4j_config = """
target:
  type: "neo4j"
  parameters:
    uri: "neo4j://localhost:7687"
    user: "neo4j"
    password: "password"
    database: "neo4j"
    node_label: "Chunk"
    document_label: "Document"
    relationship_type: "PART_OF"
    vector_dimension: 384
  embedding_column: "embedding"
  text_column: "chunk_text"
  id_column: "chunk_id"
"""
        
        self.postgres_config = """
target:
  type: "postgres_vector"
  parameters:
    host: "localhost"
    port: 5432
    database: "vectordb"
    user: "postgres"
    password: "postgres"
    vector_dimension: 384
    vector_extension: "pgvector"
  embedding_column: "embedding"
  text_column: "chunk_text"
  id_column: "chunk_id"
"""
    
    def test_load_neo4j_config(self):
        """Test loading Neo4j configuration from YAML."""
        # Create a temporary file with the config
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as temp:
            temp.write(self.neo4j_config)
            temp_name = temp.name
        
        try:
            # Load the config
            with open(temp_name, 'r') as f:
                config = yaml.safe_load(f)
            
            # Check that the config was loaded correctly
            self.assertEqual(config["target"]["type"], "neo4j")
            self.assertEqual(config["target"]["parameters"]["vector_dimension"], 384)
            self.assertEqual(config["target"]["embedding_column"], "embedding")
        finally:
            # Clean up
            os.unlink(temp_name)
    
    def test_load_postgres_config(self):
        """Test loading PostgreSQL configuration from YAML."""
        # Create a temporary file with the config
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as temp:
            temp.write(self.postgres_config)
            temp_name = temp.name
        
        try:
            # Load the config
            with open(temp_name, 'r') as f:
                config = yaml.safe_load(f)
            
            # Check that the config was loaded correctly
            self.assertEqual(config["target"]["type"], "postgres_vector")
            self.assertEqual(config["target"]["parameters"]["vector_dimension"], 384)
            self.assertEqual(config["target"]["embedding_column"], "embedding")
        finally:
            # Clean up
            os.unlink(temp_name)


if __name__ == "__main__":
    unittest.main() 