"""
Unit tests for data source components.
"""

import os
import unittest
from unittest.mock import patch, MagicMock
import tempfile
import shutil

import pytest
from pyspark.sql import SparkSession

from src.data_source.file_sources import (
    TextFileSource, PDFSource, CSVSource, 
    ParquetSource, JSONSource
)
from src.exception import DataSourceException


class TestDataSource(unittest.TestCase):
    """Base test class for data sources."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-data-source") \
            .master("local[2]") \
            .getOrCreate()
        
        # Create a temporary directory for test files
        cls.test_dir = tempfile.mkdtemp()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        # Stop the Spark session
        cls.spark.stop()
        
        # Remove the temporary directory
        shutil.rmtree(cls.test_dir)


class TestTextFileSource(TestDataSource):
    """Test the TextFileSource class."""
    
    def setUp(self):
        """Set up each test."""
        # Create test text files
        self.file_path = os.path.join(self.test_dir, "test.txt")
        with open(self.file_path, "w") as f:
            f.write("This is a test file.\nIt has multiple lines.")
        
        # Configure the source
        self.config = {
            "parameters": {
                "path": self.test_dir,
                "file_pattern": "*.txt"
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        self.source = TextFileSource(self.config, self.spark)
    
    def test_read_data(self):
        """Test reading text data from files."""
        # Read the data
        df = self.source.read_data()
        
        # Check the result
        self.assertIsNotNone(df)
        self.assertTrue(df.count() > 0)
        self.assertTrue("text" in df.columns)
        self.assertTrue("id" in df.columns)
        
        # Check the content
        rows = df.collect()
        self.assertEqual(len(rows), 1)
        self.assertTrue("This is a test file." in rows[0]["text"])
    
    def test_no_files_found(self):
        """Test behavior when no files are found."""
        # Configure the source with a non-matching pattern
        config = {
            "parameters": {
                "path": self.test_dir,
                "file_pattern": "*.nonexistent"
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        source = TextFileSource(config, self.spark)
        
        # Read the data
        df = source.read_data()
        
        # Check that an empty DataFrame is returned
        self.assertIsNotNone(df)
        self.assertEqual(df.count(), 0)
    
    def test_missing_path(self):
        """Test that an exception is raised if the path is missing."""
        # Configure the source without a path
        config = {
            "parameters": {},
            "text_column": "text",
            "id_column": "id"
        }
        
        # Creating the source should raise an exception
        with self.assertRaises(DataSourceException):
            TextFileSource(config, self.spark)


class TestCSVSource(TestDataSource):
    """Test the CSVSource class."""
    
    def setUp(self):
        """Set up each test."""
        # Create test CSV file
        self.file_path = os.path.join(self.test_dir, "test.csv")
        with open(self.file_path, "w") as f:
            f.write("id,text,value\n")
            f.write("1,Sample text,10.5\n")
            f.write("2,Another example,20.0\n")
        
        # Configure the source
        self.config = {
            "parameters": {
                "path": self.file_path
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        self.source = CSVSource(self.config, self.spark)
    
    def test_read_data(self):
        """Test reading data from CSV file."""
        # Read the data
        df = self.source.read_data()
        
        # Check the result
        self.assertIsNotNone(df)
        self.assertEqual(df.count(), 2)
        self.assertTrue("text" in df.columns)
        self.assertTrue("id" in df.columns)
        
        # Check the content
        rows = df.collect()
        self.assertEqual(rows[0]["text"], "Sample text")
        self.assertEqual(rows[1]["text"], "Another example")
    
    def test_missing_path(self):
        """Test that an exception is raised if the path is missing."""
        # Configure the source without a path
        config = {
            "parameters": {},
            "text_column": "text",
            "id_column": "id"
        }
        
        # Creating the source should raise an exception
        with self.assertRaises(DataSourceException):
            CSVSource(config, self.spark)
    
    def test_missing_text_column(self):
        """Test that an exception is raised if the text column is missing."""
        # Configure the source with a non-existent text column
        config = {
            "parameters": {
                "path": self.file_path
            },
            "text_column": "nonexistent_column",
            "id_column": "id"
        }
        
        source = CSVSource(config, self.spark)
        
        # Reading should raise an exception
        with self.assertRaises(DataSourceException):
            source.read_data()


@patch('src.data_source.file_sources.PDFSource._validate_source_config')
class TestPDFSource(TestDataSource):
    """Test the PDFSource class with mocked PDF processing."""
    
    def setUp(self):
        """Set up each test."""
        # Create a dummy PDF file (not actually a PDF, just for testing)
        self.file_path = os.path.join(self.test_dir, "test.pdf")
        with open(self.file_path, "w") as f:
            f.write("Not a real PDF file")
        
        # Configure the source
        self.config = {
            "parameters": {
                "path": self.test_dir,
                "file_pattern": "*.pdf"
            },
            "text_column": "text",
            "id_column": "id"
        }
    
    def test_read_data_with_mock(self, mock_validate):
        """Test reading PDF data with mocked extraction."""
        # Mock the PDF extraction UDF
        with patch('pyspark.sql.functions.udf') as mock_udf:
            # Create a mock DataFrame
            mock_df = MagicMock()
            mock_df.count.return_value = 2
            mock_df.columns = ["id", "text", "page_number", "total_pages"]
            
            # Mock the spark read
            with patch.object(self.spark, 'createDataFrame') as mock_create_df:
                mock_create_df.return_value = mock_df
                
                # Create the source and read data
                source = PDFSource(self.config, self.spark)
                df = source.read_data()
                
                # Check the result
                self.assertIsNotNone(df)
                self.assertEqual(df.count(), 2)
    
    def test_missing_path(self, mock_validate):
        """Test that an exception is raised if the path is missing."""
        # Configure the source without a path
        config = {
            "parameters": {},
            "text_column": "text",
            "id_column": "id"
        }
        
        # Mock validation to avoid dependency issues
        mock_validate.side_effect = DataSourceException("Path must be specified for PDF source")
        
        # Creating the source should raise an exception
        with self.assertRaises(DataSourceException):
            PDFSource(config, self.spark)


class TestJSONSourceParquetSource(TestDataSource):
    """Tests for JSONSource and ParquetSource classes with mocks."""
    
    def test_json_source_validation(self):
        """Test JSON source validation."""
        # Configure the source without a path
        config = {
            "parameters": {},
            "text_column": "text",
            "id_column": "id"
        }
        
        # Creating the source should raise an exception
        with self.assertRaises(DataSourceException):
            JSONSource(config, self.spark)
    
    def test_parquet_source_validation(self):
        """Test Parquet source validation."""
        # Configure the source without a path
        config = {
            "parameters": {},
            "text_column": "text",
            "id_column": "id"
        }
        
        # Creating the source should raise an exception
        with self.assertRaises(DataSourceException):
            ParquetSource(config, self.spark)
    
    @patch('pyspark.sql.DataFrameReader.json')
    def test_json_read_data(self, mock_read):
        """Test reading JSON data with mock."""
        # Set up mock DataFrame
        mock_df = MagicMock()
        mock_df.columns = ["text", "id"]
        mock_df.count.return_value = 2
        mock_read.return_value = mock_df
        
        # Configure the source
        config = {
            "parameters": {
                "path": "dummy_path.json"
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        source = JSONSource(config, self.spark)
        
        # Read data
        df = source.read_data()
        
        # Check the result
        self.assertIsNotNone(df)
        self.assertEqual(df.count(), 2)
    
    @patch('pyspark.sql.DataFrameReader.parquet')
    def test_parquet_read_data(self, mock_read):
        """Test reading Parquet data with mock."""
        # Set up mock DataFrame
        mock_df = MagicMock()
        mock_df.columns = ["text", "id"]
        mock_df.count.return_value = 2
        mock_read.return_value = mock_df
        
        # Configure the source
        config = {
            "parameters": {
                "path": "dummy_path.parquet"
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        source = ParquetSource(config, self.spark)
        
        # Read data
        df = source.read_data()
        
        # Check the result
        self.assertIsNotNone(df)
        self.assertEqual(df.count(), 2)


if __name__ == "__main__":
    unittest.main() 