"""
Unit tests for Neo4j vector target.
"""

import unittest
from unittest.mock import patch, MagicMock, call

import pytest
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import Neo4jTarget
from src.exception import TargetException


class TestNeo4jTarget(unittest.TestCase):
    """Test class for Neo4jTarget implementation."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session for all tests."""
        cls.spark = SparkSession.builder \
            .appName("test-neo4j-target") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up the Spark session after all tests."""
        cls.spark.stop()
    
    def setUp(self):
        """Set up each test."""
        # Create a basic valid configuration
        self.config = {
            "parameters": {
                "uri": "bolt://localhost:7687",
                "user": "neo4j",
                "password": "password",
                "database": "neo4j",
                "node_label": "Document",
                "chunk_node_label": "Chunk",
                "relationship_type": "HAS_CHUNK",
                "batch_size": 10,
                "create_indices": True,
                "create_constraints": True,
                "metadata_fields": ["id", "filename", "path"],
                "vector_dimension": 384,
                "vector_property": "embedding",
                "index_name": "chunk_embedding_index",
                "similarity_metric": "cosine"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Patch Neo4j import
        self.neo4j_patcher = patch('src.target.vector_targets.importlib.util.find_spec', return_value=True)
        self.mock_find_spec = self.neo4j_patcher.start()
        
        # Patch Neo4j driver
        self.driver_patcher = patch('src.target.vector_targets.neo4j.GraphDatabase')
        self.mock_graph_db = self.driver_patcher.start()
        
        # Setup mock driver and session
        self.mock_driver = MagicMock()
        self.mock_session = MagicMock()
        self.mock_graph_db.driver.return_value = self.mock_driver
        self.mock_driver.session.return_value = self.mock_session
        
        # Initialize target
        self.target = Neo4jTarget(self.config)
    
    def tearDown(self):
        """Clean up after each test."""
        self.neo4j_patcher.stop()
        self.driver_patcher.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for Neo4j storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("document_id", StringType(), False),
            StructField("filename", StringType(), True),
            StructField("path", StringType(), True),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "chunk_id": "1-0", 
                "chunk_text": "This is a test chunk.", 
                "document_id": "1", 
                "filename": "document1.txt", 
                "path": "/data/documents/",
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5] * 77  # 385-dimensional embedding
            },
            {
                "chunk_id": "2-0", 
                "chunk_text": "Another test chunk for vector storage.", 
                "document_id": "2", 
                "filename": "document2.txt", 
                "path": "/data/documents/",
                "embedding": [0.2, 0.3, 0.4, 0.5, 0.6] * 77
            },
            {
                "chunk_id": "3-0", 
                "chunk_text": "A third chunk to store.", 
                "document_id": "3", 
                "filename": "document3.txt", 
                "path": None,
                "embedding": [0.3, 0.4, 0.5, 0.6, 0.7] * 77
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df
    
    def test_validate_config_valid(self):
        """Test that valid configuration passes validation."""
        # This should not raise an exception
        self.target._validate_target_config()
    
    def test_validate_config_missing_neo4j(self):
        """Test validation when Neo4j is not installed."""
        # Mock find_spec to return None (module not found)
        self.mock_find_spec.return_value = None
        
        # Should raise an exception
        with self.assertRaises(TargetException) as context:
            self.target._validate_target_config()
        
        self.assertIn("Neo4j Python driver is required", str(context.exception))
    
    def test_validate_config_missing_password(self):
        """Test validation with missing password."""
        # Create config with missing password
        invalid_config = {
            "parameters": {
                "uri": "bolt://localhost:7687",
                "user": "neo4j",
                "database": "neo4j"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Initialize target with invalid config
        with self.assertRaises(TargetException) as context:
            invalid_target = Neo4jTarget(invalid_config)
            invalid_target._validate_target_config()
        
        self.assertIn("Password must be specified", str(context.exception))
    
    def test_initialize_driver(self):
        """Test driver initialization."""
        # Initialize the driver
        self.target._initialize_driver()
        
        # Verify Neo4j driver was created
        self.mock_graph_db.driver.assert_called_once_with(
            "bolt://localhost:7687",
            auth=("neo4j", "password")
        )
        
        # Verify session was created for testing connection
        self.mock_driver.session.assert_called_with(database="neo4j")
        
        # Verify test query was run
        self.mock_session.run.assert_called_with("RETURN 1 AS test")
    
    def test_initialize_driver_connection_error(self):
        """Test driver initialization with connection error."""
        # Make session.run raise an exception
        self.mock_session.run.side_effect = Exception("Connection failed")
        
        # Should propagate the exception as TargetException
        with self.assertRaises(TargetException) as context:
            self.target._initialize_driver()
        
        self.assertIn("Failed to connect to Neo4j", str(context.exception))
        
        # Verify driver was reset to None
        self.assertIsNone(self.target._driver)
    
    def test_create_indices(self):
        """Test creating indices in Neo4j."""
        # Setup mock results for index check
        mock_record = MagicMock()
        mock_record.__getitem__.side_effect = lambda x: "vector" if x == "provider" else None
        self.mock_session.run.return_value = [mock_record]
        
        # Call method
        self.target._create_indices()
        
        # Verify constraint creation query was executed
        constraint_call = any(
            "CREATE CONSTRAINT" in str(call) for call in self.mock_session.run.call_args_list
        )
        self.assertTrue(constraint_call, "Constraint creation query not found")
        
        # Verify vector index creation query was executed
        vector_index_call = any(
            "createNodeIndex" in str(call) for call in self.mock_session.run.call_args_list
        )
        self.assertTrue(vector_index_call, "Vector index creation query not found")
    
    def test_write_batch(self):
        """Test writing a batch of nodes to Neo4j."""
        # Create test batch data
        batch = [
            {
                "chunk_id": "1-0", 
                "chunk_text": "This is a test chunk.", 
                "document_id": "1", 
                "embedding": [0.1, 0.2, 0.3]
            },
            {
                "chunk_id": "2-0", 
                "chunk_text": "Another test chunk.", 
                "document_id": "2", 
                "embedding": [0.2, 0.3, 0.4]
            }
        ]
        
        # Call method
        self.target._write_batch(batch)
        
        # Verify query execution
        self.mock_session.run.assert_called_once()
        
        # Check that the query contains MERGE and SET operations
        args, kwargs = self.mock_session.run.call_args
        self.assertIn("UNWIND $batch", args[0])
        self.assertIn("MERGE", args[0])
        self.assertIn("SET", args[0])
        
        # Check batch data was passed correctly
        self.assertEqual(len(kwargs["batch"]), 2)
    
    def test_create_relationships(self):
        """Test creating relationships between nodes."""
        # Create test relationship data
        df = self.create_test_dataframe()
        
        # Add mock relationships
        df = df.withColumn("relationship_field", df["document_id"])
        
        # Set relationship field in target
        self.target.relationship_field = "relationship_field"
        
        # Call method
        self.target._create_relationships(df)
        
        # Verify query execution
        self.mock_session.run.assert_called_once()
        
        # Check that the query contains MATCH and MERGE operations for relationships
        args, kwargs = self.mock_session.run.call_args
        self.assertIn("UNWIND $batch", args[0])
        self.assertIn("MATCH", args[0])
        self.assertIn("MERGE", args[0])
        
        # Check batch data was passed correctly
        self.assertIsNotNone(kwargs.get("batch"), "Batch data not passed to query")
    
    def test_write_data(self):
        """Test writing data to Neo4j."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Call write_data
        self.target.write_data(df)
        
        # Verify driver was initialized
        self.mock_graph_db.driver.assert_called_once()
        
        # Verify indices were created
        index_call = any(
            "db.indexes()" in str(call) for call in self.mock_session.run.call_args_list
        )
        self.assertTrue(index_call, "Index check query not found")
        
        # Verify batch write query was executed
        write_call = any(
            "UNWIND $batch" in str(call) and "MERGE" in str(call) 
            for call in self.mock_session.run.call_args_list
        )
        self.assertTrue(write_call, "Batch write query not found")
    
    def test_write_data_missing_columns(self):
        """Test writing data with missing columns."""
        # Create DataFrame missing required columns
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("text", StringType(), False)
        ])
        
        invalid_df = self.spark.createDataFrame([
            {"id": "1", "text": "Test text"}
        ], schema)
        
        # Should raise an exception
        with self.assertRaises(TargetException) as context:
            self.target.write_data(invalid_df)
        
        self.assertIn("not found in DataFrame", str(context.exception))
    
    def test_write_data_with_relationship_field(self):
        """Test writing data with relationship field."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Add relationship field
        df = df.withColumn("parent_id", df["document_id"])
        
        # Set relationship field in config
        relationship_config = self.config.copy()
        relationship_config["parameters"] = self.config["parameters"].copy()
        relationship_config["parameters"]["relationship_field"] = "parent_id"
        
        # Create new target with relationship config
        target = Neo4jTarget(relationship_config)
        
        # Mock the driver
        target._driver = self.mock_driver
        
        # Write data
        target.write_data(df)
        
        # Verify relationship creation query was executed
        relation_call = any(
            "MATCH" in str(call) and "MERGE" in str(call) and target.relationship_type in str(call)
            for call in self.mock_session.run.call_args_list
        )
        self.assertTrue(relation_call, "Relationship creation query not found")
    
    def test_write_data_error_handling(self):
        """Test error handling during write."""
        # Create test dataframe
        df = self.create_test_dataframe()
        
        # Make driver.session raise an exception
        self.mock_driver.session.side_effect = Exception("Test Neo4j error")
        
        # Should propagate the exception as TargetException
        with self.assertRaises(TargetException) as context:
            self.target.write_data(df)
        
        self.assertIn("Error writing to Neo4j", str(context.exception))
    
    def test_close(self):
        """Test the close method."""
        # Set up mock driver
        self.target._driver = self.mock_driver
        
        # Call close
        self.target.close()
        
        # Verify driver.close was called
        self.mock_driver.close.assert_called_once()
        
        # Verify driver is cleared
        self.assertIsNone(self.target._driver)


if __name__ == "__main__":
    unittest.main() 