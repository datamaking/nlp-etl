"""
Unit tests for vector target implementations.

Tests the following classes:
- ChromaDBTarget
- PostgresVectorTarget
- Neo4jTarget
"""

import unittest
from unittest.mock import MagicMock, patch, call
import pytest
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, FloatType

from src.target.vector_targets import ChromaDBTarget, PostgresVectorTarget, Neo4jTarget
from src.exception import TargetException


class TestVectorTarget(unittest.TestCase):
    """Base test class for vector targets."""
    
    @classmethod
    def setUpClass(cls):
        """Set up Spark session for all tests."""
        cls.spark = SparkSession.builder \
            .appName("VectorTargetTest") \
            .master("local[1]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Stop Spark session after all tests."""
        if cls.spark:
            cls.spark.stop()
    
    def create_test_dataframe(self, num_rows=5, vector_dim=384):
        """
        Create a test DataFrame with embeddings.
        
        Args:
            num_rows: Number of test rows
            vector_dim: Dimension of the test embeddings
            
        Returns:
            DataFrame with test data
        """
        # Create schema for the DataFrame
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("chunk_id", StringType(), False),
            StructField("text", StringType(), True),
            StructField("chunk_text", StringType(), True),
            StructField("doc_id", StringType(), True),
            StructField("metadata", StringType(), True),
            StructField("embedding", ArrayType(FloatType()), True)
        ])
        
        # Create test data
        data = []
        for i in range(num_rows):
            # Generate random embedding vector
            embedding = np.random.rand(vector_dim).tolist()
            
            # Create row
            row = {
                "id": f"doc_{i}",
                "chunk_id": f"chunk_{i}",
                "text": f"Document {i} content",
                "chunk_text": f"Chunk {i} content",
                "doc_id": f"doc_{i}",
                "metadata": f"{{\"source\": \"test_{i}\"}}",
                "embedding": embedding
            }
            data.append(row)
        
        # Create DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df


class TestChromaDBTarget(TestVectorTarget):
    """Tests for ChromaDBTarget."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock the chromadb module
        self.chromadb_mock = MagicMock()
        self.settings_mock = MagicMock()
        self.client_mock = MagicMock()
        self.collection_mock = MagicMock()
        
        # Configure mocks
        self.chromadb_mock.Client.return_value = self.client_mock
        self.client_mock.get_or_create_collection.return_value = self.collection_mock
        
        # Create test config
        self.config = {
            "parameters": {
                "collection_name": "test_collection",
                "persist_directory": "./test_chroma",
                "batch_size": 2,
                "metadata_fields": ["doc_id"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Set up patches
        self.find_spec_patch = patch("importlib.util.find_spec", return_value=True)
        self.chromadb_patch = patch.dict("sys.modules", {"chromadb": self.chromadb_mock, "chromadb.config": self.chromadb_mock})
        
        # Start patches
        self.find_spec_patch.start()
        self.chromadb_patch.start()
    
    def tearDown(self):
        """Clean up after each test."""
        self.find_spec_patch.stop()
        self.chromadb_patch.stop()
    
    def test_validate_config_valid(self):
        """Test valid configuration validation."""
        target = ChromaDBTarget(self.config)
        # Should not raise an exception
    
    def test_validate_config_missing_chromadb(self):
        """Test validation when ChromaDB is not installed."""
        with patch("importlib.util.find_spec", return_value=None):
            with self.assertRaises(TargetException):
                ChromaDBTarget(self.config)
    
    def test_validate_config_no_collection_name(self):
        """Test validation with missing collection name."""
        config = self.config.copy()
        config["parameters"] = self.config["parameters"].copy()
        config["parameters"]["collection_name"] = ""
        
        with self.assertRaises(TargetException):
            ChromaDBTarget(config)
    
    def test_initialize_client(self):
        """Test client initialization."""
        target = ChromaDBTarget(self.config)
        target._initialize_client()
        
        # Check if client was initialized correctly
        self.chromadb_mock.Client.assert_called_once()
        self.client_mock.get_or_create_collection.assert_called_once_with(
            name="test_collection",
            metadata={"description": "Collection created by NLP Pipeline"}
        )
    
    def test_write_data(self):
        """Test writing data to ChromaDB."""
        target = ChromaDBTarget(self.config)
        df = self.create_test_dataframe(5)
        
        target.write_data(df)
        
        # Check if client was initialized
        self.assertEqual(target._client, self.client_mock)
        self.assertEqual(target._collection, self.collection_mock)
        
        # Check if collection add was called with correct arguments
        # There should be 3 calls (5 rows with batch size 2: 2 + 2 + 1)
        self.assertEqual(self.collection_mock.add.call_count, 3)
    
    def test_write_data_missing_column(self):
        """Test writing data with missing column."""
        target = ChromaDBTarget(self.config)
        
        # Create DataFrame without embedding column
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), True)
        ])
        
        data = [{"id": "doc_1", "chunk_id": "chunk_1", "chunk_text": "test"}]
        df = self.spark.createDataFrame(data, schema)
        
        with self.assertRaises(TargetException):
            target.write_data(df)
    
    def test_close(self):
        """Test closing ChromaDB client."""
        target = ChromaDBTarget(self.config)
        target._initialize_client()
        
        # Check that client is initialized
        self.assertIsNotNone(target._client)
        
        # Close client
        target.close()
        
        # Check that client was cleared
        self.assertIsNone(target._client)
        self.assertIsNone(target._collection)


class TestPostgresVectorTarget(TestVectorTarget):
    """Tests for PostgresVectorTarget."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock the psycopg2 module
        self.psycopg2_mock = MagicMock()
        self.connection_mock = MagicMock()
        self.cursor_mock = MagicMock()
        
        # Configure mocks
        self.psycopg2_mock.connect.return_value = self.connection_mock
        self.connection_mock.__enter__.return_value = self.connection_mock
        self.connection_mock.cursor.return_value = self.cursor_mock
        self.cursor_mock.__enter__.return_value = self.cursor_mock
        
        # Create test config
        self.config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "testdb",
                "schema": "public",
                "table": "embeddings",
                "user": "postgres",
                "password": "password",
                "batch_size": 10,
                "vector_dimensions": 384,
                "create_index": True,
                "index_type": "hnsw",
                "enable_extension": True,
                "overwrite": True,
                "metadata_fields": ["doc_id"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Set up patches
        self.find_spec_patch = patch("importlib.util.find_spec", return_value=True)
        self.psycopg2_patch = patch.dict("sys.modules", {"psycopg2": self.psycopg2_mock})
        
        # Start patches
        self.find_spec_patch.start()
        self.psycopg2_patch.start()
    
    def tearDown(self):
        """Clean up after each test."""
        self.find_spec_patch.stop()
        self.psycopg2_patch.stop()
    
    def test_validate_config_valid(self):
        """Test valid configuration validation."""
        target = PostgresVectorTarget(self.config)
        # Should not raise an exception
    
    def test_validate_config_missing_psycopg2(self):
        """Test validation when psycopg2 is not installed."""
        with patch("importlib.util.find_spec", return_value=None):
            with self.assertRaises(TargetException):
                PostgresVectorTarget(self.config)
    
    def test_validate_config_missing_database(self):
        """Test validation with missing database."""
        config = self.config.copy()
        config["parameters"] = self.config["parameters"].copy()
        config["parameters"]["database"] = None
        
        with self.assertRaises(TargetException):
            PostgresVectorTarget(config)
    
    def test_validate_config_missing_user(self):
        """Test validation with missing user."""
        config = self.config.copy()
        config["parameters"] = self.config["parameters"].copy()
        config["parameters"]["user"] = None
        
        with self.assertRaises(TargetException):
            PostgresVectorTarget(config)
    
    def test_initialize_connection(self):
        """Test PostgreSQL connection initialization."""
        target = PostgresVectorTarget(self.config)
        target._initialize_connection()
        
        # Check if connection was established correctly
        self.psycopg2_mock.connect.assert_called_once_with(
            host="localhost",
            port=5432,
            dbname="testdb",
            user="postgres",
            password="password"
        )
        
        # Check if pgvector extension was created
        self.cursor_mock.execute.assert_called_once_with("CREATE EXTENSION IF NOT EXISTS vector")
    
    @patch("pyspark.sql.DataFrame")
    @patch("pyspark.sql.functions.udf")
    @patch("pyspark.sql.types.StringType")
    def test_write_data(self, string_type_mock, udf_mock, df_mock):
        """Test writing data to PostgreSQL."""
        # Configure DataFrame mock
        df_mock.columns = ["chunk_id", "chunk_text", "embedding", "doc_id"]
        df_mock.count.return_value = 5
        
        # Create target and write data
        target = PostgresVectorTarget(self.config)
        with patch.object(target, '_initialize_connection'), patch.object(target, '_create_vector_index'):
            target.write_data(df_mock)
            
            # Check if vector index was created
            target._create_vector_index.assert_called_once()
    
    def test_close(self):
        """Test closing PostgreSQL connection."""
        target = PostgresVectorTarget(self.config)
        target._conn = self.connection_mock
        
        # Close connection
        target.close()
        
        # Check that connection was closed
        self.connection_mock.close.assert_called_once()
        self.assertIsNone(target._conn)


class TestNeo4jTarget(TestVectorTarget):
    """Tests for Neo4jTarget."""
    
    def setUp(self):
        """Set up test environment."""
        # Mock the neo4j module
        self.neo4j_mock = MagicMock()
        self.driver_mock = MagicMock()
        self.session_mock = MagicMock()
        self.result_mock = MagicMock()
        
        # Configure mocks
        self.neo4j_mock.GraphDatabase.driver.return_value = self.driver_mock
        self.driver_mock.session.return_value = self.session_mock
        self.session_mock.__enter__.return_value = self.session_mock
        self.session_mock.run.return_value = self.result_mock
        self.result_mock.single.return_value = {"count": 0, "test": 1}
        
        # Create test config
        self.config = {
            "parameters": {
                "uri": "bolt://localhost:7687",
                "user": "neo4j",
                "password": "password",
                "database": "neo4j",
                "node_label": "Document",
                "chunk_node_label": "Chunk",
                "relationship_type": "HAS_CHUNK",
                "batch_size": 10,
                "create_indices": True,
                "create_constraints": True,
                "vector_dimension": 384,
                "vector_property": "embedding",
                "index_name": "vector_index",
                "similarity_metric": "cosine",
                "document_mapping": {
                    "id": "id",
                    "title": "text"
                },
                "chunk_mapping": {
                    "id": "chunk_id",
                    "text": "chunk_text"
                },
                "metadata_fields": ["doc_id"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "id"
        }
        
        # Set up patches
        self.find_spec_patch = patch("importlib.util.find_spec", return_value=True)
        self.neo4j_patch = patch.dict("sys.modules", {"neo4j": self.neo4j_mock})
        
        # Start patches
        self.find_spec_patch.start()
        self.neo4j_patch.start()
    
    def tearDown(self):
        """Clean up after each test."""
        self.find_spec_patch.stop()
        self.neo4j_patch.stop()
    
    def test_validate_config_valid(self):
        """Test valid configuration validation."""
        target = Neo4jTarget(self.config)
        # Should not raise an exception
    
    def test_validate_config_missing_neo4j(self):
        """Test validation when Neo4j driver is not installed."""
        with patch("importlib.util.find_spec", return_value=None):
            with self.assertRaises(TargetException):
                Neo4jTarget(self.config)
    
    def test_validate_config_missing_password(self):
        """Test validation with missing password."""
        config = self.config.copy()
        config["parameters"] = self.config["parameters"].copy()
        config["parameters"]["password"] = None
        
        with self.assertRaises(TargetException):
            Neo4jTarget(config)
    
    def test_initialize_driver(self):
        """Test Neo4j driver initialization."""
        target = Neo4jTarget(self.config)
        target._initialize_driver()
        
        # Check if driver was initialized correctly
        self.neo4j_mock.GraphDatabase.driver.assert_called_once_with(
            "bolt://localhost:7687",
            auth=("neo4j", "password")
        )
        
        # Check if test connection was made
        self.session_mock.run.assert_called_with("RETURN 1 AS test")
    
    def test_create_indices(self):
        """Test creating indices and constraints in Neo4j."""
        # Configure record mock to indicate vector support
        record_mock = MagicMock()
        record_mock.__getitem__.return_value = "vector"
        self.result_mock.__iter__.return_value = [record_mock]
        
        # Create target and initialize
        target = Neo4jTarget(self.config)
        target._driver = self.driver_mock
        
        # Create indices
        target._create_indices()
        
        # Check that constraints were created
        constraint_calls = [
            call('CREATE CONSTRAINT IF NOT EXISTS FOR (d:Document) \nREQUIRE d.id IS UNIQUE\n'),
            call('CREATE CONSTRAINT IF NOT EXISTS FOR (c:Chunk) \nREQUIRE c.id IS UNIQUE\n')
        ]
        self.session_mock.run.assert_has_calls(constraint_calls, any_order=True)
        
        # Check that vector index was created
        index_calls = [
            call("CALL db.indexes() YIELD provider"),
            call("SHOW VECTOR INDEXES\nYIELD name\nWHERE name = 'vector_index'\nRETURN count(*) as count\n"),
            call("CREATE VECTOR INDEX vector_index\nFOR (c:Chunk)\nON c.embedding\nOPTIONS {indexConfig: {\n    `vector.dimensions`: 384,\n    `vector.similarity_function`: 'cosine'\n}}\n")
        ]
        self.session_mock.run.assert_has_calls(index_calls, any_order=True)
    
    @patch("pyspark.sql.DataFrame")
    def test_write_data(self, df_mock):
        """Test writing data to Neo4j."""
        # Configure row mock
        row1 = MagicMock()
        row1.__getitem__.side_effect = lambda key: {"id": "doc1", "chunk_id": "chunk1", "chunk_text": "text1", "embedding": [0.1]*384}[key]
        row1.__fields__ = ["id", "chunk_id", "chunk_text", "embedding", "doc_id"]
        
        row2 = MagicMock()
        row2.__getitem__.side_effect = lambda key: {"id": "doc2", "chunk_id": "chunk2", "chunk_text": "text2", "embedding": [0.2]*384}[key]
        row2.__fields__ = ["id", "chunk_id", "chunk_text", "embedding", "doc_id"]
        
        # Configure DataFrame mock
        df_mock.columns = ["id", "chunk_id", "chunk_text", "embedding", "doc_id"]
        df_mock.collect.return_value = [row1, row2]
        
        # Create target and initialize
        target = Neo4jTarget(self.config)
        
        # Mock internal methods
        with patch.object(target, '_initialize_driver'), patch.object(target, '_create_indices'), \
             patch.object(target, '_write_batch'), patch.object(target, '_create_relationships'):
            
            target.write_data(df_mock)
            
            # Check if methods were called
            target._initialize_driver.assert_called_once()
            target._create_indices.assert_called_once()
            target._write_batch.assert_called_once_with([row1, row2])
            target._create_relationships.assert_called_once()
    
    def test_close(self):
        """Test closing Neo4j driver."""
        target = Neo4jTarget(self.config)
        target._driver = self.driver_mock
        
        # Close driver
        target.close()
        
        # Check that driver was closed
        self.driver_mock.close.assert_called_once()
        self.assertIsNone(target._driver)


if __name__ == "__main__":
    unittest.main() 