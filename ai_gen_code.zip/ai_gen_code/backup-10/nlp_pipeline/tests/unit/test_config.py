"""
Unit tests for the configuration module.
"""

import os
import unittest
import tempfile
import yaml
from unittest.mock import patch, MagicMock

import pytest

from src.config import PipelineConfig
from src.exception import ConfigurationException


class TestPipelineConfig(unittest.TestCase):
    """Test class for PipelineConfig implementation."""
    
    def setUp(self):
        """Set up each test with a temporary configuration file."""
        # Create a temporary directory
        self.temp_dir = tempfile.mkdtemp()
        
        # Create a valid configuration
        self.valid_config = {
            "pipeline": {
                "name": "test-pipeline",
                "description": "Test pipeline configuration",
                "version": "1.0.0"
            },
            "spark": {
                "app_name": "test-app",
                "master": "local[2]",
                "log_level": "WARN",
                "config": {
                    "spark.driver.memory": "2g",
                    "spark.executor.memory": "2g"
                }
            },
            "source": {
                "type": "text_files",
                "parameters": {
                    "path": "data/input",
                    "file_pattern": "*.txt"
                }
            },
            "preprocessing": {
                "operations": [
                    {"name": "clean_text"},
                    {"name": "normalize_unicode"}
                ]
            },
            "chunking": {
                "type": "paragraph",
                "parameters": {
                    "separator": "\n\n",
                    "min_chunk_size": 100,
                    "max_chunk_size": 1000
                }
            },
            "embedding": {
                "type": "huggingface",
                "parameters": {
                    "model_name": "BAAI/bge-small-en-v1.5",
                    "batch_size": 32
                }
            },
            "target": {
                "type": "postgres_vector",
                "parameters": {
                    "host": "localhost",
                    "port": 5432,
                    "database": "vectordb",
                    "user": "postgres",
                    "password": "postgres"
                }
            },
            "intermediate_storage": {
                "enabled": True,
                "format": "parquet",
                "path": "data/intermediate",
                "mode": "overwrite"
            }
        }
        
        # Create a temp config file
        self.config_path = os.path.join(self.temp_dir, "config.yaml")
        with open(self.config_path, "w") as f:
            yaml.dump(self.valid_config, f)
    
    def tearDown(self):
        """Clean up temporary files."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_init_valid_config(self):
        """Test initialization with valid configuration."""
        config = PipelineConfig(self.config_path)
        
        # Verify basic properties
        self.assertEqual(config.get_pipeline_name(), "test-pipeline")
        self.assertEqual(config.get_pipeline_version(), "1.0.0")
        
        # Verify sections were loaded
        self.assertIsNotNone(config.get_source_config())
        self.assertIsNotNone(config.get_target_config())
    
    def test_init_missing_file(self):
        """Test initialization with missing file."""
        nonexistent_path = os.path.join(self.temp_dir, "nonexistent.yaml")
        
        with self.assertRaises(ConfigurationException):
            PipelineConfig(nonexistent_path)
    
    def test_get_config_sections(self):
        """Test getting configuration sections."""
        config = PipelineConfig(self.config_path)
        
        # Check source config
        source_config = config.get_source_config()
        self.assertEqual(source_config["type"], "text_files")
        
        # Check preprocessing config
        preproc_config = config.get_preprocessing_config()
        self.assertEqual(len(preproc_config["operations"]), 2)
        
        # Check chunking config
        chunking_config = config.get_chunking_config()
        self.assertEqual(chunking_config["type"], "paragraph")
        
        # Check embedding config
        embedding_config = config.get_embedding_config()
        self.assertEqual(embedding_config["type"], "huggingface")
        
        # Check target config
        target_config = config.get_target_config()
        self.assertEqual(target_config["type"], "postgres_vector")
    
    def test_build_spark_session(self):
        """Test building a Spark session."""
        # Mock SparkSession builder
        mock_builder = MagicMock()
        mock_session = MagicMock()
        
        with patch("src.config.config.SparkSession") as mock_spark:
            mock_spark.builder = mock_builder
            mock_builder.appName.return_value = mock_builder
            mock_builder.master.return_value = mock_builder
            mock_builder.config.return_value = mock_builder
            mock_builder.getOrCreate.return_value = mock_session
            
            config = PipelineConfig(self.config_path)
            session = config.build_spark_session()
            
            # Verify session was created with correct parameters
            mock_builder.appName.assert_called_once_with("test-app")
            mock_builder.master.assert_called_once_with("local[2]")
            
            # Verify configs were set
            config_calls = mock_builder.config.call_args_list
            self.assertEqual(len(config_calls), 2)
            
            # Verify session was returned
            self.assertEqual(session, mock_session)
    
    def test_invalid_source_config(self):
        """Test validation with invalid source config."""
        # Create config without source type
        invalid_config = self.valid_config.copy()
        invalid_config["source"] = {"parameters": {}}
        
        # Write to temp file
        invalid_path = os.path.join(self.temp_dir, "invalid.yaml")
        with open(invalid_path, "w") as f:
            yaml.dump(invalid_config, f)
        
        # Should raise exception
        with self.assertRaises(ConfigurationException) as context:
            PipelineConfig(invalid_path)
        
        self.assertIn("Source type must be specified", str(context.exception))
    
    def test_invalid_target_config(self):
        """Test validation with invalid target config."""
        # Create config without target type
        invalid_config = self.valid_config.copy()
        invalid_config["target"] = {"parameters": {}}
        
        # Write to temp file
        invalid_path = os.path.join(self.temp_dir, "invalid.yaml")
        with open(invalid_path, "w") as f:
            yaml.dump(invalid_config, f)
        
        # Should raise exception
        with self.assertRaises(ConfigurationException) as context:
            PipelineConfig(invalid_path)
        
        self.assertIn("Target type must be specified", str(context.exception))
    
    def test_get_value(self):
        """Test getting config values by path."""
        config = PipelineConfig(self.config_path)
        
        # Test getting values at different paths
        self.assertEqual(config.get_value("pipeline.name"), "test-pipeline")
        self.assertEqual(config.get_value("spark.config.spark.driver.memory"), "2g")
        self.assertEqual(config.get_value("source.parameters.path"), "data/input")
        
        # Test default value for nonexistent path
        self.assertIsNone(config.get_value("nonexistent.path"))
        self.assertEqual(config.get_value("nonexistent.path", "default"), "default")
    
    def test_get_intermediate_storage_config(self):
        """Test getting intermediate storage config with defaults."""
        config = PipelineConfig(self.config_path)
        
        # Get storage config
        storage_config = config.get_intermediate_storage_config()
        
        # Check values were loaded correctly
        self.assertTrue(storage_config["enabled"])
        self.assertEqual(storage_config["format"], "parquet")
        self.assertEqual(storage_config["path"], "data/intermediate")
        self.assertEqual(storage_config["mode"], "overwrite")
    
    def test_get_checkpoint_path(self):
        """Test getting checkpoint paths."""
        config = PipelineConfig(self.config_path)
        
        # Check checkpoint paths for different stages
        extraction_path = config.get_checkpoint_path("extraction")
        self.assertEqual(extraction_path, os.path.join("data/intermediate", "extraction"))
        
        preprocessing_path = config.get_checkpoint_path("preprocessing")
        self.assertEqual(preprocessing_path, os.path.join("data/intermediate", "preprocessing"))
    
    def test_with_missing_embedding_type(self):
        """Test validation with missing embedding type."""
        # Create config with embedding section but missing type
        invalid_config = self.valid_config.copy()
        invalid_config["embedding"] = {"parameters": {"model_name": "test-model"}}
        
        # Write to temp file
        invalid_path = os.path.join(self.temp_dir, "invalid.yaml")
        with open(invalid_path, "w") as f:
            yaml.dump(invalid_config, f)
        
        # Should raise exception
        with self.assertRaises(ConfigurationException) as context:
            PipelineConfig(invalid_path)
        
        self.assertIn("Embedding type must be specified", str(context.exception))
    
    def test_get_full_config(self):
        """Test getting the full configuration."""
        config = PipelineConfig(self.config_path)
        
        # Get full config
        full_config = config.get_full_config()
        
        # Should match the original config
        self.assertEqual(full_config["pipeline"]["name"], "test-pipeline")
        self.assertEqual(full_config["source"]["type"], "text_files")
        self.assertEqual(full_config["target"]["type"], "postgres_vector")


if __name__ == "__main__":
    unittest.main() 