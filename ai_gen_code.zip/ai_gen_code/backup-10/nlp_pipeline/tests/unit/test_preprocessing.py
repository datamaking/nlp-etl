"""
Unit tests for preprocessing components.
"""

import unittest
from unittest.mock import patch, MagicMock, call

import pytest
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import StringType

from src.preprocessing.preprocessors import (
    TextPreprocessor,
    BaseTextTransformation,
    CleanTextTransformation,
    RemoveHTMLTagsTransformation,
    RemoveURLsTransformation,
    NormalizeUnicodeTransformation,
    RemoveNumbersTransformation
)
from src.exception import PreprocessingException


class TestPreprocessor(unittest.TestCase):
    """Base test class for preprocessors."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-preprocessor") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        cls.spark.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for preprocessing."""
        data = [
            {"id": "1", "text": "This is a test text with HTML <p>tags</p> and URLs https://example.com."},
            {"id": "2", "text": "Text with numbers 12345 and unicode characters: café résumé."},
            {"id": "3", "text": "Special symbols: &amp; &#39; and multiple   spaces."}
        ]
        return self.spark.createDataFrame(data)


class TestTextPreprocessor(TestPreprocessor):
    """Test the TextPreprocessor class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "operations": [
                    {"name": "clean_text"},
                    {"name": "remove_html_tags"},
                    {"name": "remove_urls"},
                    {"name": "normalize_unicode"}
                ]
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        self.preprocessor = TextPreprocessor(self.config)
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.preprocessor._validate_preprocessor_config()
        
        # Test missing operations
        invalid_config = {
            "parameters": {},
            "text_column": "text",
            "id_column": "id"
        }
        
        with self.assertRaises(PreprocessingException):
            TextPreprocessor(invalid_config)
    
    def test_initialize_transformations(self):
        """Test initialization of transformations."""
        transformations = self.preprocessor._initialize_transformations()
        
        # Check that transformations were created correctly
        self.assertEqual(len(transformations), 4)
        self.assertIsInstance(transformations[0], CleanTextTransformation)
        self.assertIsInstance(transformations[1], RemoveHTMLTagsTransformation)
        self.assertIsInstance(transformations[2], RemoveURLsTransformation)
        self.assertIsInstance(transformations[3], NormalizeUnicodeTransformation)
    
    def test_initialize_with_invalid_operation(self):
        """Test initialization with an invalid operation."""
        config = {
            "parameters": {
                "operations": [
                    {"name": "invalid_operation"}
                ]
            },
            "text_column": "text",
            "id_column": "id"
        }
        
        with self.assertRaises(PreprocessingException):
            TextPreprocessor(config)
    
    def test_process_integration(self):
        """Integration test for the process method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Process the dataframe
        result_df = self.preprocessor.process(df)
        
        # Check the result
        self.assertIsNotNone(result_df)
        self.assertEqual(result_df.count(), 3)
        
        # Check that preprocessing was applied
        rows = result_df.collect()
        for row in rows:
            # HTML tags should be removed
            self.assertNotIn("<p>", row["text"])
            self.assertNotIn("</p>", row["text"])
            
            # URLs should be removed
            self.assertNotIn("https://example.com", row["text"])
    
    @patch('pyspark.sql.functions.udf')
    def test_process_with_mocks(self, mock_udf):
        """Test the process method with mocks."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Mock the withColumn method
        mock_withcolumn = MagicMock()
        df.withColumn = MagicMock(return_value=mock_withcolumn)
        
        # Call the process method
        result_df = self.preprocessor.process(df)
        
        # Verify the calls
        df.withColumn.assert_called_once()
        
        # Check that the UDF was created
        mock_udf.assert_called_once()


class TestTextTransformations(unittest.TestCase):
    """Test individual text transformation classes."""
    
    def test_base_transformation(self):
        """Test the BaseTextTransformation class."""
        # BaseTextTransformation is abstract and should not be instantiated directly
        with self.assertRaises(TypeError):
            BaseTextTransformation()
    
    def test_clean_text_transformation(self):
        """Test the CleanTextTransformation class."""
        transformation = CleanTextTransformation()
        
        # Test with multiple spaces
        text = "This   has    multiple    spaces."
        result = transformation.transform(text)
        self.assertEqual(result, "This has multiple spaces.")
        
        # Test with special characters
        text = "Text with &amp; &#39; entities."
        result = transformation.transform(text)
        self.assertEqual(result, "Text with & ' entities.")
    
    def test_remove_html_tags_transformation(self):
        """Test the RemoveHTMLTagsTransformation class."""
        transformation = RemoveHTMLTagsTransformation()
        
        # Test with HTML tags
        text = "<p>This is a <b>paragraph</b> with <i>HTML</i> tags.</p>"
        result = transformation.transform(text)
        self.assertEqual(result, "This is a paragraph with HTML tags.")
        
        # Test with complex HTML
        text = "<div class='content'><h1>Title</h1><p>Text</p></div>"
        result = transformation.transform(text)
        self.assertEqual(result, "TitleText")
    
    def test_remove_urls_transformation(self):
        """Test the RemoveURLsTransformation class."""
        transformation = RemoveURLsTransformation()
        
        # Test with URLs
        text = "Visit https://example.com for more information."
        result = transformation.transform(text)
        self.assertEqual(result, "Visit  for more information.")
        
        # Test with multiple URLs
        text = "Links: http://site1.com and https://site2.org/path?query=value"
        result = transformation.transform(text)
        self.assertEqual(result, "Links:  and ")
    
    def test_normalize_unicode_transformation(self):
        """Test the NormalizeUnicodeTransformation class."""
        transformation = NormalizeUnicodeTransformation()
        
        # Test with accented characters
        text = "café résumé"
        result = transformation.transform(text)
        self.assertEqual(result, "cafe resume")
        
        # Test with more unicode characters
        text = "naïve jalapeño"
        result = transformation.transform(text)
        self.assertEqual(result, "naive jalapeno")
    
    def test_remove_numbers_transformation(self):
        """Test the RemoveNumbersTransformation class."""
        transformation = RemoveNumbersTransformation()
        
        # Test with numbers
        text = "Text with numbers 12345."
        result = transformation.transform(text)
        self.assertEqual(result, "Text with numbers .")
        
        # Test with mixed content
        text = "Price is $99.99 for item #A2C4-789."
        result = transformation.transform(text)
        self.assertEqual(result, "Price is $. for item #A-.")


if __name__ == "__main__":
    unittest.main() 