"""
Unit tests for embedding components.
"""

import unittest
from unittest.mock import patch, MagicMock, call

import pytest
import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.embedding.embedders import (
    OpenAIEmbedder,
    HuggingFaceEmbedder
)
from src.exception import EmbeddingException


class TestEmbedder(unittest.TestCase):
    """Base test class for embedders."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-embedder") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        cls.spark.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for embedding."""
        data = [
            {"chunk_id": "1-0", "chunk_text": "This is a test chunk.", "chunk_index": 0, "id": "1"},
            {"chunk_id": "2-0", "chunk_text": "Another test chunk for embedding.", "chunk_index": 0, "id": "2"},
            {"chunk_id": "3-0", "chunk_text": "A third chunk to embed.", "chunk_index": 0, "id": "3"}
        ]
        return self.spark.createDataFrame(data)


class TestOpenAIEmbedder(TestEmbedder):
    """Test the OpenAIEmbedder class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "api_key": "test-api-key",
                "model": "text-embedding-ada-002",
                "batch_size": 10,
                "dimensions": 1536,
                "api_base": "https://api.openai.com/v1",
                "api_type": "open_ai"
            },
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        self.patcher = patch('src.embedding.embedders.OpenAI')
        self.mock_openai = self.patcher.start()
        self.mock_client = MagicMock()
        self.mock_openai.return_value = self.mock_client
        
        # Mock embeddings client and response
        self.mock_embeddings = MagicMock()
        self.mock_client.embeddings = self.mock_embeddings
        
        # Setup mock response
        mock_embedding = MagicMock()
        mock_embedding.embedding = [0.1] * 1536
        mock_response = MagicMock()
        mock_response.data = [mock_embedding]
        self.mock_embeddings.create.return_value = mock_response
        
        self.embedder = OpenAIEmbedder(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.patcher.stop()
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.embedder._validate_embedder_config()
        
        # Test missing API key
        invalid_config = {
            "parameters": {
                "model": "text-embedding-ada-002"
            },
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        with self.assertRaises(EmbeddingException):
            OpenAIEmbedder(invalid_config)
    
    def test_initialize_client(self):
        """Test client initialization."""
        self.embedder._initialize_client()
        
        # Check that the OpenAI client was created with the correct parameters
        self.mock_openai.assert_called_once_with(
            api_key="test-api-key",
            base_url="https://api.openai.com/v1"
        )
    
    @patch('pyspark.sql.functions.udf')
    def test_process(self, mock_udf):
        """Test the process method with mocks."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Mock the withColumn method
        mock_withcolumn = MagicMock()
        df.withColumn = MagicMock(return_value=mock_withcolumn)
        
        # Call the process method
        result_df = self.embedder.process(df)
        
        # Verify the calls
        df.withColumn.assert_called_once()
        
        # Check that the UDF was created
        mock_udf.assert_called_once()
    
    def test_get_embedding(self):
        """Test the _get_embedding method."""
        # Test with a single text
        embedding = self.embedder._get_embedding("This is a test chunk.")
        
        # Check calls to the OpenAI API
        self.mock_embeddings.create.assert_called_once()
        
        # Check result
        self.assertIsNotNone(embedding)
        self.assertEqual(len(embedding), 1536)  # Dimensions from config
    
    def test_get_embeddings_batch(self):
        """Test the _get_embeddings_batch method."""
        # Test with a batch of texts
        texts = ["Text 1", "Text 2", "Text 3"]
        embeddings = self.embedder._get_embeddings_batch(texts)
        
        # Check calls to the OpenAI API
        self.mock_embeddings.create.assert_called_once()
        
        # Check result
        self.assertIsNotNone(embeddings)
        self.assertEqual(len(embeddings), 3)
        for emb in embeddings:
            self.assertEqual(len(emb), 1536)  # Dimensions from config


class TestHuggingFaceEmbedder(TestEmbedder):
    """Test the HuggingFaceEmbedder class."""
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "model": "sentence-transformers/all-MiniLM-L6-v2",
                "batch_size": 8,
                "device": "cpu",
                "max_length": 512
            },
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Mock the SentenceTransformer class
        self.patcher = patch('src.embedding.embedders.SentenceTransformer')
        self.mock_sentence_transformer = self.patcher.start()
        self.mock_model = MagicMock()
        self.mock_sentence_transformer.return_value = self.mock_model
        
        # Setup mock encode method to return random embeddings
        def mock_encode(texts, **kwargs):
            if isinstance(texts, str):
                return np.random.rand(384)  # Single text
            else:
                return np.random.rand(len(texts), 384)  # Batch
            
        self.mock_model.encode.side_effect = mock_encode
        
        self.embedder = HuggingFaceEmbedder(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.patcher.stop()
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.embedder._validate_embedder_config()
        
        # Test missing model
        invalid_config = {
            "parameters": {
                "batch_size": 8
            },
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        with self.assertRaises(EmbeddingException):
            HuggingFaceEmbedder(invalid_config)
    
    def test_initialize_model(self):
        """Test model initialization."""
        self.embedder._initialize_model()
        
        # Check that the model was loaded with the correct parameters
        self.mock_sentence_transformer.assert_called_with(
            "sentence-transformers/all-MiniLM-L6-v2",
            device="cpu"
        )
    
    @patch('pyspark.sql.functions.udf')
    def test_process(self, mock_udf):
        """Test the process method with mocks."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Mock the withColumn method
        mock_withcolumn = MagicMock()
        df.withColumn = MagicMock(return_value=mock_withcolumn)
        
        # Call the process method
        result_df = self.embedder.process(df)
        
        # Verify the calls
        df.withColumn.assert_called_once()
        
        # Check that the UDF was created
        mock_udf.assert_called_once()
    
    def test_get_embedding(self):
        """Test the _get_embedding method."""
        # Test with a single text
        embedding = self.embedder._get_embedding("This is a test chunk.")
        
        # Check calls to the model
        self.mock_model.encode.assert_called_once()
        
        # Check result
        self.assertIsNotNone(embedding)
        self.assertEqual(len(embedding), 384)  # Default size for the mocked model
    
    def test_get_embeddings_batch(self):
        """Test the _get_embeddings_batch method."""
        # Test with a batch of texts
        texts = ["Text 1", "Text 2", "Text 3"]
        embeddings = self.embedder._get_embeddings_batch(texts)
        
        # Check calls to the model
        self.mock_model.encode.assert_called_once()
        
        # Check result
        self.assertIsNotNone(embeddings)
        self.assertEqual(len(embeddings), 3)
        for emb in embeddings:
            self.assertEqual(len(emb), 384)  # Default size for the mocked model


if __name__ == "__main__":
    unittest.main() 