"""
Integration tests for Neo4j vector target.

Note: These tests require a running Neo4j instance.
To run these tests, set the NEO4J_TEST_URI, NEO4J_TEST_USER,
and NEO4J_TEST_PASSWORD environment variables.
"""

import os
import unittest
import pytest
from unittest.mock import patch

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import Neo4jTarget
from src.exception.exceptions import TargetException

# Skip all tests if environment variables are not set
skip_tests = not all([
    os.environ.get("NEO4J_TEST_URI"),
    os.environ.get("NEO4J_TEST_USER"),
    os.environ.get("NEO4J_TEST_PASSWORD")
])


@pytest.mark.skipif(skip_tests, reason="Neo4j connection parameters not set")
class TestNeo4jIntegration(unittest.TestCase):
    """Integration tests for Neo4j vector target."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session and Neo4j connection."""
        cls.spark = SparkSession.builder \
            .appName("test-neo4j-integration") \
            .master("local[2]") \
            .getOrCreate()
        
        # Get connection parameters from environment
        cls.uri = os.environ.get("NEO4J_TEST_URI", "neo4j://localhost:7687")
        cls.user = os.environ.get("NEO4J_TEST_USER", "neo4j")
        cls.password = os.environ.get("NEO4J_TEST_PASSWORD", "")
        cls.database = os.environ.get("NEO4J_TEST_DATABASE", "neo4j")
        
        # Use a unique label for test data to avoid conflicts
        cls.test_label = f"TestChunk_{os.getpid()}"
        cls.test_doc_label = f"TestDoc_{os.getpid()}"
    
    @classmethod
    def tearDownClass(cls):
        """Clean up the Spark session."""
        cls.spark.stop()
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "uri": self.uri,
                "user": self.user,
                "password": self.password,
                "database": self.database,
                "node_label": self.test_label,
                "document_label": self.test_doc_label,
                "relationship_type": "TEST_PART_OF",
                "batch_size": 10,
                "vector_dimension": 4,
                "create_vector_index": True,
                "vector_index_name": f"{self.test_label}_vector_index",
                "similarity_metric": "cosine",
                "create_constraints": True
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        self.target = Neo4jTarget(self.config)
        
        # Initialize driver and clean up previous test data
        self.target._initialize_driver()
        self.clean_test_data()
    
    def tearDown(self):
        """Clean up after each test."""
        self.clean_test_data()
        self.target.close()
    
    def clean_test_data(self):
        """Remove test data from Neo4j."""
        with self.target._driver.session(database=self.database) as session:
            # Delete test nodes
            session.run(f"MATCH (n:{self.test_label}) DETACH DELETE n")
            session.run(f"MATCH (n:{self.test_doc_label}) DETACH DELETE n")
            
            # Drop constraints and indices if they exist
            try:
                session.run(f"DROP CONSTRAINT {self.test_label}_id_unique IF EXISTS")
            except Exception:
                pass
            
            try:
                session.run(f"CALL db.index.vector.drop('{self.test_label}_vector_index') YIELD name RETURN name")
            except Exception:
                pass
    
    def create_test_dataframe(self):
        """Create a test DataFrame for vector storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("chunk_index", StringType(), False),
            StructField("id", StringType(), False),
            StructField("embedding", ArrayType(FloatType()), False),
            StructField("filename", StringType(), True),
            StructField("path", StringType(), True)
        ])
        
        # Create sample data with small embeddings for quick tests
        data = [
            {
                "chunk_id": "doc1-0", 
                "chunk_text": "This is a test chunk from document 1.", 
                "chunk_index": "0", 
                "id": "doc1", 
                "embedding": [0.1, 0.2, 0.3, 0.4],
                "filename": "doc1.txt",
                "path": "/data/doc1.txt"
            },
            {
                "chunk_id": "doc1-1", 
                "chunk_text": "This is another chunk from document 1.", 
                "chunk_index": "1", 
                "id": "doc1", 
                "embedding": [0.2, 0.3, 0.4, 0.5],
                "filename": "doc1.txt",
                "path": "/data/doc1.txt"
            },
            {
                "chunk_id": "doc2-0", 
                "chunk_text": "This is a chunk from document 2.", 
                "chunk_index": "0", 
                "id": "doc2", 
                "embedding": [0.3, 0.4, 0.5, 0.6],
                "filename": "doc2.txt",
                "path": "/data/doc2.txt"
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df
    
    def test_create_indices(self):
        """Test creating indices in Neo4j."""
        # Create indices
        self.target._create_indices()
        
        # Verify that the indices were created
        with self.target._driver.session(database=self.database) as session:
            # Check for constraints
            result = session.run("SHOW CONSTRAINTS")
            constraints = [record for record in result]
            constraint_found = False
            
            for constraint in constraints:
                if constraint.get("name", "").startswith(f"{self.test_label}_id_unique"):
                    constraint_found = True
                    break
            
            self.assertTrue(constraint_found, "Constraint was not created")
            
            # Check for vector index - this might not work in all Neo4j versions
            try:
                result = session.run("SHOW INDEX")
                indices = [record for record in result]
                index_found = False
                
                for index in indices:
                    if index.get("name", "").startswith(f"{self.test_label}_vector_index"):
                        index_found = True
                        break
                
                self.assertTrue(index_found, "Vector index was not created")
            except Exception:
                # If the SHOW INDEX command fails, it might be due to version differences
                # In this case, we'll skip this assertion
                pass
    
    def test_write_data(self):
        """Test writing data to Neo4j."""
        # Create test data
        df = self.create_test_dataframe()
        
        # Write data to Neo4j
        self.target.write_data(df)
        
        # Verify that the data was written
        with self.target._driver.session(database=self.database) as session:
            # Check chunk nodes
            result = session.run(f"MATCH (c:{self.test_label}) RETURN count(c) as count")
            chunk_count = result.single()["count"]
            self.assertEqual(chunk_count, 3, "Not all chunk nodes were created")
            
            # Check document nodes
            result = session.run(f"MATCH (d:{self.test_doc_label}) RETURN count(d) as count")
            doc_count = result.single()["count"]
            self.assertEqual(doc_count, 2, "Not all document nodes were created")
            
            # Check relationships
            result = session.run(
                f"MATCH (c:{self.test_label})-[r:TEST_PART_OF]->(d:{self.test_doc_label}) "
                f"RETURN count(r) as count"
            )
            rel_count = result.single()["count"]
            self.assertEqual(rel_count, 3, "Not all relationships were created")
            
            # Check node properties
            result = session.run(
                f"MATCH (c:{self.test_label}) WHERE c.chunk_id = 'doc1-0' "
                f"RETURN c.chunk_text, c.embedding"
            )
            node = result.single()
            self.assertEqual(
                node["c.chunk_text"], 
                "This is a test chunk from document 1.",
                "Chunk text property not set correctly"
            )
            self.assertEqual(
                len(node["c.embedding"]), 
                4,
                "Embedding not stored correctly"
            )
    
    def test_vector_search(self):
        """Test vector similarity search in Neo4j."""
        # Create test data
        df = self.create_test_dataframe()
        
        # Write data to Neo4j
        self.target.write_data(df)
        
        # Simple vector to use for similarity search
        query_vector = [0.1, 0.2, 0.3, 0.4]
        
        # Perform vector search
        with self.target._driver.session(database=self.database) as session:
            # This query depends on Neo4j version and vector capabilities
            try:
                result = session.run(
                    f"MATCH (c:{self.test_label}) "
                    f"WITH c, vector.similarity(c.embedding, $query_vector) AS score "
                    f"ORDER BY score DESC "
                    f"LIMIT 2 "
                    f"RETURN c.chunk_id, score",
                    query_vector=query_vector
                )
                
                results = [record for record in result]
                self.assertEqual(len(results), 2, "Should return 2 results")
                
                # First result should be "doc1-0" as it has the same vector as the query
                self.assertEqual(results[0]["c.chunk_id"], "doc1-0")
                self.assertAlmostEqual(results[0]["score"], 1.0, places=4)
            except Exception as e:
                # If vector search fails, it might be because the Neo4j instance
                # doesn't support vector operations, so we'll skip this test
                print(f"Skipping vector search test: {str(e)}")
                pytest.skip("Neo4j vector search not supported in this version")


if __name__ == "__main__":
    unittest.main() 