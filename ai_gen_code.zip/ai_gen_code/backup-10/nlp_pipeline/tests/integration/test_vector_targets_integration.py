"""
Integration tests for vector target implementations.

These tests demonstrate how to use the vector targets with actual data.
Note: These tests require actual database connections, so they should be
      skipped unless the necessary services are available.
"""

import os
import pytest
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, FloatType

from src.target.vector_targets import ChromaDBTarget, PostgresVectorTarget, Neo4jTarget


# Skip all tests if the INTEGRATION_TESTS environment variable is not set to "1"
pytestmark = pytest.mark.skipif(
    os.environ.get("INTEGRATION_TESTS") != "1",
    reason="Integration tests are disabled. Set INTEGRATION_TESTS=1 to enable."
)


@pytest.fixture(scope="module")
def spark():
    """Create a Spark session for testing."""
    spark = SparkSession.builder \
        .appName("VectorTargetIntegrationTest") \
        .master("local[2]") \
        .config("spark.driver.memory", "1g") \
        .getOrCreate()
    
    yield spark
    
    spark.stop()


@pytest.fixture(scope="module")
def test_dataframe(spark):
    """Create a test DataFrame with embeddings."""
    # Define schema
    schema = StructType([
        StructField("id", StringType(), False),
        StructField("chunk_id", StringType(), False),
        StructField("text", StringType(), True),
        StructField("chunk_text", StringType(), True),
        StructField("doc_id", StringType(), True),
        StructField("metadata", StringType(), True),
        StructField("embedding", ArrayType(FloatType()), True)
    ])
    
    # Create sample data
    data = []
    for i in range(10):
        # Generate random embedding vector (384 dimensions)
        embedding = np.random.rand(384).tolist()
        
        # Create document
        row = {
            "id": f"integration_doc_{i}",
            "chunk_id": f"integration_chunk_{i}",
            "text": f"Integration test document {i}",
            "chunk_text": f"Integration test chunk {i} with content for vector search",
            "doc_id": f"integration_doc_{i}",
            "metadata": f"{{\"source\": \"integration_test\", \"category\": \"test_{i % 3}\"}}",
            "embedding": embedding
        }
        data.append(row)
    
    # Create DataFrame
    return spark.createDataFrame(data, schema)


@pytest.mark.chroma
def test_chromadb_target(test_dataframe):
    """Test writing to and querying from ChromaDB."""
    # Configure ChromaDB target
    config = {
        "parameters": {
            "collection_name": "integration_test_collection",
            "persist_directory": "./temp_chroma",
            "batch_size": 5,
            "metadata_fields": ["doc_id", "metadata"]
        },
        "embedding_column": "embedding",
        "text_column": "chunk_text",
        "id_column": "chunk_id"
    }
    
    # Create target
    target = ChromaDBTarget(config)
    
    # Write data
    try:
        target.write_data(test_dataframe)
        
        # Verify data was written by performing a query
        import chromadb
        
        # Create client and get collection
        client = chromadb.Client(chromadb.config.Settings(
            persist_directory="./temp_chroma"
        ))
        
        collection = client.get_collection("integration_test_collection")
        
        # Count documents
        all_ids = collection.get()["ids"]
        assert len(all_ids) == 10, f"Expected 10 documents, found {len(all_ids)}"
        
        # Query with random embedding
        query_embedding = np.random.rand(384).tolist()
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=3
        )
        
        # Verify results format
        assert len(results["ids"][0]) == 3, "Expected 3 results"
        assert "distances" in results, "Expected distances in results"
        
        # Clean up test collection
        client.delete_collection("integration_test_collection")
        
    finally:
        # Close target
        target.close()


@pytest.mark.postgres
def test_postgres_vector_target(test_dataframe):
    """Test writing to and querying from PostgreSQL with pgvector."""
    # Configure PostgreSQL target
    config = {
        "parameters": {
            "host": "localhost",
            "port": 5432,
            "database": "vectordb",
            "schema": "public",
            "table": "integration_test_embeddings",
            "user": "postgres",
            "password": "postgres",
            "batch_size": 5,
            "vector_dimensions": 384,
            "create_index": True,
            "index_type": "hnsw",
            "enable_extension": True,
            "overwrite": True,
            "metadata_fields": ["doc_id", "metadata"]
        },
        "embedding_column": "embedding",
        "text_column": "chunk_text",
        "id_column": "chunk_id"
    }
    
    # Create target
    target = PostgresVectorTarget(config)
    
    # Write data
    try:
        target.write_data(test_dataframe)
        
        # Verify data was written by querying
        import psycopg2
        
        # Connect to database
        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            dbname="vectordb",
            user="postgres",
            password="postgres"
        )
        
        # Query count
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) FROM integration_test_embeddings")
            count = cursor.fetchone()[0]
            assert count == 10, f"Expected 10 rows, found {count}"
            
            # Query using vector similarity
            cursor.execute("""
            SELECT chunk_id, chunk_text 
            FROM integration_test_embeddings 
            ORDER BY embedding <-> '[0.1, 0.2, 0.3]'::vector(384) 
            LIMIT 3
            """)
            
            results = cursor.fetchall()
            assert len(results) == 3, "Expected 3 results from similarity query"
            
            # Clean up
            cursor.execute("DROP TABLE IF EXISTS integration_test_embeddings")
            conn.commit()
        
        conn.close()
        
    finally:
        # Close target
        target.close()


@pytest.mark.neo4j
def test_neo4j_target(test_dataframe):
    """Test writing to and querying from Neo4j."""
    # Configure Neo4j target
    config = {
        "parameters": {
            "uri": "bolt://localhost:7687",
            "user": "neo4j",
            "password": "password",
            "database": "neo4j",
            "node_label": "IntegrationDocument",
            "chunk_node_label": "IntegrationChunk",
            "relationship_type": "HAS_INTEGRATION_CHUNK",
            "batch_size": 5,
            "create_indices": True,
            "create_constraints": True,
            "vector_dimension": 384,
            "vector_property": "embedding",
            "index_name": "integration_vector_index",
            "similarity_metric": "cosine",
            "document_mapping": {
                "id": "id",
                "title": "text"
            },
            "chunk_mapping": {
                "id": "chunk_id",
                "text": "chunk_text"
            },
            "metadata_fields": ["doc_id", "metadata"]
        },
        "embedding_column": "embedding",
        "text_column": "chunk_text",
        "id_column": "id"
    }
    
    # Create target
    target = Neo4jTarget(config)
    
    # Write data
    try:
        target.write_data(test_dataframe)
        
        # Verify data was written using Neo4j driver
        import neo4j
        
        # Connect to Neo4j
        driver = neo4j.GraphDatabase.driver(
            "bolt://localhost:7687",
            auth=("neo4j", "password")
        )
        
        with driver.session(database="neo4j") as session:
            # Count documents
            result = session.run("""
            MATCH (d:IntegrationDocument)
            RETURN COUNT(d) AS count
            """)
            
            count = result.single()["count"]
            assert count == 10, f"Expected 10 documents, found {count}"
            
            # Count chunks
            result = session.run("""
            MATCH (c:IntegrationChunk)
            RETURN COUNT(c) AS count
            """)
            
            count = result.single()["count"]
            assert count == 10, f"Expected 10 chunks, found {count}"
            
            # Verify relationships
            result = session.run("""
            MATCH (d:IntegrationDocument)-[r:HAS_INTEGRATION_CHUNK]->(c:IntegrationChunk)
            RETURN COUNT(r) AS count
            """)
            
            count = result.single()["count"]
            assert count == 10, f"Expected 10 relationships, found {count}"
            
            # Check vector similarity search (requires Neo4j 5.11+)
            try:
                result = session.run("""
                MATCH (c:IntegrationChunk)
                WITH c, gds.similarity.cosine(c.embedding, $embedding) AS score
                RETURN c.id, c.text, score
                ORDER BY score DESC
                LIMIT 3
                """, {"embedding": [0.1] * 384})
                
                results = list(result)
                assert len(results) > 0, "Expected results from vector similarity query"
            except Exception as e:
                print(f"Vector similarity query failed (this is expected if Neo4j version < 5.11): {e}")
            
            # Clean up
            session.run("""
            MATCH (d:IntegrationDocument)
            DETACH DELETE d
            """)
            
            session.run("""
            MATCH (c:IntegrationChunk)
            DETACH DELETE c
            """)
            
            try:
                session.run(f"DROP VECTOR INDEX integration_vector_index")
            except:
                pass
            
        driver.close()
        
    finally:
        # Close target
        target.close() 