#!/usr/bin/env python
"""
Example script demonstrating how to use the PostgreSQL vector target
to store text chunks with embeddings in a PostgreSQL database with
vector extension capabilities (pgvector).
"""

import os
import sys
import yaml
import logging
from pathlib import Path

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf, struct, lit
from pyspark.sql.types import ArrayType, FloatType

# Add the src directory to the Python path
sys.path.append(str(Path(__file__).parent.parent))

from src.target.vector_targets import PostgresVectorTarget
from src.exception.exceptions import TargetException

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("postgres_example")


def load_config(config_path):
    """Load the target configuration from a YAML file."""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Extract only the target section
    return config["target"]


def create_sample_data(spark):
    """Create a sample DataFrame with text chunks and embeddings."""
    # Define some sample text chunks
    chunks = [
        {
            "chunk_id": f"doc{i}-{j}",
            "chunk_text": f"This is chunk {j} from document {i}.",
            "chunk_index": j,
            "id": f"doc{i}",
            "filename": f"doc{i}.txt",
            "path": f"/data/doc{i}.txt",
            "file_size": 1000 * i,
            "last_modified": "2023-01-01",
        }
        for i in range(1, 4)  # 3 documents
        for j in range(2)     # 2 chunks per document
    ]
    
    # Create a DataFrame
    df = pd.DataFrame(chunks)
    
    # Generate random embeddings (384-dimensional for compatibility with models like BGE)
    EMBEDDING_DIM = 384
    embeddings = [np.random.rand(EMBEDDING_DIM).tolist() for _ in range(len(df))]
    df["embedding"] = embeddings
    
    # Convert to Spark DataFrame
    spark_df = spark.createDataFrame(df)
    return spark_df


def main():
    """Run the example."""
    # Parse command line arguments
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_file>")
        print(f"Example: {sys.argv[0]} examples/postgres_vector_config.yaml")
        sys.exit(1)
    
    config_path = sys.argv[1]
    
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName("postgres-vector-example") \
        .master("local[*]") \
        .config("spark.driver.memory", "4g") \
        .getOrCreate()
    
    try:
        # Load configuration
        logger.info(f"Loading configuration from {config_path}")
        target_config = load_config(config_path)
        
        # Create sample data
        logger.info("Creating sample data")
        df = create_sample_data(spark)
        logger.info(f"Created {df.count()} sample chunks")
        
        # Display sample data
        logger.info("Sample data schema:")
        df.printSchema()
        logger.info("Sample data (first row):")
        df.limit(1).show(truncate=False)
        
        # Initialize PostgreSQL vector target
        logger.info("Initializing PostgreSQL vector target")
        target = PostgresVectorTarget(target_config)
        
        # Write data to PostgreSQL
        logger.info("Writing data to PostgreSQL")
        target.write_data(df)
        
        # Close the target
        logger.info("Closing PostgreSQL target")
        target.close()
        
        logger.info("Successfully wrote data to PostgreSQL!")
        
        # Display example SQL queries
        schema = target_config["parameters"].get("schema", "public")
        chunk_table = target_config["parameters"].get("chunk_table", "chunks")
        document_table = target_config["parameters"].get("document_table", "documents")
        
        print("\nExample SQL queries to retrieve data:")
        print("-----------------------------------------")
        print(f"-- Get all chunks")
        print(f"SELECT chunk_id, chunk_text FROM {schema}.{chunk_table} LIMIT 10;")
        print()
        print(f"-- Get all documents")
        print(f"SELECT id, filename, path FROM {schema}.{document_table} LIMIT 10;")
        print()
        print(f"-- Get chunks for a specific document")
        print(f"SELECT c.chunk_id, c.chunk_text FROM {schema}.{chunk_table} c")
        print(f"WHERE c.document_id = 'doc1';")
        print()
        print(f"-- Vector similarity search with L2 distance (pgvector)")
        print(f"SELECT chunk_id, chunk_text, embedding <-> $1 as distance")
        print(f"FROM {schema}.{chunk_table}")
        print(f"ORDER BY distance")
        print(f"LIMIT 5;")
        print()
        print(f"-- Vector similarity search with cosine distance (pgvector)")
        print(f"SELECT chunk_id, chunk_text, embedding <=> $1 as distance")
        print(f"FROM {schema}.{chunk_table}")
        print(f"ORDER BY distance")
        print(f"LIMIT 5;")
        
        print("\nExample Python code to query with psycopg2:")
        print("-----------------------------------------")
        print("```python")
        print("import psycopg2")
        print("import numpy as np")
        print("")
        print("# Connect to the database")
        print(f"conn = psycopg2.connect(")
        print(f"    host='{target_config['parameters'].get('host', 'localhost')}',")
        print(f"    port={target_config['parameters'].get('port', 5432)},")
        print(f"    database='{target_config['parameters'].get('database', 'vectordb')}',")
        print(f"    user='{target_config['parameters'].get('user', 'postgres')}',")
        print(f"    password='your-password'")
        print(f")")
        print("")
        print("# Create a cursor")
        print("cur = conn.cursor()")
        print("")
        print("# Generate a query vector (must match your vector dimension)")
        print(f"query_vector = np.random.rand({target_config['parameters'].get('vector_dimension', 384)}).tolist()")
        print("")
        print("# Execute a vector similarity search")
        print(f"cur.execute(")
        print(f"    \"SELECT chunk_id, chunk_text, embedding <=> %s as distance FROM {schema}.{chunk_table} ORDER BY distance LIMIT 5\",")
        print(f"    (query_vector,)")
        print(f")")
        print("")
        print("# Fetch and print results")
        print("for record in cur.fetchall():")
        print("    print(f\"Chunk ID: {record[0]}, Text: {record[1]}, Distance: {record[2]}\")")
        print("")
        print("# Close the connection")
        print("cur.close()")
        print("conn.close()")
        print("```")
        
    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        sys.exit(1)
    finally:
        # Stop the Spark session
        spark.stop()


if __name__ == "__main__":
    main() 