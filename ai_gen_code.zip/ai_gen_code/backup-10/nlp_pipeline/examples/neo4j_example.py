#!/usr/bin/env python
"""
Example script demonstrating how to use the Neo4j vector target
to store text chunks with embeddings in a Neo4j database.
"""

import os
import sys
import yaml
import logging
from pathlib import Path

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf, struct, lit
from pyspark.sql.types import ArrayType, FloatType

# Add the src directory to the Python path
sys.path.append(str(Path(__file__).parent.parent))

from src.target.vector_targets import Neo4jTarget
from src.exception.exceptions import TargetException

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("neo4j_example")


def load_config(config_path):
    """Load the target configuration from a YAML file."""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Extract only the target section
    return config["target"]


def create_sample_data(spark):
    """Create a sample DataFrame with text chunks and embeddings."""
    # Define some sample text chunks
    chunks = [
        {
            "chunk_id": f"doc{i}-{j}",
            "chunk_text": f"This is chunk {j} from document {i}.",
            "chunk_index": j,
            "id": f"doc{i}",
            "filename": f"doc{i}.txt",
            "path": f"/data/doc{i}.txt",
            "last_modified": "2023-01-01",
        }
        for i in range(1, 4)  # 3 documents
        for j in range(2)     # 2 chunks per document
    ]
    
    # Create a DataFrame
    df = pd.DataFrame(chunks)
    
    # Generate random embeddings (384-dimensional for compatibility with models like BGE)
    EMBEDDING_DIM = 384
    embeddings = [np.random.rand(EMBEDDING_DIM).tolist() for _ in range(len(df))]
    df["embedding"] = embeddings
    
    # Convert to Spark DataFrame
    spark_df = spark.createDataFrame(df)
    return spark_df


def main():
    """Run the example."""
    # Parse command line arguments
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_file>")
        print(f"Example: {sys.argv[0]} examples/neo4j_vector_config.yaml")
        sys.exit(1)
    
    config_path = sys.argv[1]
    
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName("neo4j-example") \
        .master("local[*]") \
        .config("spark.driver.memory", "4g") \
        .getOrCreate()
    
    try:
        # Load configuration
        logger.info(f"Loading configuration from {config_path}")
        target_config = load_config(config_path)
        
        # Create sample data
        logger.info("Creating sample data")
        df = create_sample_data(spark)
        logger.info(f"Created {df.count()} sample chunks")
        
        # Display sample data
        logger.info("Sample data schema:")
        df.printSchema()
        logger.info("Sample data (first row):")
        df.limit(1).show(truncate=False)
        
        # Initialize Neo4j target
        logger.info("Initializing Neo4j target")
        target = Neo4jTarget(target_config)
        
        # Write data to Neo4j
        logger.info("Writing data to Neo4j")
        target.write_data(df)
        
        # Close the target
        logger.info("Closing Neo4j target")
        target.close()
        
        logger.info("Successfully wrote data to Neo4j!")
        
        # Display example Cypher queries for retrieving data
        node_label = target_config["parameters"].get("node_label", "Chunk")
        doc_label = target_config["parameters"].get("document_label", "Document")
        rel_type = target_config["parameters"].get("relationship_type", "PART_OF")
        
        print("\nExample Cypher queries to retrieve data:")
        print("-----------------------------------------")
        print(f"1. Get all chunks:\n   MATCH (c:{node_label}) RETURN c.chunk_id, c.chunk_text LIMIT 10\n")
        print(f"2. Get all documents:\n   MATCH (d:{doc_label}) RETURN d.id, d.filename LIMIT 10\n")
        print(f"3. Get chunks for a specific document:\n   MATCH (c:{node_label})-[:{rel_type}]->(d:{doc_label}) WHERE d.id = 'doc1' RETURN c.chunk_id, c.chunk_text\n")
        print(f"4. Vector similarity search:\n   MATCH (c:{node_label}) WITH c, vector.similarity(c.embedding, $queryVector) AS score ORDER BY score DESC LIMIT 5 RETURN c.chunk_id, c.chunk_text, score\n")
        
    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        sys.exit(1)
    finally:
        # Stop the Spark session
        spark.stop()


if __name__ == "__main__":
    main() 