#!/usr/bin/env python
"""
Example script demonstrating how to use the ChromaDB vector target
to store text chunks with embeddings in a ChromaDB database.
"""

import os
import sys
import yaml
import logging
from pathlib import Path

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf, struct, lit
from pyspark.sql.types import ArrayType, FloatType

# Add the src directory to the Python path
sys.path.append(str(Path(__file__).parent.parent))

from src.target.vector_targets import ChromaDBTarget
from src.exception.exceptions import TargetException

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("chromadb_example")


def load_config(config_path):
    """Load the target configuration from a YAML file."""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Extract only the target section
    return config["target"]


def create_sample_data(spark):
    """Create a sample DataFrame with text chunks and embeddings."""
    # Define some sample text chunks
    chunks = [
        {
            "chunk_id": f"doc{i}-{j}",
            "chunk_text": f"This is chunk {j} from document {i}.",
            "chunk_index": j,
            "id": f"doc{i}",
            "filename": f"doc{i}.txt",
            "source": "text_files",
            "last_modified": "2023-01-01",
        }
        for i in range(1, 4)  # 3 documents
        for j in range(2)     # 2 chunks per document
    ]
    
    # Create a DataFrame
    df = pd.DataFrame(chunks)
    
    # Generate random embeddings (128-dimensional for this example)
    EMBEDDING_DIM = 128
    embeddings = [np.random.rand(EMBEDDING_DIM).tolist() for _ in range(len(df))]
    df["embedding"] = embeddings
    
    # Convert to Spark DataFrame
    spark_df = spark.createDataFrame(df)
    return spark_df


def main():
    """Run the example."""
    # Parse command line arguments
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_file>")
        print(f"Example: {sys.argv[0]} examples/chromadb_config.yaml")
        sys.exit(1)
    
    config_path = sys.argv[1]
    
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName("chromadb-example") \
        .master("local[*]") \
        .config("spark.driver.memory", "4g") \
        .getOrCreate()
    
    try:
        # Load configuration
        logger.info(f"Loading configuration from {config_path}")
        target_config = load_config(config_path)
        
        # Create sample data
        logger.info("Creating sample data")
        df = create_sample_data(spark)
        logger.info(f"Created {df.count()} sample chunks")
        
        # Display sample data
        logger.info("Sample data schema:")
        df.printSchema()
        logger.info("Sample data (first row):")
        df.limit(1).show(truncate=False)
        
        # Initialize ChromaDB target
        logger.info("Initializing ChromaDB target")
        target = ChromaDBTarget(target_config)
        
        # Write data to ChromaDB
        logger.info("Writing data to ChromaDB")
        target.write_data(df)
        
        # Close the target
        logger.info("Closing ChromaDB target")
        target.close()
        
        logger.info("Successfully wrote data to ChromaDB!")
        
        # Display example Python code for querying
        collection_name = target_config["parameters"].get("collection_name", "documents")
        persist_directory = target_config["parameters"].get("persist_directory", None)
        
        print("\nExample Python code to query the data:")
        print("-----------------------------------------")
        print("```python")
        print("import chromadb")
        
        if persist_directory:
            print(f"client = chromadb.PersistentClient(path='{persist_directory}')")
        else:
            print("client = chromadb.Client()")
            
        print(f"collection = client.get_collection(name='{collection_name}')")
        print("")
        print("# Query by text similarity")
        print("results = collection.query(")
        print("    query_texts=['sample query text'],")
        print("    n_results=3")
        print(")")
        print("")
        print("# Query by metadata")
        print("results = collection.query(")
        print("    query_texts=[''],")
        print("    where={'source': 'text_files', 'id': 'doc1'},")
        print("    n_results=5")
        print(")")
        print("")
        print("# Query by vector similarity with specific embedding")
        print("import numpy as np")
        print("query_embedding = np.random.rand(128).tolist()  # Must match embedding dimension")
        print("results = collection.query(")
        print("    query_embeddings=[query_embedding],")
        print("    n_results=3")
        print(")")
        print("")
        print("# Print results")
        print("print(results)")
        print("```")
        
    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        sys.exit(1)
    finally:
        # Stop the Spark session
        spark.stop()


if __name__ == "__main__":
    main() 