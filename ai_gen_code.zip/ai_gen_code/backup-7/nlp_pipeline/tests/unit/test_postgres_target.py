"""
Comprehensive unit tests for PostgreSQL vector target.
"""

import unittest
from unittest.mock import patch, MagicMock, call, ANY

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import PostgresVectorTarget
from src.exception.exceptions import TargetException


class TestPostgresVectorTarget(unittest.TestCase):
    """Test the PostgresVectorTarget class with comprehensive test cases."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-postgres-vector-target") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        cls.spark.stop()
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "vectordb",
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
                "document_table": "documents",
                "chunk_table": "chunks",
                "vector_dimension": 384,
                "vector_extension": "pgvector",
                "index_type": "hnsw",
                "batch_size": 10,
                "create_tables": True,
                "create_extension": True
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Mock psycopg2
        self.patcher = patch('src.target.vector_targets.psycopg2')
        self.mock_psycopg2 = self.patcher.start()
        
        # Setup mock connection and cursor
        self.mock_conn = MagicMock()
        self.mock_cursor = MagicMock()
        self.mock_psycopg2.connect.return_value = self.mock_conn
        self.mock_conn.cursor.return_value = self.mock_cursor
        
        # Create postgres target
        self.target = PostgresVectorTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.patcher.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for vector storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("chunk_index", StringType(), False),
            StructField("id", StringType(), False),
            StructField("source", StringType(), True),
            StructField("filename", StringType(), True),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "chunk_id": "doc1-0", 
                "chunk_text": "This is a test chunk from document 1.", 
                "chunk_index": "0", 
                "id": "doc1",
                "source": "text_files",
                "filename": "doc1.txt",
                "embedding": [0.1, 0.2, 0.3, 0.4] * 96  # 384-dimensional embedding
            },
            {
                "chunk_id": "doc1-1", 
                "chunk_text": "This is another chunk from document 1.", 
                "chunk_index": "1", 
                "id": "doc1",
                "source": "text_files",
                "filename": "doc1.txt",
                "embedding": [0.2, 0.3, 0.4, 0.5] * 96
            },
            {
                "chunk_id": "doc2-0", 
                "chunk_text": "This is a chunk from document 2.", 
                "chunk_index": "0", 
                "id": "doc2",
                "source": "text_files",
                "filename": "doc2.txt",
                "embedding": [0.3, 0.4, 0.5, 0.6] * 96
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.target._validate_target_config()
        
        # Test missing database parameter
        invalid_config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "user": "postgres",
                "password": "postgres"
                # Missing database
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Should raise exception due to missing database
        target = PostgresVectorTarget(invalid_config)
        with self.assertRaises(TargetException):
            target._validate_target_config()
        
        # Test missing embedding column
        invalid_config = {
            "parameters": {
                "host": "localhost",
                "port": 5432,
                "database": "vectordb",
                "user": "postgres",
                "password": "postgres"
            },
            "text_column": "chunk_text",
            "id_column": "chunk_id"
            # Missing embedding_column
        }
        
        # Should raise exception due to missing embedding column
        with self.assertRaises(TargetException):
            PostgresVectorTarget(invalid_config)._validate_target_config()
    
    def test_initialize_connection(self):
        """Test connection initialization."""
        self.target._initialize_connection()
        
        # Check that the PostgreSQL connection was created with the right parameters
        self.mock_psycopg2.connect.assert_called_once_with(
            host="localhost",
            port=5432,
            database="vectordb",
            user="postgres",
            password="postgres"
        )
    
    def test_create_extension(self):
        """Test creating the vector extension."""
        # Call the method
        self.target._create_extension()
        
        # Check that execute was called with the right SQL
        self.mock_cursor.execute.assert_called_once_with("CREATE EXTENSION IF NOT EXISTS pgvector")
        
        # Test with different extension
        self.target.vector_extension = "vector"
        self.target._create_extension()
        
        # Check that execute was called with the right SQL for alternate extension
        self.mock_cursor.execute.assert_called_with("CREATE EXTENSION IF NOT EXISTS vector")
    
    def test_create_tables(self):
        """Test table creation."""
        # Call the create_tables method
        self.target._create_tables()
        
        # Check that execute was called for document table
        doc_table_call = call(
            f"CREATE TABLE IF NOT EXISTS {self.target.schema}.{self.target.document_table} ("
            f"id VARCHAR(255) PRIMARY KEY, "
            f"filename VARCHAR(255), "
            f"path VARCHAR(1000), "
            f"file_size BIGINT, "
            f"last_modified TIMESTAMP, "
            f"metadata JSONB)"
        )
        self.mock_cursor.execute.assert_has_calls([doc_table_call], any_order=True)
        
        # Check that execute was called for chunk table
        chunk_table_call = call(ANY)  # The exact string is long, so we'll just check for a call
        self.assertTrue(self.mock_cursor.execute.call_count >= 2)
    
    def test_create_index(self):
        """Test index creation."""
        # Call the method
        self.target._create_index()
        
        # Verify SQL execution for ID index
        id_index_call = call(
            f"CREATE INDEX IF NOT EXISTS idx_{self.target.chunk_table}_id "
            f"ON {self.target.schema}.{self.target.chunk_table} (chunk_id)"
        )
        self.mock_cursor.execute.assert_has_calls([id_index_call], any_order=True)
        
        # Verify SQL execution for vector index with HNSW
        vector_index_call = call(
            f"CREATE INDEX IF NOT EXISTS idx_{self.target.chunk_table}_vector "
            f"ON {self.target.schema}.{self.target.chunk_table} "
            f"USING hnsw (embedding vector_l2_ops)"
        )
        self.mock_cursor.execute.assert_has_calls([vector_index_call], any_order=True)
        
        # Test with ivfflat index type
        self.target.index_type = "ivfflat"
        self.target._create_index()
        
        # Verify SQL execution for vector index with IVFFLAT
        ivf_index_call = call(
            f"CREATE INDEX IF NOT EXISTS idx_{self.target.chunk_table}_vector "
            f"ON {self.target.schema}.{self.target.chunk_table} "
            f"USING ivfflat (embedding vector_l2_ops)"
        )
        self.mock_cursor.execute.assert_has_calls([ivf_index_call], any_order=True)
    
    def test_write_document(self):
        """Test writing document metadata."""
        # Create test data
        doc_id = "doc1"
        metadata = {
            "filename": "doc1.txt",
            "path": "/data/doc1.txt",
            "file_size": 12345,
            "last_modified": "2023-01-01T00:00:00",
            "metadata": {"author": "Test Author", "title": "Test Document"}
        }
        
        # Call the method
        self.target._write_document(doc_id, metadata)
        
        # Verify SQL execution
        self.mock_cursor.execute.assert_called_once()
        args, _ = self.mock_cursor.execute.call_args
        
        # Check that the SQL contains the right table and placeholders
        sql = args[0]
        self.assertIn(f"INSERT INTO {self.target.schema}.{self.target.document_table}", sql)
        self.assertIn("ON CONFLICT (id) DO UPDATE", sql)
    
    @patch('src.target.vector_targets.udf')
    def test_write_data(self, mock_udf):
        """Test the write_data method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF and foreach method
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Call the write_data method
        self.target.write_data(df)
        
        # Verify the UDF was created for batch processing
        mock_udf.assert_called_once()
    
    def test_write_data_missing_column(self):
        """Test write_data with missing columns."""
        # Create a dataframe missing required columns
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("text", StringType(), False)
        ])
        df = self.spark.createDataFrame([{"id": "1", "text": "test"}], schema)
        
        # Should raise exception
        with self.assertRaises(TargetException):
            self.target.write_data(df)
    
    def test_write_chunks_batch(self):
        """Test writing a batch of chunks."""
        # Create test batch data
        batch = [
            {
                "chunk_id": "doc1-0",
                "chunk_text": "This is a test chunk from document 1.",
                "chunk_index": "0",
                "id": "doc1",
                "embedding": [0.1, 0.2, 0.3, 0.4]
            },
            {
                "chunk_id": "doc1-1",
                "chunk_text": "This is another chunk from document 1.",
                "chunk_index": "1",
                "id": "doc1",
                "embedding": [0.2, 0.3, 0.4, 0.5]
            }
        ]
        
        # Call the method
        self.target._write_chunks_batch(batch)
        
        # Verify cursor executemany was called once
        self.mock_cursor.executemany.assert_called_once()
        
        # Check that the SQL contains the right table and placeholders
        args, _ = self.mock_cursor.executemany.call_args
        sql = args[0]
        self.assertIn(f"INSERT INTO {self.target.schema}.{self.target.chunk_table}", sql)
        self.assertIn("ON CONFLICT (chunk_id) DO UPDATE", sql)
    
    def test_generate_vector_sql(self):
        """Test generating the vector SQL for different vector extensions."""
        # Default pgvector
        vector_sql = self.target._generate_vector_sql()
        self.assertEqual(vector_sql, "embedding vector(384)")
        
        # Test with vector extension
        self.target.vector_extension = "vector"
        vector_sql = self.target._generate_vector_sql()
        self.assertEqual(vector_sql, "embedding vector(384)")
        
        # Test with pg_embedding
        self.target.vector_extension = "pg_embedding"
        vector_sql = self.target._generate_vector_sql()
        self.assertEqual(vector_sql, "embedding real[]")
    
    def test_close(self):
        """Test the close method."""
        # Call the close method
        self.target.close()
        
        # Verify that the connection was closed
        self.mock_conn.close.assert_called_once()
        
        # Should not raise exception if connection is None
        self.target._conn = None
        self.target.close()


if __name__ == "__main__":
    unittest.main() 