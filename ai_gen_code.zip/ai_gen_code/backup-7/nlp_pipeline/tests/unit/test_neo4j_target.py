"""
Comprehensive unit tests for Neo4j vector target.
"""

import unittest
from unittest.mock import patch, MagicMock, call, ANY

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import Neo4jTarget
from src.exception.exceptions import TargetException


class TestNeo4jTarget(unittest.TestCase):
    """Test the Neo4jTarget class with comprehensive test cases."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-neo4j-target") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        cls.spark.stop()
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "uri": "neo4j://localhost:7687",
                "user": "neo4j",
                "password": "password",
                "database": "neo4j",
                "node_label": "Chunk",
                "document_label": "Document",
                "relationship_type": "PART_OF",
                "batch_size": 10,
                "vector_dimension": 384,
                "create_vector_index": True,
                "vector_index_name": "chunk_vector_index",
                "similarity_metric": "cosine",
                "chunk_properties": ["chunk_text", "chunk_index"],
                "document_properties": ["id", "filename", "path"],
                "create_constraints": True,
                "constraint_properties": ["chunk_id", "id"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Mock Neo4j driver
        self.patcher_driver = patch('src.target.vector_targets.GraphDatabase')
        self.mock_graph_db = self.patcher_driver.start()
        
        # Mock Neo4j
        self.patcher_neo4j = patch('src.target.vector_targets.neo4j')
        self.mock_neo4j = self.patcher_neo4j.start()
        
        # Setup mock driver and session
        self.mock_driver = MagicMock()
        self.mock_session = MagicMock()
        self.mock_result = MagicMock()
        
        self.mock_graph_db.driver.return_value = self.mock_driver
        self.mock_driver.session.return_value = self.mock_session
        self.mock_session.run.return_value = self.mock_result
        
        # Create Neo4j target
        self.target = Neo4jTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.patcher_driver.stop()
        self.patcher_neo4j.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for vector storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("chunk_index", StringType(), False),
            StructField("id", StringType(), False),
            StructField("filename", StringType(), True),
            StructField("path", StringType(), True),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "chunk_id": "doc1-0", 
                "chunk_text": "This is a test chunk from document 1.", 
                "chunk_index": "0", 
                "id": "doc1",
                "filename": "doc1.txt",
                "path": "/data/doc1.txt",
                "embedding": [0.1, 0.2, 0.3, 0.4] * 96  # 384-dimensional embedding
            },
            {
                "chunk_id": "doc1-1", 
                "chunk_text": "This is another chunk from document 1.", 
                "chunk_index": "1", 
                "id": "doc1",
                "filename": "doc1.txt",
                "path": "/data/doc1.txt",
                "embedding": [0.2, 0.3, 0.4, 0.5] * 96
            },
            {
                "chunk_id": "doc2-0", 
                "chunk_text": "This is a chunk from document 2.", 
                "chunk_index": "0", 
                "id": "doc2",
                "filename": "doc2.txt",
                "path": "/data/doc2.txt",
                "embedding": [0.3, 0.4, 0.5, 0.6] * 96
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.target._validate_target_config()
        
        # Test missing password parameter
        invalid_config = {
            "parameters": {
                "uri": "neo4j://localhost:7687",
                "user": "neo4j",
                # Missing password
                "database": "neo4j"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Should raise exception due to missing password
        target = Neo4jTarget(invalid_config)
        with self.assertRaises(TargetException):
            target._validate_target_config()
        
        # Test missing embedding column
        invalid_config = {
            "parameters": {
                "uri": "neo4j://localhost:7687",
                "user": "neo4j",
                "password": "password",
                "database": "neo4j"
            },
            "text_column": "chunk_text",
            "id_column": "chunk_id"
            # Missing embedding_column
        }
        
        # Should raise exception due to missing embedding column
        with self.assertRaises(TargetException):
            Neo4jTarget(invalid_config)._validate_target_config()
    
    def test_initialize_driver(self):
        """Test driver initialization."""
        self.target._initialize_driver()
        
        # Check that the Neo4j driver was created with the right parameters
        self.mock_graph_db.driver.assert_called_once_with(
            "neo4j://localhost:7687",
            auth=("neo4j", "password")
        )
    
    def test_create_indices(self):
        """Test creating indices in Neo4j."""
        # Setup mock result for index provider check
        mock_record = MagicMock()
        mock_record["provider"] = "vector"
        self.mock_result.__iter__.return_value = [mock_record]
        
        # Call the method
        self.target._create_indices()
        
        # Verify constraint creation
        constraint_call = call(
            f"CREATE CONSTRAINT {self.target.node_label}_id_unique IF NOT EXISTS "
            f"FOR (d:{self.target.node_label}) REQUIRE d.{self.target.id_column} IS UNIQUE"
        )
        self.mock_session.run.assert_has_calls([constraint_call], any_order=True)
        
        # Verify vector index creation
        vector_index_call = call(
            f"CALL db.index.vector.createNodeIndex("
            f"'{self.target.node_label}_vector_index', "
            f"'{self.target.node_label}', "
            f"'{self.target.embedding_column}', "
            f"384, 'cosine'"
            f")"
        )
        self.mock_session.run.assert_has_calls([vector_index_call], any_order=True)
    
    def test_create_indices_no_vector_support(self):
        """Test creating indices in Neo4j when vector indices are not supported."""
        # Setup mock result for index provider check with no vector support
        mock_record = MagicMock()
        mock_record["provider"] = "btree"
        self.mock_result.__iter__.return_value = [mock_record]
        
        # Call the method
        self.target._create_indices()
        
        # Should still create constraint but not vector index
        constraint_call = call(
            f"CREATE CONSTRAINT {self.target.node_label}_id_unique IF NOT EXISTS "
            f"FOR (d:{self.target.node_label}) REQUIRE d.{self.target.id_column} IS UNIQUE"
        )
        self.mock_session.run.assert_has_calls([constraint_call], any_order=True)
        
        # Verify vector index creation was not attempted
        vector_index_call = call(
            f"CALL db.index.vector.createNodeIndex("
            f"'{self.target.node_label}_vector_index', "
            f"'{self.target.node_label}', "
            f"'{self.target.embedding_column}', "
            f"384, 'cosine'"
            f")"
        )
        self.assertNotIn(vector_index_call, self.mock_session.run.call_args_list)
    
    def test_write_batch(self):
        """Test writing a batch of nodes to Neo4j."""
        # Create test batch data
        batch = [
            {
                "chunk_id": "doc1-0",
                "chunk_text": "This is a test chunk from document 1.",
                "chunk_index": "0",
                "id": "doc1",
                "embedding": [0.1, 0.2, 0.3, 0.4],
                "filename": "doc1.txt",
                "path": "/data/doc1.txt"
            },
            {
                "chunk_id": "doc1-1",
                "chunk_text": "This is another chunk from document 1.",
                "chunk_index": "1",
                "id": "doc1",
                "embedding": [0.2, 0.3, 0.4, 0.5],
                "filename": "doc1.txt",
                "path": "/data/doc1.txt"
            }
        ]
        
        # Call the write_batch method
        self.target._write_batch(batch)
        
        # Verify that the session run method was called with the right query
        self.mock_session.run.assert_called_once()
        args, kwargs = self.mock_session.run.call_args
        
        # Verify query structure
        query = args[0]
        self.assertIn("UNWIND $batch AS row", query)
        self.assertIn(f"MERGE (d:{self.target.node_label}", query)
        self.assertIn(f"SET d.{self.target.text_column} = row.{self.target.text_column}", query)
        self.assertIn(f"SET d.{self.target.embedding_column} = row.{self.target.embedding_column}", query)
        
        # Verify batch data was passed
        self.assertEqual(kwargs["batch"], batch)
    
    def test_create_relationships(self):
        """Test creating relationships between nodes."""
        # Create test batch data
        batch = [
            {
                "chunk_id": "doc1-0",
                "id": "doc1",
                "chunk_index": "0"
            },
            {
                "chunk_id": "doc1-1",
                "id": "doc1",
                "chunk_index": "1"
            },
            {
                "chunk_id": "doc2-0",
                "id": "doc2",
                "chunk_index": "0"
            }
        ]
        
        # Call the create_relationships method
        self.target._create_relationships(batch)
        
        # Verify that the session run method was called with the right query
        self.mock_session.run.assert_called_once()
        args, kwargs = self.mock_session.run.call_args
        
        # Verify query structure
        query = args[0]
        self.assertIn("UNWIND $batch AS row", query)
        self.assertIn(f"MATCH (c:{self.target.node_label})", query)
        self.assertIn(f"MATCH (d:{self.target.document_label})", query)
        self.assertIn(f"MERGE (c)-[:{self.target.relationship_type}]->(d)", query)
        
        # Verify batch data was passed
        self.assertEqual(kwargs["batch"], batch)
    
    def test_create_document_nodes(self):
        """Test creating document nodes."""
        # Create test batch data
        batch = [
            {
                "id": "doc1",
                "filename": "doc1.txt",
                "path": "/data/doc1.txt"
            },
            {
                "id": "doc2",
                "filename": "doc2.txt",
                "path": "/data/doc2.txt"
            }
        ]
        
        # Call the create_document_nodes method
        self.target._create_document_nodes(batch)
        
        # Verify that the session run method was called with the right query
        self.mock_session.run.assert_called_once()
        args, kwargs = self.mock_session.run.call_args
        
        # Verify query structure
        query = args[0]
        self.assertIn("UNWIND $batch AS row", query)
        self.assertIn(f"MERGE (d:{self.target.document_label}", query)
        self.assertIn(f"ON CREATE SET", query)
        
        # Verify batch data was passed
        self.assertEqual(kwargs["batch"], batch)
    
    @patch('src.target.vector_targets.udf')
    def test_write_data(self, mock_udf):
        """Test the write_data method."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the UDF and foreach method
        mock_udf_instance = MagicMock()
        mock_udf.return_value = mock_udf_instance
        
        # Call the write_data method
        self.target.write_data(df)
        
        # Verify the UDF was created for batch processing
        mock_udf.assert_called_once()
    
    def test_write_data_missing_column(self):
        """Test write_data with missing columns."""
        # Create a dataframe missing required columns
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("text", StringType(), False)
        ])
        df = self.spark.createDataFrame([{"id": "1", "text": "test"}], schema)
        
        # Should raise exception
        with self.assertRaises(TargetException):
            self.target.write_data(df)
    
    def test_prepare_document_data(self):
        """Test preparing document data from a batch."""
        # Create test batch data
        batch = [
            {
                "chunk_id": "doc1-0",
                "id": "doc1",
                "filename": "doc1.txt",
                "path": "/data/doc1.txt"
            },
            {
                "chunk_id": "doc1-1",
                "id": "doc1",
                "filename": "doc1.txt",
                "path": "/data/doc1.txt"
            },
            {
                "chunk_id": "doc2-0",
                "id": "doc2",
                "filename": "doc2.txt",
                "path": "/data/doc2.txt"
            }
        ]
        
        # Call the prepare_document_data method
        doc_data = self.target._prepare_document_data(batch)
        
        # Should return unique documents based on id
        self.assertEqual(len(doc_data), 2)
        self.assertEqual(doc_data[0]["id"], "doc1")
        self.assertEqual(doc_data[1]["id"], "doc2")
        
        # Should include all document properties
        self.assertEqual(doc_data[0]["filename"], "doc1.txt")
        self.assertEqual(doc_data[0]["path"], "/data/doc1.txt")
    
    def test_close(self):
        """Test the close method."""
        # Call the close method
        self.target.close()
        
        # Verify that the driver was closed
        self.mock_driver.close.assert_called_once()
        
        # Should not raise exception if driver is None
        self.target._driver = None
        self.target.close()


if __name__ == "__main__":
    unittest.main() 