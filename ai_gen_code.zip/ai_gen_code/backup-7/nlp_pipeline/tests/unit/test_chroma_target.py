"""
Comprehensive unit tests for ChromaDB vector target.
"""

import unittest
from unittest.mock import patch, MagicMock, call, ANY

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import ArrayType, FloatType, StringType, StructType, StructField

from src.target.vector_targets import ChromaDBTarget
from src.exception.exceptions import TargetException


class TestChromaDBTarget(unittest.TestCase):
    """Test the ChromaDBTarget class with comprehensive test cases."""
    
    @classmethod
    def setUpClass(cls):
        """Set up the Spark session."""
        cls.spark = SparkSession.builder \
            .appName("test-chromadb-target") \
            .master("local[2]") \
            .getOrCreate()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests."""
        cls.spark.stop()
    
    def setUp(self):
        """Set up each test."""
        self.config = {
            "parameters": {
                "collection_name": "test_collection",
                "persist_directory": "/tmp/chromadb",
                "chroma_db_impl": "duckdb+parquet",
                "batch_size": 10,
                "metadata_fields": ["id", "chunk_index", "source", "filename"]
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Mock ChromaDB client
        self.patcher = patch('src.target.vector_targets.chromadb')
        self.mock_chromadb = self.patcher.start()
        
        # Setup mock client and collection
        self.mock_client = MagicMock()
        self.mock_collection = MagicMock()
        self.mock_chromadb.Client.return_value = self.mock_client
        self.mock_chromadb.PersistentClient.return_value = self.mock_client
        self.mock_client.get_or_create_collection.return_value = self.mock_collection
        
        # Create chromadb target
        self.target = ChromaDBTarget(self.config)
    
    def tearDown(self):
        """Tear down each test."""
        self.patcher.stop()
    
    def create_test_dataframe(self):
        """Create a test DataFrame for vector storage."""
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("chunk_id", StringType(), False),
            StructField("chunk_text", StringType(), False),
            StructField("chunk_index", StringType(), False),
            StructField("id", StringType(), False),
            StructField("source", StringType(), True),
            StructField("filename", StringType(), True),
            StructField("embedding", ArrayType(FloatType()), False)
        ])
        
        # Create sample data
        data = [
            {
                "chunk_id": "doc1-0", 
                "chunk_text": "This is a test chunk from document 1.", 
                "chunk_index": "0", 
                "id": "doc1",
                "source": "text_files",
                "filename": "doc1.txt",
                "embedding": [0.1, 0.2, 0.3, 0.4] * 32  # 128-dimensional embedding
            },
            {
                "chunk_id": "doc1-1", 
                "chunk_text": "This is another chunk from document 1.", 
                "chunk_index": "1", 
                "id": "doc1",
                "source": "text_files",
                "filename": "doc1.txt",
                "embedding": [0.2, 0.3, 0.4, 0.5] * 32
            },
            {
                "chunk_id": "doc2-0", 
                "chunk_text": "This is a chunk from document 2.", 
                "chunk_index": "0", 
                "id": "doc2",
                "source": "text_files",
                "filename": "doc2.txt",
                "embedding": [0.3, 0.4, 0.5, 0.6] * 32
            }
        ]
        
        # Convert to DataFrame
        df = self.spark.createDataFrame(data, schema)
        return df
    
    def test_validate_config(self):
        """Test configuration validation."""
        # Valid config should not raise an exception
        self.target._validate_target_config()
        
        # Test missing collection name
        invalid_config = {
            "parameters": {
                "persist_directory": "/tmp/chromadb"
            },
            "embedding_column": "embedding",
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Should raise exception due to missing collection name
        with self.assertRaises(TargetException):
            ChromaDBTarget(invalid_config)._validate_target_config()
        
        # Test missing embedding column
        invalid_config = {
            "parameters": {
                "collection_name": "test_collection",
                "persist_directory": "/tmp/chromadb"
            },
            "text_column": "chunk_text",
            "id_column": "chunk_id"
        }
        
        # Should raise exception due to missing embedding column
        with self.assertRaises(TargetException):
            ChromaDBTarget(invalid_config)._validate_target_config()
    
    def test_initialize_client_persistent(self):
        """Test client initialization with persistence."""
        # Create a target with persistent storage
        config = self.config.copy()
        config["parameters"] = self.config["parameters"].copy()
        config["parameters"]["persist_directory"] = "/tmp/chromadb"
        
        target = ChromaDBTarget(config)
        target._initialize_client()
        
        # Check that the ChromaDB client was created with the right settings
        self.mock_chromadb.PersistentClient.assert_called_once_with(path="/tmp/chromadb")
        
        # Check that the collection was created
        self.mock_client.get_or_create_collection.assert_called_once_with(
            name="test_collection",
            metadata={"description": "Collection created by NLP Pipeline"}
        )
    
    def test_initialize_client_in_memory(self):
        """Test client initialization with in-memory storage."""
        # Create a target with in-memory storage
        config = self.config.copy()
        config["parameters"] = self.config["parameters"].copy()
        config["parameters"].pop("persist_directory", None)
        
        target = ChromaDBTarget(config)
        target._initialize_client()
        
        # Check that the ChromaDB client was created with the right settings
        self.mock_chromadb.Client.assert_called_once()
        
        # Check that the collection was created
        self.mock_client.get_or_create_collection.assert_called_once_with(
            name="test_collection",
            metadata={"description": "Collection created by NLP Pipeline"}
        )
    
    def test_write_data_with_metadata(self):
        """Test writing data with metadata to ChromaDB."""
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Mock the collection batch add method
        self.mock_collection.add.return_value = None
        
        # Set up collect to return a specific result
        mock_row = MagicMock()
        mock_row.__fields__ = ["chunk_id", "chunk_text", "embedding", "id", "chunk_index", "source", "filename"]
        mock_row["chunk_id"] = "doc1-0"
        mock_row["chunk_text"] = "This is a test chunk from document 1."
        mock_row["embedding"] = [0.1, 0.2, 0.3, 0.4]
        mock_row["id"] = "doc1"
        mock_row["chunk_index"] = "0"
        mock_row["source"] = "text_files"
        mock_row["filename"] = "doc1.txt"
        
        with patch.object(df, 'collect', return_value=[mock_row]):
            # Call the write_data method
            self.target.write_data(df)
            
            # Check that the collection add method was called with the right parameters
            self.mock_collection.add.assert_called_once_with(
                ids=["doc1-0"],
                documents=["This is a test chunk from document 1."],
                embeddings=[[0.1, 0.2, 0.3, 0.4]],
                metadatas=[{
                    "id": "doc1",
                    "chunk_index": "0",
                    "source": "text_files",
                    "filename": "doc1.txt"
                }]
            )
    
    def test_write_data_missing_columns(self):
        """Test the write_data method with missing columns."""
        # Create a dataframe missing required columns
        schema = StructType([
            StructField("id", StringType(), False),
            StructField("text", StringType(), False)
        ])
        df = self.spark.createDataFrame([{"id": "1", "text": "test"}], schema)
        
        # Call should raise exception for missing text column
        with self.assertRaises(TargetException):
            self.target.write_data(df)
    
    def test_write_data_batch_processing(self):
        """Test that data is written in batches."""
        # Create mock data with more rows than batch size
        num_rows = 25  # Larger than batch size of 10
        
        # Create mock rows
        mock_rows = []
        for i in range(num_rows):
            mock_row = MagicMock()
            mock_row.__fields__ = ["chunk_id", "chunk_text", "embedding", "id", "chunk_index", "source", "filename"]
            mock_row["chunk_id"] = f"doc1-{i}"
            mock_row["chunk_text"] = f"This is test chunk {i} from document 1."
            mock_row["embedding"] = [0.1, 0.2, 0.3, 0.4]
            mock_row["id"] = "doc1"
            mock_row["chunk_index"] = str(i)
            mock_row["source"] = "text_files"
            mock_row["filename"] = "doc1.txt"
            mock_rows.append(mock_row)
        
        # Create a test dataframe
        df = self.create_test_dataframe()
        
        # Set up collect to return the mock rows
        with patch.object(df, 'collect', return_value=mock_rows):
            # Call the write_data method
            self.target.write_data(df)
            
            # Check that add was called 3 times (25 rows with batch size 10)
            self.assertEqual(self.mock_collection.add.call_count, 3)
            
            # First batch should have 10 rows
            first_call_kwargs = self.mock_collection.add.call_args_list[0][1]
            self.assertEqual(len(first_call_kwargs['ids']), 10)
            
            # Second batch should have 10 rows
            second_call_kwargs = self.mock_collection.add.call_args_list[1][1]
            self.assertEqual(len(second_call_kwargs['ids']), 10)
            
            # Third batch should have 5 rows
            third_call_kwargs = self.mock_collection.add.call_args_list[2][1]
            self.assertEqual(len(third_call_kwargs['ids']), 5)
    
    def test_close(self):
        """Test the close method."""
        # Should not raise any exceptions
        self.target.close()
        
        # If client exists, it should be set to None
        self.target._client = MagicMock()
        self.target._collection = MagicMock()
        self.target.close()
        
        self.assertIsNone(self.target._client)
        self.assertIsNone(self.target._collection)


if __name__ == "__main__":
    unittest.main() 