"""
Text utilities for the NLP ETL Pipeline
"""
from typing import List, Dict, Set, Optional, Union, Any, Tuple
import re
import string
import unicodedata
from functools import lru_cache
import logging

from src.logging_module.logger import get_logger
from src.exception.exceptions import handle_exception, PreprocessingError

logger = get_logger(__name__)


@handle_exception
def clean_text(text: str, 
              remove_urls: bool = True,
              remove_html: bool = True,
              remove_special_chars: bool = True,
              remove_numbers: bool = True,
              normalize_whitespace: bool = True,
              lowercase: bool = True) -> str:
    """
    Clean text by removing unwanted elements
    
    Args:
        text: Input text to clean
        remove_urls: Whether to remove URLs
        remove_html: Whether to remove HTML tags
        remove_special_chars: Whether to remove special characters
        remove_numbers: Whether to remove numbers
        normalize_whitespace: Whether to normalize whitespace
        lowercase: Whether to convert to lowercase
        
    Returns:
        Cleaned text
    """
    if not isinstance(text, str):
        if text is None:
            return ""
        text = str(text)
    
    # Remove URLs
    if remove_urls:
        text = re.sub(r'https?://\S+|www\.\S+', ' ', text)
    
    # Remove HTML tags
    if remove_html:
        text = re.sub(r'<.*?>', ' ', text)
    
    # Remove special characters
    if remove_special_chars:
        text = re.sub(r'[^\w\s]', ' ', text)
    
    # Remove numbers
    if remove_numbers:
        text = re.sub(r'\d+', ' ', text)
    
    # Normalize whitespace
    if normalize_whitespace:
        text = re.sub(r'\s+', ' ', text).strip()
    
    # Convert to lowercase
    if lowercase:
        text = text.lower()
    
    return text


@handle_exception
def normalize_unicode(text: str, form: str = 'NFKC') -> str:
    """
    Normalize Unicode characters in text
    
    Args:
        text: Input text
        form: Unicode normalization form ('NFC', 'NFKC', 'NFD', 'NFKD')
        
    Returns:
        Normalized text
    """
    if not isinstance(text, str):
        if text is None:
            return ""
        text = str(text)
    
    return unicodedata.normalize(form, text)


@lru_cache(maxsize=1)
def get_stopwords(language: str = 'english') -> Set[str]:
    """
    Get a set of stopwords for a given language
    
    Args:
        language: Language for stopwords
        
    Returns:
        Set of stopwords
    """
    try:
        import nltk
        try:
            nltk.data.find(f'corpora/stopwords')
        except LookupError:
            nltk.download('stopwords', quiet=True)
        
        from nltk.corpus import stopwords
        return set(stopwords.words(language))
    except ImportError:
        logger.warning("NLTK not available, using basic English stopword list")
        # Basic English stopwords
        return {
            'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 
            'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', 
            'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 
            'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 
            'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 
            'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 
            'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 
            'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 
            'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 
            'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 
            'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 
            'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 
            'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 
            'will', 'just', 'don', 'should', 'now'
        }


@handle_exception
def remove_stopwords(text: str, stopwords: Optional[Set[str]] = None, language: str = 'english') -> str:
    """
    Remove stopwords from text
    
    Args:
        text: Input text
        stopwords: Set of stopwords to remove (if None, will use language default)
        language: Language for stopwords if not explicitly provided
        
    Returns:
        Text with stopwords removed
    """
    if stopwords is None:
        stopwords = get_stopwords(language)
    
    words = text.split()
    filtered_words = [word for word in words if word.lower() not in stopwords]
    return ' '.join(filtered_words)


@lru_cache(maxsize=1)
def get_stemmer(language: str = 'english'):
    """
    Get a stemmer for a given language
    
    Args:
        language: Language for stemmer
        
    Returns:
        Stemmer object
    """
    try:
        import nltk
        if language == 'english':
            from nltk.stem import PorterStemmer
            return PorterStemmer()
        else:
            try:
                from nltk.stem import SnowballStemmer
                return SnowballStemmer(language)
            except ValueError:
                logger.warning(f"Language {language} not supported for stemming, falling back to English")
                from nltk.stem import PorterStemmer
                return PorterStemmer()
    except ImportError:
        logger.warning("NLTK not available, creating basic English stemmer")
        # Basic English stemming rules
        class BasicStemmer:
            def stem(self, word):
                if word.endswith('ing'):
                    return word[:-3]
                elif word.endswith('ed'):
                    return word[:-2]
                elif word.endswith('s'):
                    return word[:-1]
                return word
        return BasicStemmer()


@handle_exception
def stem_text(text: str, language: str = 'english') -> str:
    """
    Apply stemming to text
    
    Args:
        text: Input text
        language: Language for stemming
        
    Returns:
        Stemmed text
    """
    stemmer = get_stemmer(language)
    words = text.split()
    stemmed_words = [stemmer.stem(word) for word in words]
    return ' '.join(stemmed_words)


@lru_cache(maxsize=1)
def get_lemmatizer(language: str = 'english'):
    """
    Get a lemmatizer for a given language
    
    Args:
        language: Language for lemmatizer
        
    Returns:
        Lemmatizer object
    """
    try:
        import nltk
        try:
            nltk.data.find('corpora/wordnet')
        except LookupError:
            nltk.download('wordnet', quiet=True)
            nltk.download('omw-1.4', quiet=True)
        
        from nltk.stem import WordNetLemmatizer
        return WordNetLemmatizer()
    except ImportError:
        logger.warning("NLTK not available, creating basic lemmatizer")
        # Very basic English lemmatization
        class BasicLemmatizer:
            def lemmatize(self, word, pos=None):
                if word.endswith('s'):
                    return word[:-1]
                return word
        return BasicLemmatizer()


@handle_exception
def lemmatize_text(text: str, language: str = 'english') -> str:
    """
    Apply lemmatization to text
    
    Args:
        text: Input text
        language: Language for lemmatization
        
    Returns:
        Lemmatized text
    """
    lemmatizer = get_lemmatizer(language)
    words = text.split()
    
    try:
        import nltk
        try:
            nltk.data.find('averaged_perceptron_tagger')
        except LookupError:
            nltk.download('averaged_perceptron_tagger', quiet=True)
        
        # Get POS tags for better lemmatization
        pos_tags = nltk.pos_tag(words)
        
        # Convert POS tags to WordNet format
        def get_wordnet_pos(tag):
            if tag.startswith('J'):
                return 'a'  # Adjective
            elif tag.startswith('V'):
                return 'v'  # Verb
            elif tag.startswith('N'):
                return 'n'  # Noun
            elif tag.startswith('R'):
                return 'r'  # Adverb
            else:
                return 'n'  # Default to noun
        
        lemmatized_words = [lemmatizer.lemmatize(word, get_wordnet_pos(pos)) 
                           for word, pos in pos_tags]
    except ImportError:
        # Fallback without POS tagging
        lemmatized_words = [lemmatizer.lemmatize(word) for word in words]
    
    return ' '.join(lemmatized_words)


@handle_exception
def parse_html(html_text: str) -> str:
    """
    Extract plain text from HTML
    
    Args:
        html_text: HTML text to parse
        
    Returns:
        Extracted plain text
    """
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html_text, 'html.parser')
        
        # Remove script and style elements
        for script_or_style in soup(['script', 'style']):
            script_or_style.decompose()
        
        # Extract text and normalize whitespace
        text = soup.get_text()
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = '\n'.join(chunk for chunk in chunks if chunk)
        
        return text
    except ImportError:
        logger.warning("BeautifulSoup not available, using regex for HTML parsing")
        # Simple regex-based HTML parsing
        text = re.sub(r'<style.*?>.*?</style>', ' ', html_text, flags=re.DOTALL)
        text = re.sub(r'<script.*?>.*?</script>', ' ', text, flags=re.DOTALL)
        text = re.sub(r'<.*?>', ' ', text)
        text = re.sub(r'&[a-zA-Z]+;', ' ', text)  # Remove HTML entities
        text = re.sub(r'\s+', ' ', text).strip()
        return text


@handle_exception
def tokenize_text(text: str, tokenizer: Optional[Any] = None) -> List[str]:
    """
    Tokenize text into words
    
    Args:
        text: Input text
        tokenizer: Custom tokenizer (if None, will use basic tokenization)
        
    Returns:
        List of tokens
    """
    if tokenizer:
        return tokenizer.tokenize(text)
    
    try:
        import nltk
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt', quiet=True)
        
        return nltk.word_tokenize(text)
    except ImportError:
        # Simple space-based tokenization with punctuation handling
        text = re.sub(r'([^\w\s])', r' \1 ', text)
        return [token for token in text.split() if token]


@handle_exception
def segment_sentences(text: str) -> List[str]:
    """
    Split text into sentences
    
    Args:
        text: Input text
        
    Returns:
        List of sentences
    """
    try:
        import nltk
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt', quiet=True)
        
        return nltk.sent_tokenize(text)
    except ImportError:
        # Simple sentence segmentation
        sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!)\s', text)
        return [s.strip() for s in sentences if s.strip()]


@handle_exception
def calculate_text_stats(text: str) -> Dict[str, Any]:
    """
    Calculate various statistics for text
    
    Args:
        text: Input text
        
    Returns:
        Dictionary with text statistics
    """
    char_count = len(text)
    word_count = len(text.split())
    sentences = segment_sentences(text)
    sentence_count = len(sentences)
    
    avg_word_length = char_count / max(1, word_count)
    avg_sentence_length = word_count / max(1, sentence_count)
    
    paragraphs = [p for p in text.split('\n\n') if p.strip()]
    paragraph_count = len(paragraphs)
    
    return {
        "char_count": char_count,
        "word_count": word_count,
        "sentence_count": sentence_count,
        "paragraph_count": paragraph_count,
        "avg_word_length": avg_word_length,
        "avg_sentence_length": avg_sentence_length
    }


@handle_exception
def truncate_text(text: str, max_length: int, truncation_marker: str = "...") -> str:
    """
    Truncate text to a maximum length, preserving word boundaries
    
    Args:
        text: Input text
        max_length: Maximum length of the output text
        truncation_marker: String to append to truncated text
        
    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text
    
    truncated = text[:max_length]
    last_space = truncated.rfind(' ')
    
    if last_space > 0:
        truncated = truncated[:last_space]
    
    return truncated + truncation_marker 