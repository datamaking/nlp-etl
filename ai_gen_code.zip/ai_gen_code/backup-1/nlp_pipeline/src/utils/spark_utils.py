"""
Spark utilities for the NLP ETL Pipeline
"""
import os
from typing import Dict, List, Optional, Union, Any
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql import types as T
import logging

from src.logging_module.logger import get_logger
from src.exception.exceptions import handle_exception, DataSourceError

logger = get_logger(__name__)


@handle_exception
def create_spark_session(app_name: str, config: Optional[Dict[str, str]] = None) -> SparkSession:
    """
    Create a Spark session with the given configuration
    
    Args:
        app_name: Name of the Spark application
        config: Dictionary of configuration options
        
    Returns:
        Configured SparkSession
    """
    logger.info(f"Creating Spark session for application: {app_name}")
    
    builder = SparkSession.builder.appName(app_name)
    
    # Default configurations for NLP processing
    default_config = {
        "spark.driver.memory": "4g",
        "spark.executor.memory": "4g",
        "spark.sql.adaptive.enabled": "true",
        "spark.sql.adaptive.coalescePartitions.enabled": "true",
        "spark.sql.shuffle.partitions": "200",
        "spark.default.parallelism": "200"
    }
    
    # Apply default configurations first
    for key, value in default_config.items():
        builder = builder.config(key, value)
    
    # Then apply user configurations, which may override defaults
    if config:
        for key, value in config.items():
            builder = builder.config(key, value)
    
    return builder.getOrCreate()


@handle_exception
def get_dataframe_info(df: DataFrame) -> Dict[str, Any]:
    """
    Get information about a DataFrame
    
    Args:
        df: Spark DataFrame
        
    Returns:
        Dictionary with DataFrame information
    """
    count = df.count()
    schema_info = {field.name: str(field.dataType) for field in df.schema.fields}
    
    return {
        "count": count,
        "schema": schema_info,
        "columns": df.columns,
        "partitions": df.rdd.getNumPartitions()
    }


@handle_exception
def repartition_df(df: DataFrame, num_partitions: Optional[int] = None, 
                  partition_cols: Optional[List[str]] = None) -> DataFrame:
    """
    Repartition a DataFrame for better performance
    
    Args:
        df: Spark DataFrame
        num_partitions: Number of partitions to use
        partition_cols: Columns to partition by
        
    Returns:
        Repartitioned DataFrame
    """
    if partition_cols:
        logger.info(f"Repartitioning DataFrame by columns: {partition_cols}")
        return df.repartition(*partition_cols)
    elif num_partitions:
        logger.info(f"Repartitioning DataFrame to {num_partitions} partitions")
        return df.repartition(num_partitions)
    else:
        # Estimate a good partition count based on data size
        count = df.count()
        estimated_partitions = max(200, min(count // 100000, 1000))
        logger.info(f"Auto-repartitioning DataFrame to {estimated_partitions} partitions")
        return df.repartition(estimated_partitions)


@handle_exception
def persist_dataframe(df: DataFrame, storage_level: str = "MEMORY_AND_DISK") -> DataFrame:
    """
    Persist a DataFrame with the specified storage level
    
    Args:
        df: Spark DataFrame
        storage_level: Storage level to use
        
    Returns:
        Persisted DataFrame
    """
    from pyspark.storagelevel import StorageLevel
    
    storage_levels = {
        "MEMORY_ONLY": StorageLevel.MEMORY_ONLY,
        "MEMORY_AND_DISK": StorageLevel.MEMORY_AND_DISK,
        "MEMORY_ONLY_SER": StorageLevel.MEMORY_ONLY_SER,
        "MEMORY_AND_DISK_SER": StorageLevel.MEMORY_AND_DISK_SER,
        "DISK_ONLY": StorageLevel.DISK_ONLY,
        "OFF_HEAP": StorageLevel.OFF_HEAP
    }
    
    level = storage_levels.get(storage_level, StorageLevel.MEMORY_AND_DISK)
    logger.info(f"Persisting DataFrame with storage level: {storage_level}")
    
    return df.persist(level)


@handle_exception
def save_checkpoint(df: DataFrame, checkpoint_dir: str, name: str) -> DataFrame:
    """
    Save a DataFrame checkpoint to break lineage and improve performance for complex pipelines
    
    Args:
        df: Spark DataFrame
        checkpoint_dir: Directory to store checkpoint
        name: Checkpoint name
        
    Returns:
        Checkpointed DataFrame
    """
    # Create checkpoint directory if it doesn't exist
    spark = df.sparkSession
    sc = spark.sparkContext
    
    if not checkpoint_dir.startswith("hdfs://") and not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir, exist_ok=True)
    
    # Set checkpoint directory
    sc.setCheckpointDir(checkpoint_dir)
    
    # Create a unique checkpoint name
    import uuid
    import datetime
    
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    checkpoint_id = f"{name}_{timestamp}_{str(uuid.uuid4())[:8]}"
    
    logger.info(f"Creating checkpoint: {checkpoint_id}")
    
    # Cache, checkpoint, and force materialization
    df = df.cache()
    df.checkpoint(True)
    df.count()  # Force materialization
    
    return df


@handle_exception
def join_dataframes(dfs: List[DataFrame], join_columns: Dict[str, str], 
                   join_type: str = "inner") -> DataFrame:
    """
    Join multiple DataFrames based on column mappings
    
    Args:
        dfs: List of DataFrames to join
        join_columns: Dictionary mapping join columns between DataFrames
        join_type: Type of join to perform
        
    Returns:
        Joined DataFrame
    """
    if not dfs:
        raise DataSourceError("No DataFrames provided for joining")
    
    if len(dfs) == 1:
        return dfs[0]
    
    result_df = dfs[0]
    
    for i, right_df in enumerate(dfs[1:], 1):
        # Get join columns for this pair of DataFrames
        left_key = f"df0_df{i}"
        if left_key in join_columns:
            left_col = join_columns[left_key]
            right_col = join_columns.get(f"df{i}", left_col)
            
            logger.info(f"Joining DataFrame {i} on columns: {left_col} = {right_col}")
            
            # Handle potentially different column names
            if left_col != right_col:
                join_condition = result_df[left_col] == right_df[right_col]
            else:
                join_condition = left_col
                
            result_df = result_df.join(right_df, on=join_condition, how=join_type)
        else:
            raise DataSourceError(f"Join columns not specified for DataFrames 0 and {i}")
    
    return result_df


@handle_exception
def explode_array_column(df: DataFrame, array_column: str, 
                        new_column: Optional[str] = None) -> DataFrame:
    """
    Explode an array column into multiple rows
    
    Args:
        df: Spark DataFrame
        array_column: Column containing arrays to explode
        new_column: Name for the exploded column
        
    Returns:
        DataFrame with exploded array column
    """
    if new_column:
        return df.withColumn(new_column, F.explode_outer(F.col(array_column)))
    else:
        return df.withColumn(array_column, F.explode_outer(F.col(array_column)))


@handle_exception
def profile_dataframe(df: DataFrame, sample_ratio: float = 0.1, 
                     num_columns: Optional[int] = None) -> Dict[str, Any]:
    """
    Generate profile statistics for a DataFrame
    
    Args:
        df: Spark DataFrame to profile
        sample_ratio: Ratio of data to sample (0.0 to 1.0)
        num_columns: Maximum number of columns to profile
        
    Returns:
        Dictionary with profile statistics
    """
    # Sample the DataFrame if ratio < 1.0
    if 0.0 < sample_ratio < 1.0:
        profiled_df = df.sample(withReplacement=False, fraction=sample_ratio)
    else:
        profiled_df = df
    
    # Select columns to profile
    columns_to_profile = df.columns
    if num_columns and len(columns_to_profile) > num_columns:
        columns_to_profile = columns_to_profile[:num_columns]
    
    # Basic statistics
    profile = {
        "record_count": profiled_df.count(),
        "column_count": len(df.columns),
        "columns": {}
    }
    
    # Generate statistics for each column
    for column in columns_to_profile:
        col_stats = profiled_df.select(
            F.count(column).alias("count"),
            F.countDistinct(column).alias("distinct_count"),
            F.count(F.when(F.col(column).isNull(), 1)).alias("null_count"),
            F.mean(column).alias("mean") if isinstance(profiled_df.schema[column].dataType, 
                                                    (T.IntegerType, T.LongType, T.FloatType, T.DoubleType)) else F.lit(None),
            F.min(column).alias("min"),
            F.max(column).alias("max")
        ).collect()[0].asDict()
        
        profile["columns"][column] = col_stats
    
    return profile


@handle_exception
def get_or_create_empty_dataframe(spark: SparkSession, schema: T.StructType) -> DataFrame:
    """
    Create an empty DataFrame with the specified schema
    
    Args:
        spark: SparkSession
        schema: Schema for the DataFrame
        
    Returns:
        Empty DataFrame with the specified schema
    """
    return spark.createDataFrame([], schema) 