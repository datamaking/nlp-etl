"""
Configuration module for the NLP ETL Pipeline
""" 