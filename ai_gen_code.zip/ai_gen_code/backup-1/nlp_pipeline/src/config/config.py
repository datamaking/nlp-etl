"""
Configuration classes for the NLP ETL Pipeline
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Union, Any
import os
import yaml
import json
import logging
from pyspark.sql import SparkSession


class Department(Enum):
    """Enum for departments"""
    ADMIN = "ADMIN"
    HR = "HR"
    FINANCE = "FINANCE"
    IT_HELPDESK = "IT_HELPDESK"


class SourceType(Enum):
    """Enum for data source types"""
    HIVE = "HIVE"
    HDFS = "HDFS"
    LOCAL_FILE = "LOCAL_FILE"
    RDBMS = "RDBMS"


class FileFormat(Enum):
    """Enum for file formats"""
    TEXT = "TEXT"
    HTML = "HTML"
    JSON = "JSON"
    CSV = "CSV"


class TargetType(Enum):
    """Enum for data target types"""
    HIVE = "HIVE"
    HDFS = "HDFS"
    LOCAL_FILE = "LOCAL_FILE"
    RDBMS = "RDBMS"
    CHROMADB = "CHROMADB"
    POSTGRES_VECTOR = "POSTGRES_VECTOR"
    NEO4J = "NEO4J"


class LoadType(Enum):
    """Enum for data load types"""
    FULL = "FULL"
    INCREMENTAL_SCD2 = "INCREMENTAL_SCD2"
    INCREMENTAL_CDC = "INCREMENTAL_CDC"


class PreprocessingType(Enum):
    """Enum for preprocessing types"""
    HTML_PARSING = "HTML_PARSING"
    DATA_CLEANING = "DATA_CLEANING"
    STOPWORD_REMOVAL = "STOPWORD_REMOVAL"
    STEMMING = "STEMMING"
    LEMMATIZATION = "LEMMATIZATION"


class ChunkingStrategy(Enum):
    """Enum for chunking strategies"""
    FIXED_SIZE = "FIXED_SIZE"
    SENTENCE = "SENTENCE"
    PARAGRAPH = "PARAGRAPH"
    RECURSIVE = "RECURSIVE"
    SEMANTIC = "SEMANTIC"


class EmbeddingType(Enum):
    """Enum for embedding types"""
    TFIDF = "TFIDF"
    SENTENCE_ST5 = "SENTENCE_ST5"


@dataclass
class BaseConfig(ABC):
    """Abstract base configuration class"""
    name: str
    department: Department
    
    @abstractmethod
    def validate(self) -> bool:
        """Validate configuration"""
        pass
    
    def to_dict(self) -> Dict:
        """Convert config to dictionary"""
        return {k: (v.value if isinstance(v, Enum) else v) 
                for k, v in self.__dict__.items()}


@dataclass
class SourceConfig(BaseConfig):
    """Configuration for data sources"""
    source_type: SourceType
    file_format: Optional[FileFormat] = None
    tables: List[str] = field(default_factory=list)
    queries: List[str] = field(default_factory=list)
    join_columns: Optional[Dict[str, str]] = None
    connection_params: Optional[Dict[str, str]] = None
    file_paths: List[str] = field(default_factory=list)
    text_column: Optional[str] = None
    
    def validate(self) -> bool:
        """Validate source configuration"""
        if self.source_type in [SourceType.HIVE, SourceType.RDBMS] and not (self.tables or self.queries):
            return False
        if self.source_type in [SourceType.HDFS, SourceType.LOCAL_FILE] and not self.file_paths:
            return False
        if self.source_type == SourceType.RDBMS and not self.connection_params:
            return False
        return True


@dataclass
class PreprocessingConfig(BaseConfig):
    """Configuration for preprocessing"""
    preprocessing_types: List[PreprocessingType]
    params: Dict[str, Any] = field(default_factory=dict)
    
    def validate(self) -> bool:
        """Validate preprocessing configuration"""
        if not self.preprocessing_types:
            return False
        return True


@dataclass
class ChunkingConfig(BaseConfig):
    """Configuration for chunking"""
    chunking_strategy: ChunkingStrategy
    chunk_size: int = 512
    chunk_overlap: int = 50
    enable_smoothing: bool = True
    
    def validate(self) -> bool:
        """Validate chunking configuration"""
        if self.chunk_size <= 0:
            return False
        if self.chunk_overlap >= self.chunk_size:
            return False
        return True


@dataclass
class EmbeddingConfig(BaseConfig):
    """Configuration for embedding generation"""
    embedding_type: EmbeddingType
    model_path: Optional[str] = None
    batch_size: int = 32
    max_sequence_length: int = 512
    
    def validate(self) -> bool:
        """Validate embedding configuration"""
        if self.embedding_type == EmbeddingType.SENTENCE_ST5 and not self.model_path:
            return False
        if self.batch_size <= 0:
            return False
        return True


@dataclass
class TargetConfig(BaseConfig):
    """Configuration for data targets"""
    target_type: TargetType
    load_type: LoadType
    file_format: Optional[FileFormat] = None
    table_name: Optional[str] = None
    file_path: Optional[str] = None
    connection_params: Optional[Dict[str, str]] = None
    partition_columns: List[str] = field(default_factory=list)
    
    def validate(self) -> bool:
        """Validate target configuration"""
        if self.target_type in [TargetType.HIVE, TargetType.RDBMS] and not self.table_name:
            return False
        if self.target_type in [TargetType.HDFS, TargetType.LOCAL_FILE] and not self.file_path:
            return False
        if self.target_type in [TargetType.RDBMS, TargetType.CHROMADB, 
                               TargetType.POSTGRES_VECTOR, TargetType.NEO4J] and not self.connection_params:
            return False
        return True


@dataclass
class PipelineConfig:
    """Main pipeline configuration"""
    pipeline_name: str
    department: Department
    spark_config: Dict[str, str] = field(default_factory=dict)
    source_config: Optional[SourceConfig] = None
    preprocessing_config: Optional[PreprocessingConfig] = None
    chunking_config: Optional[ChunkingConfig] = None
    embedding_config: Optional[EmbeddingConfig] = None
    target_config: Optional[TargetConfig] = None
    intermediate_storage: Dict[str, str] = field(default_factory=dict)
    
    def validate(self) -> bool:
        """Validate pipeline configuration"""
        # Check if at least one stage is configured
        if not any([self.source_config, self.preprocessing_config, 
                   self.chunking_config, self.embedding_config, self.target_config]):
            return False
        
        # Validate each stage configuration if present
        if self.source_config and not self.source_config.validate():
            return False
        if self.preprocessing_config and not self.preprocessing_config.validate():
            return False
        if self.chunking_config and not self.chunking_config.validate():
            return False
        if self.embedding_config and not self.embedding_config.validate():
            return False
        if self.target_config and not self.target_config.validate():
            return False
        
        return True
    
    @classmethod
    def from_yaml(cls, yaml_path: str) -> 'PipelineConfig':
        """Load pipeline configuration from YAML file"""
        with open(yaml_path, 'r') as f:
            config_dict = yaml.safe_load(f)
        
        # Convert string enum values to Enum instances
        if 'department' in config_dict:
            config_dict['department'] = Department(config_dict['department'])
        
        # Process source config
        if 'source_config' in config_dict and config_dict['source_config']:
            src_cfg = config_dict['source_config']
            if 'source_type' in src_cfg:
                src_cfg['source_type'] = SourceType(src_cfg['source_type'])
            if 'file_format' in src_cfg and src_cfg['file_format']:
                src_cfg['file_format'] = FileFormat(src_cfg['file_format'])
            if 'department' in src_cfg:
                src_cfg['department'] = Department(src_cfg['department'])
            config_dict['source_config'] = SourceConfig(**src_cfg)
        
        # Process preprocessing config
        if 'preprocessing_config' in config_dict and config_dict['preprocessing_config']:
            pre_cfg = config_dict['preprocessing_config']
            if 'preprocessing_types' in pre_cfg:
                pre_cfg['preprocessing_types'] = [PreprocessingType(t) for t in pre_cfg['preprocessing_types']]
            if 'department' in pre_cfg:
                pre_cfg['department'] = Department(pre_cfg['department'])
            config_dict['preprocessing_config'] = PreprocessingConfig(**pre_cfg)
        
        # Process chunking config
        if 'chunking_config' in config_dict and config_dict['chunking_config']:
            chk_cfg = config_dict['chunking_config']
            if 'chunking_strategy' in chk_cfg:
                chk_cfg['chunking_strategy'] = ChunkingStrategy(chk_cfg['chunking_strategy'])
            if 'department' in chk_cfg:
                chk_cfg['department'] = Department(chk_cfg['department'])
            config_dict['chunking_config'] = ChunkingConfig(**chk_cfg)
        
        # Process embedding config
        if 'embedding_config' in config_dict and config_dict['embedding_config']:
            emb_cfg = config_dict['embedding_config']
            if 'embedding_type' in emb_cfg:
                emb_cfg['embedding_type'] = EmbeddingType(emb_cfg['embedding_type'])
            if 'department' in emb_cfg:
                emb_cfg['department'] = Department(emb_cfg['department'])
            config_dict['embedding_config'] = EmbeddingConfig(**emb_cfg)
        
        # Process target config
        if 'target_config' in config_dict and config_dict['target_config']:
            tgt_cfg = config_dict['target_config']
            if 'target_type' in tgt_cfg:
                tgt_cfg['target_type'] = TargetType(tgt_cfg['target_type'])
            if 'load_type' in tgt_cfg:
                tgt_cfg['load_type'] = LoadType(tgt_cfg['load_type'])
            if 'file_format' in tgt_cfg and tgt_cfg['file_format']:
                tgt_cfg['file_format'] = FileFormat(tgt_cfg['file_format'])
            if 'department' in tgt_cfg:
                tgt_cfg['department'] = Department(tgt_cfg['department'])
            config_dict['target_config'] = TargetConfig(**tgt_cfg)
        
        return cls(**config_dict)
    
    def to_yaml(self, yaml_path: str) -> None:
        """Save pipeline configuration to YAML file"""
        config_dict = {
            'pipeline_name': self.pipeline_name,
            'department': self.department.value,
            'spark_config': self.spark_config,
            'intermediate_storage': self.intermediate_storage
        }
        
        # Convert configs to dictionaries
        if self.source_config:
            config_dict['source_config'] = self.source_config.to_dict()
        
        if self.preprocessing_config:
            config_dict['preprocessing_config'] = self.preprocessing_config.to_dict()
        
        if self.chunking_config:
            config_dict['chunking_config'] = self.chunking_config.to_dict()
        
        if self.embedding_config:
            config_dict['embedding_config'] = self.embedding_config.to_dict()
        
        if self.target_config:
            config_dict['target_config'] = self.target_config.to_dict()
        
        with open(yaml_path, 'w') as f:
            yaml.dump(config_dict, f, default_flow_style=False)
    
    def get_spark_session(self) -> SparkSession:
        """Create and configure Spark session from config"""
        builder = SparkSession.builder.appName(self.pipeline_name)
        
        # Apply custom Spark configurations
        for key, value in self.spark_config.items():
            builder = builder.config(key, value)
        
        return builder.getOrCreate()


class ConfigurationFactory:
    """Factory class for creating configurations"""
    
    @staticmethod
    def create_source_config(
        name: str,
        department: Department,
        source_type: SourceType,
        **kwargs
    ) -> SourceConfig:
        """Create a source configuration"""
        return SourceConfig(
            name=name,
            department=department,
            source_type=source_type,
            **kwargs
        )
    
    @staticmethod
    def create_preprocessing_config(
        name: str,
        department: Department,
        preprocessing_types: List[PreprocessingType],
        **kwargs
    ) -> PreprocessingConfig:
        """Create a preprocessing configuration"""
        return PreprocessingConfig(
            name=name,
            department=department,
            preprocessing_types=preprocessing_types,
            **kwargs
        )
    
    @staticmethod
    def create_chunking_config(
        name: str,
        department: Department,
        chunking_strategy: ChunkingStrategy,
        **kwargs
    ) -> ChunkingConfig:
        """Create a chunking configuration"""
        return ChunkingConfig(
            name=name,
            department=department,
            chunking_strategy=chunking_strategy,
            **kwargs
        )
    
    @staticmethod
    def create_embedding_config(
        name: str,
        department: Department,
        embedding_type: EmbeddingType,
        **kwargs
    ) -> EmbeddingConfig:
        """Create an embedding configuration"""
        return EmbeddingConfig(
            name=name,
            department=department,
            embedding_type=embedding_type,
            **kwargs
        )
    
    @staticmethod
    def create_target_config(
        name: str,
        department: Department,
        target_type: TargetType,
        load_type: LoadType,
        **kwargs
    ) -> TargetConfig:
        """Create a target configuration"""
        return TargetConfig(
            name=name,
            department=department,
            target_type=target_type,
            load_type=load_type,
            **kwargs
        )
    
    @staticmethod
    def create_pipeline_config(
        pipeline_name: str,
        department: Department,
        **kwargs
    ) -> PipelineConfig:
        """Create a pipeline configuration"""
        return PipelineConfig(
            pipeline_name=pipeline_name,
            department=department,
            **kwargs
        ) 