"""
Preprocessing module for the NLP ETL Pipeline
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Set
import logging
import re

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.functions import udf

from src.config.config import PreprocessingConfig, PreprocessingType, Department
from src.logging_module.logger import get_logger, log_execution_time
from src.exception.exceptions import handle_exception, PreprocessingError
from src.utils.text_utils import (
    clean_text, normalize_unicode, remove_stopwords, stem_text, 
    lemmatize_text, parse_html, get_stopwords
)

logger = get_logger(__name__)


# Define UDFs for text processing
@udf(returnType=T.StringType())
def clean_text_udf(text, remove_urls=True, remove_html=True, 
                  remove_special_chars=True, remove_numbers=True,
                  normalize_whitespace=True, lowercase=True):
    """UDF wrapper for clean_text function"""
    return clean_text(
        text, 
        remove_urls=remove_urls,
        remove_html=remove_html,
        remove_special_chars=remove_special_chars,
        remove_numbers=remove_numbers,
        normalize_whitespace=normalize_whitespace,
        lowercase=lowercase
    )


@udf(returnType=T.StringType())
def normalize_unicode_udf(text, form='NFKC'):
    """UDF wrapper for normalize_unicode function"""
    return normalize_unicode(text, form=form)


@udf(returnType=T.StringType())
def remove_stopwords_udf(text, language='english'):
    """UDF wrapper for remove_stopwords function"""
    stopwords = get_stopwords(language)
    return remove_stopwords(text, stopwords, language)


@udf(returnType=T.StringType())
def stem_text_udf(text, language='english'):
    """UDF wrapper for stem_text function"""
    return stem_text(text, language)


@udf(returnType=T.StringType())
def lemmatize_text_udf(text, language='english'):
    """UDF wrapper for lemmatize_text function"""
    return lemmatize_text(text, language)


@udf(returnType=T.StringType())
def parse_html_udf(html_text):
    """UDF wrapper for parse_html function"""
    return parse_html(html_text)


class Preprocessor(ABC):
    """Abstract base class for all preprocessors"""
    
    def __init__(self, config: PreprocessingConfig, spark: SparkSession):
        """
        Initialize the preprocessor
        
        Args:
            config: Preprocessing configuration
            spark: Spark session
        """
        self.config = config
        self.spark = spark
        self.validate_config()
    
    def validate_config(self) -> bool:
        """
        Validate the configuration
        
        Returns:
            True if configuration is valid, False otherwise
        """
        if not self.config.validate():
            raise PreprocessingError("Invalid preprocessing configuration")
        return True
    
    @abstractmethod
    def preprocess(self, df: DataFrame) -> DataFrame:
        """
        Preprocess the data
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with preprocessed data
        """
        pass


class HTMLParsingPreprocessor(Preprocessor):
    """Preprocessor for HTML parsing"""
    
    @log_execution_time(stage_name="HTMLParsing")
    @handle_exception
    def preprocess(self, df: DataFrame) -> DataFrame:
        """
        Parse HTML content in text column
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with parsed HTML
        """
        logger.info("Parsing HTML content")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise PreprocessingError("Text column not found in DataFrame")
        
        # Apply HTML parsing
        return df.withColumn("text", parse_html_udf("text"))


class DataCleaningPreprocessor(Preprocessor):
    """Preprocessor for data cleaning"""
    
    @log_execution_time(stage_name="DataCleaning")
    @handle_exception
    def preprocess(self, df: DataFrame) -> DataFrame:
        """
        Clean text data
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with cleaned text
        """
        logger.info("Cleaning text data")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise PreprocessingError("Text column not found in DataFrame")
        
        # Get parameters from config
        params = self.config.params
        remove_urls = params.get("remove_urls", True)
        remove_html = params.get("remove_html", True)
        remove_special_chars = params.get("remove_special_chars", True)
        remove_numbers = params.get("remove_numbers", True)
        normalize_whitespace = params.get("normalize_whitespace", True)
        lowercase = params.get("lowercase", True)
        
        # Apply data cleaning
        return df.withColumn(
            "text", 
            clean_text_udf(
                "text", 
                F.lit(remove_urls), 
                F.lit(remove_html),
                F.lit(remove_special_chars),
                F.lit(remove_numbers),
                F.lit(normalize_whitespace),
                F.lit(lowercase)
            )
        )


class StopwordRemovalPreprocessor(Preprocessor):
    """Preprocessor for stopword removal"""
    
    @log_execution_time(stage_name="StopwordRemoval")
    @handle_exception
    def preprocess(self, df: DataFrame) -> DataFrame:
        """
        Remove stopwords from text
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with stopwords removed
        """
        logger.info("Removing stopwords")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise PreprocessingError("Text column not found in DataFrame")
        
        # Get parameters from config
        params = self.config.params
        language = params.get("language", "english")
        
        # Apply stopword removal
        return df.withColumn("text", remove_stopwords_udf("text", F.lit(language)))


class StemmingPreprocessor(Preprocessor):
    """Preprocessor for stemming"""
    
    @log_execution_time(stage_name="Stemming")
    @handle_exception
    def preprocess(self, df: DataFrame) -> DataFrame:
        """
        Apply stemming to text
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with stemmed text
        """
        logger.info("Applying stemming")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise PreprocessingError("Text column not found in DataFrame")
        
        # Get parameters from config
        params = self.config.params
        language = params.get("language", "english")
        
        # Apply stemming
        return df.withColumn("text", stem_text_udf("text", F.lit(language)))


class LemmatizationPreprocessor(Preprocessor):
    """Preprocessor for lemmatization"""
    
    @log_execution_time(stage_name="Lemmatization")
    @handle_exception
    def preprocess(self, df: DataFrame) -> DataFrame:
        """
        Apply lemmatization to text
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with lemmatized text
        """
        logger.info("Applying lemmatization")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise PreprocessingError("Text column not found in DataFrame")
        
        # Get parameters from config
        params = self.config.params
        language = params.get("language", "english")
        
        # Apply lemmatization
        return df.withColumn("text", lemmatize_text_udf("text", F.lit(language)))


class PreprocessingPipeline:
    """Pipeline for applying multiple preprocessing steps"""
    
    def __init__(self, config: PreprocessingConfig, spark: SparkSession):
        """
        Initialize the preprocessing pipeline
        
        Args:
            config: Preprocessing configuration
            spark: Spark session
        """
        self.config = config
        self.spark = spark
        self.preprocessing_steps = self._create_preprocessing_steps()
    
    @handle_exception
    def _create_preprocessing_steps(self) -> List[Preprocessor]:
        """
        Create preprocessing steps based on configuration
        
        Returns:
            List of preprocessors
        """
        steps = []
        
        for preprocessing_type in self.config.preprocessing_types:
            if preprocessing_type == PreprocessingType.HTML_PARSING:
                steps.append(HTMLParsingPreprocessor(self.config, self.spark))
            elif preprocessing_type == PreprocessingType.DATA_CLEANING:
                steps.append(DataCleaningPreprocessor(self.config, self.spark))
            elif preprocessing_type == PreprocessingType.STOPWORD_REMOVAL:
                steps.append(StopwordRemovalPreprocessor(self.config, self.spark))
            elif preprocessing_type == PreprocessingType.STEMMING:
                steps.append(StemmingPreprocessor(self.config, self.spark))
            elif preprocessing_type == PreprocessingType.LEMMATIZATION:
                steps.append(LemmatizationPreprocessor(self.config, self.spark))
            else:
                logger.warning(f"Unsupported preprocessing type: {preprocessing_type}")
        
        return steps
    
    @log_execution_time(stage_name="PreprocessingPipeline")
    @handle_exception
    def preprocess(self, df: DataFrame) -> DataFrame:
        """
        Apply all preprocessing steps
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with preprocessed data
        """
        logger.info(f"Starting preprocessing pipeline with {len(self.preprocessing_steps)} steps")
        
        result_df = df
        
        for i, preprocessor in enumerate(self.preprocessing_steps):
            logger.info(f"Applying preprocessing step {i+1}/{len(self.preprocessing_steps)}: {type(preprocessor).__name__}")
            result_df = preprocessor.preprocess(result_df)
        
        return result_df


class PreprocessorFactory:
    """Factory class for creating preprocessors"""
    
    @staticmethod
    def create_preprocessor(config: PreprocessingConfig, spark: SparkSession) -> PreprocessingPipeline:
        """
        Create a preprocessing pipeline based on configuration
        
        Args:
            config: Preprocessing configuration
            spark: Spark session
            
        Returns:
            Configured preprocessing pipeline
        """
        return PreprocessingPipeline(config, spark) 