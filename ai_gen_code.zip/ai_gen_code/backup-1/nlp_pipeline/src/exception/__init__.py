"""
Exception handling module for the NLP ETL Pipeline
""" 