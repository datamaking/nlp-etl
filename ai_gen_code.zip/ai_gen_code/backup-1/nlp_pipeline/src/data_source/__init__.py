"""
Data source module for the NLP ETL Pipeline
""" 