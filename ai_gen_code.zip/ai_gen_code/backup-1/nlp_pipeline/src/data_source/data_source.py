"""
Data source module for the NLP ETL Pipeline
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Union
import os
import logging
from pathlib import Path
import json

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

from src.config.config import SourceConfig, SourceType, FileFormat, Department
from src.logging_module.logger import get_logger, log_execution_time
from src.exception.exceptions import handle_exception, DataSourceError, DataReadError
from src.utils.spark_utils import join_dataframes

logger = get_logger(__name__)


class DataSource(ABC):
    """Abstract base class for all data sources"""
    
    def __init__(self, config: SourceConfig, spark: SparkSession):
        """
        Initialize the data source
        
        Args:
            config: Data source configuration
            spark: Spark session
        """
        self.config = config
        self.spark = spark
        self.validate_config()
    
    def validate_config(self) -> bool:
        """
        Validate the configuration
        
        Returns:
            True if configuration is valid, False otherwise
        """
        if not self.config.validate():
            raise DataSourceError("Invalid source configuration")
        return True
    
    @abstractmethod
    def read_data(self) -> DataFrame:
        """
        Read data from the source
        
        Returns:
            DataFrame with the source data
        """
        pass


class HiveSource(DataSource):
    """Data source for Hive tables"""
    
    @log_execution_time(stage_name="HiveDataSourceRead")
    @handle_exception
    def read_data(self) -> DataFrame:
        """
        Read data from Hive tables
        
        Returns:
            DataFrame with the data from Hive tables
        """
        logger.info(f"Reading data from Hive tables: {self.config.tables}")
        
        if self.config.tables:
            # Read from tables
            dataframes = []
            for table in self.config.tables:
                logger.info(f"Reading table: {table}")
                df = self.spark.table(table)
                dataframes.append(df)
            
            # Join dataframes if needed
            if len(dataframes) > 1 and self.config.join_columns:
                logger.info("Joining multiple tables")
                return join_dataframes(dataframes, self.config.join_columns)
            elif len(dataframes) == 1:
                return dataframes[0]
            else:
                raise DataReadError("Multiple tables specified but no join columns provided")
        
        elif self.config.queries:
            # Read from queries
            dataframes = []
            for i, query in enumerate(self.config.queries):
                logger.info(f"Executing query {i+1}/{len(self.config.queries)}")
                df = self.spark.sql(query)
                dataframes.append(df)
            
            # Join dataframes if needed
            if len(dataframes) > 1 and self.config.join_columns:
                logger.info("Joining multiple query results")
                return join_dataframes(dataframes, self.config.join_columns)
            elif len(dataframes) == 1:
                return dataframes[0]
            else:
                raise DataReadError("Multiple queries specified but no join columns provided")
        
        else:
            raise DataReadError("No tables or queries specified in the configuration")


class HDFSSource(DataSource):
    """Data source for HDFS files"""
    
    @log_execution_time(stage_name="HDFSDataSourceRead")
    @handle_exception
    def read_data(self) -> DataFrame:
        """
        Read data from HDFS files
        
        Returns:
            DataFrame with the data from HDFS files
        """
        logger.info(f"Reading data from HDFS files: {self.config.file_paths}")
        
        if not self.config.file_paths:
            raise DataReadError("No file paths specified in the configuration")
        
        if not self.config.file_format:
            raise DataReadError("File format not specified in the configuration")
        
        # Read all files
        dataframes = []
        for file_path in self.config.file_paths:
            logger.info(f"Reading file: {file_path}")
            
            reader = self.spark.read
            
            # Apply file format
            if self.config.file_format == FileFormat.CSV:
                df = reader.option("header", "true").option("inferSchema", "true").csv(file_path)
            elif self.config.file_format == FileFormat.JSON:
                df = reader.json(file_path)
            elif self.config.file_format == FileFormat.TEXT:
                df = reader.text(file_path)
            elif self.config.file_format == FileFormat.HTML:
                # Read HTML as plain text, parsing will be done in preprocessing
                df = reader.text(file_path)
            else:
                raise DataReadError(f"Unsupported file format: {self.config.file_format}")
            
            dataframes.append(df)
        
        # Join dataframes if needed
        if len(dataframes) > 1 and self.config.join_columns:
            logger.info("Joining multiple file dataframes")
            return join_dataframes(dataframes, self.config.join_columns)
        elif len(dataframes) == 1:
            return dataframes[0]
        else:
            raise DataReadError("Multiple files specified but no join columns provided")


class LocalFileSource(DataSource):
    """Data source for local files"""
    
    @log_execution_time(stage_name="LocalFileDataSourceRead")
    @handle_exception
    def read_data(self) -> DataFrame:
        """
        Read data from local files
        
        Returns:
            DataFrame with the data from local files
        """
        logger.info(f"Reading data from local files: {self.config.file_paths}")
        
        if not self.config.file_paths:
            raise DataReadError("No file paths specified in the configuration")
        
        if not self.config.file_format:
            raise DataReadError("File format not specified in the configuration")
        
        # Read all files
        dataframes = []
        for file_path in self.config.file_paths:
            logger.info(f"Reading file: {file_path}")
            
            # Check if file exists
            if not os.path.exists(file_path):
                raise DataReadError(f"File not found: {file_path}")
            
            reader = self.spark.read
            
            # Apply file format
            if self.config.file_format == FileFormat.CSV:
                df = reader.option("header", "true").option("inferSchema", "true").csv(file_path)
            elif self.config.file_format == FileFormat.JSON:
                df = reader.json(file_path)
            elif self.config.file_format == FileFormat.TEXT:
                df = reader.text(file_path)
            elif self.config.file_format == FileFormat.HTML:
                # Read HTML as plain text, parsing will be done in preprocessing
                df = reader.text(file_path)
            else:
                raise DataReadError(f"Unsupported file format: {self.config.file_format}")
            
            dataframes.append(df)
        
        # Join dataframes if needed
        if len(dataframes) > 1 and self.config.join_columns:
            logger.info("Joining multiple file dataframes")
            return join_dataframes(dataframes, self.config.join_columns)
        elif len(dataframes) == 1:
            return dataframes[0]
        else:
            raise DataReadError("Multiple files specified but no join columns provided")


class RDBMSSource(DataSource):
    """Data source for RDBMS databases"""
    
    @log_execution_time(stage_name="RDBMSDataSourceRead")
    @handle_exception
    def read_data(self) -> DataFrame:
        """
        Read data from RDBMS
        
        Returns:
            DataFrame with the data from RDBMS
        """
        logger.info("Reading data from RDBMS")
        
        if not self.config.connection_params:
            raise DataReadError("No connection parameters specified in the configuration")
        
        # Extract connection parameters
        jdbc_url = self.config.connection_params.get("jdbc_url")
        driver = self.config.connection_params.get("driver")
        user = self.config.connection_params.get("user")
        password = self.config.connection_params.get("password")
        
        if not jdbc_url:
            raise DataReadError("JDBC URL not specified in connection parameters")
        
        # Read from tables or queries
        dataframes = []
        
        if self.config.tables:
            for table in self.config.tables:
                logger.info(f"Reading table: {table}")
                
                df = (self.spark.read
                     .format("jdbc")
                     .option("url", jdbc_url)
                     .option("dbtable", table)
                     .option("driver", driver)
                     .option("user", user)
                     .option("password", password)
                     .load())
                
                dataframes.append(df)
        
        elif self.config.queries:
            for i, query in enumerate(self.config.queries):
                logger.info(f"Executing query {i+1}/{len(self.config.queries)}")
                
                # Create a unique query alias
                query_alias = f"({query}) as query_{i}"
                
                df = (self.spark.read
                     .format("jdbc")
                     .option("url", jdbc_url)
                     .option("dbtable", query_alias)
                     .option("driver", driver)
                     .option("user", user)
                     .option("password", password)
                     .load())
                
                dataframes.append(df)
        
        else:
            raise DataReadError("No tables or queries specified in the configuration")
        
        # Join dataframes if needed
        if len(dataframes) > 1 and self.config.join_columns:
            logger.info("Joining multiple table/query dataframes")
            return join_dataframes(dataframes, self.config.join_columns)
        elif len(dataframes) == 1:
            return dataframes[0]
        else:
            raise DataReadError("Multiple tables/queries specified but no join columns provided")


class DataSourceFactory:
    """Factory class for creating data sources"""
    
    @staticmethod
    def create_data_source(config: SourceConfig, spark: SparkSession) -> DataSource:
        """
        Create a data source based on configuration
        
        Args:
            config: Data source configuration
            spark: Spark session
            
        Returns:
            Configured data source
        """
        if config.source_type == SourceType.HIVE:
            return HiveSource(config, spark)
        elif config.source_type == SourceType.HDFS:
            return HDFSSource(config, spark)
        elif config.source_type == SourceType.LOCAL_FILE:
            return LocalFileSource(config, spark)
        elif config.source_type == SourceType.RDBMS:
            return RDBMSSource(config, spark)
        else:
            raise DataSourceError(f"Unsupported source type: {config.source_type}")


@log_execution_time(stage_name="DataSourceExtraction")
@handle_exception
def get_department_text_column(department: Department, df: DataFrame) -> DataFrame:
    """
    Get the appropriate text column for a specific department
    
    Args:
        department: Department for which to get the text column
        df: Input DataFrame
        
    Returns:
        DataFrame with standardized text column
    """
    # Define department-specific text columns
    department_columns = {
        Department.ADMIN: ["admin_text", "administration_notes", "admin_description"],
        Department.HR: ["hr_text", "employee_notes", "hr_description", "candidate_feedback"],
        Department.FINANCE: ["finance_text", "transaction_notes", "finance_description"],
        Department.IT_HELPDESK: ["ticket_description", "issue_details", "resolution_notes"]
    }
    
    # Get the list of potential columns for this department
    potential_columns = department_columns.get(department, [])
    
    # Find the first matching column in the DataFrame
    text_column = None
    for col in potential_columns:
        if col in df.columns:
            text_column = col
            break
    
    if not text_column:
        # If no specific column found, check if there's a config-specified text column
        if hasattr(department, 'text_column') and department.text_column in df.columns:
            text_column = department.text_column
        else:
            # Try common text columns
            common_text_columns = ["text", "content", "description", "notes"]
            for col in common_text_columns:
                if col in df.columns:
                    text_column = col
                    break
    
    if not text_column:
        raise DataSourceError(f"Could not find a suitable text column for department {department.value}")
    
    logger.info(f"Using text column '{text_column}' for department {department.value}")
    
    # Standardize column name to 'text' for consistency in downstream processing
    return df.withColumn("text", F.col(text_column)) 