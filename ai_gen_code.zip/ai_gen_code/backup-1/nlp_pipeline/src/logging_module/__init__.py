"""
Logging module for the NLP ETL Pipeline
""" 