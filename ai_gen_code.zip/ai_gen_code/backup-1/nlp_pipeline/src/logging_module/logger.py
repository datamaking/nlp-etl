"""
Logging configuration for the NLP ETL Pipeline
"""
import logging
import logging.config
import json
import os
import datetime
import functools
import time
from typing import Dict, Any, Optional, Callable
from pathlib import Path


class PipelineLogger:
    """Singleton logger class for the NLP ETL Pipeline"""
    _instance = None
    _logger = None
    
    def __new__(cls, *args, **kwargs):
        """Ensure singleton instance"""
        if cls._instance is None:
            cls._instance = super(PipelineLogger, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, log_level: str = "INFO", log_dir: str = "logs", app_name: str = "nlp_pipeline"):
        """Initialize the logger"""
        if self._initialized:
            return
        
        self.log_level = log_level
        self.log_dir = log_dir
        self.app_name = app_name
        self._execution_timers = {}
        self._stage_timers = {}
        
        # Create log directory if it doesn't exist
        os.makedirs(self.log_dir, exist_ok=True)
        
        # Generate log file name with timestamp
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = os.path.join(self.log_dir, f"{self.app_name}_{timestamp}.log")
        
        # Configure logger
        self._configure_logger()
        self._initialized = True
    
    def _configure_logger(self):
        """Configure the logging system"""
        log_config = {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "simple": {
                    "format": "%(levelname)s: %(message)s"
                },
                "detailed": {
                    "format": "%(asctime)s [%(levelname)s] [%(name)s:%(lineno)d] - %(message)s",
                    "datefmt": "%Y-%m-%d %H:%M:%S"
                },
                "json": {
                    "class": "pythonjsonlogger.jsonlogger.JsonFormatter",
                    "format": "%(asctime)s %(name)s %(levelname)s %(message)s"
                }
            },
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "level": self.log_level,
                    "formatter": "simple",
                    "stream": "ext://sys.stdout"
                },
                "file": {
                    "class": "logging.FileHandler",
                    "level": self.log_level,
                    "formatter": "detailed",
                    "filename": self.log_file,
                    "encoding": "utf8"
                }
            },
            "loggers": {
                "": {  # Root logger
                    "handlers": ["console", "file"],
                    "level": self.log_level,
                    "propagate": True
                }
            }
        }
        
        # Try to configure with json logger if available
        try:
            from pythonjsonlogger import jsonlogger
            log_config["handlers"]["json_file"] = {
                "class": "logging.FileHandler",
                "level": self.log_level,
                "formatter": "json",
                "filename": self.log_file.replace(".log", ".json"),
                "encoding": "utf8"
            }
            log_config["loggers"][""]["handlers"].append("json_file")
        except ImportError:
            pass
        
        logging.config.dictConfig(log_config)
        self._logger = logging.getLogger(self.app_name)
        self._logger.info(f"Logger initialized, logs will be saved to {self.log_file}")
    
    @property
    def logger(self):
        """Get the configured logger"""
        return self._logger
    
    def start_pipeline_timer(self):
        """Start timing the entire pipeline execution"""
        self._execution_timers["pipeline"] = time.time()
        self._logger.info("Pipeline execution started")
    
    def end_pipeline_timer(self):
        """End timing for the pipeline and log results"""
        if "pipeline" in self._execution_timers:
            elapsed_time = time.time() - self._execution_timers["pipeline"]
            self._logger.info(f"Pipeline execution completed in {elapsed_time:.2f} seconds")
            
            # Log all stage times if available
            if self._stage_timers:
                self._logger.info("Pipeline Stage Execution Times:")
                total_stage_time = 0
                for stage, duration in self._stage_timers.items():
                    self._logger.info(f"  - {stage}: {duration:.2f} seconds")
                    total_stage_time += duration
                
                # Calculate overhead
                overhead = elapsed_time - total_stage_time
                if overhead > 0:
                    self._logger.info(f"  - Overhead: {overhead:.2f} seconds")
            
            return elapsed_time
        return None
    
    def start_stage_timer(self, stage_name: str):
        """Start timing a specific pipeline stage"""
        timer_key = f"stage_{stage_name}"
        self._execution_timers[timer_key] = time.time()
        self._logger.info(f"Stage '{stage_name}' started")
    
    def end_stage_timer(self, stage_name: str):
        """End timing for a specific stage and log results"""
        timer_key = f"stage_{stage_name}"
        if timer_key in self._execution_timers:
            elapsed_time = time.time() - self._execution_timers[timer_key]
            self._stage_timers[stage_name] = elapsed_time
            self._logger.info(f"Stage '{stage_name}' completed in {elapsed_time:.2f} seconds")
            return elapsed_time
        return None
    
    def log_execution_summary(self) -> Dict[str, float]:
        """Generate and log execution summary report"""
        report = {
            "pipeline_total": self._execution_timers.get("pipeline", 0),
            "stages": self._stage_timers
        }
        
        self._logger.info(f"Execution Summary Report: {json.dumps(report, indent=2)}")
        return report


def log_execution_time(func=None, *, stage_name: Optional[str] = None):
    """Decorator to log execution time of functions or methods"""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger = PipelineLogger().logger
            func_name = stage_name or func.__name__
            
            logger.debug(f"Executing {func_name}")
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                elapsed_time = time.time() - start_time
                logger.debug(f"{func_name} completed in {elapsed_time:.2f} seconds")
                return result
            except Exception as e:
                elapsed_time = time.time() - start_time
                logger.error(f"{func_name} failed after {elapsed_time:.2f} seconds with error: {str(e)}")
                raise
        
        return wrapper
    
    # Handle both @log_execution_time and @log_execution_time(stage_name="...")
    if func is None:
        return decorator
    return decorator(func)


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """Get a logger instance with the specified name"""
    logger_name = name or "nlp_pipeline"
    return logging.getLogger(logger_name)


class LoggingContext:
    """Context manager for adding temporary context to logs"""
    
    def __init__(self, logger, context: Dict[str, Any], level: int = logging.INFO, log_on_enter: bool = True):
        self.logger = logger
        self.context = context
        self.level = level
        self.log_on_enter = log_on_enter
        self.old_context = {}
    
    def __enter__(self):
        # Store and update existing context
        if hasattr(self.logger, 'context'):
            self.old_context = self.logger.context.copy()
            self.logger.context.update(self.context)
        else:
            self.logger.context = self.context
        
        if self.log_on_enter:
            self.logger.log(self.level, f"Entering context: {self.context}")
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self.logger.log(logging.ERROR, f"Exiting context with error: {exc_val}")
        else:
            self.logger.log(self.level, "Exiting context")
        
        # Restore previous context
        if self.old_context:
            self.logger.context = self.old_context
        else:
            delattr(self.logger, 'context')
        
        # Don't suppress exceptions
        return False 