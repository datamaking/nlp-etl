"""
Embedding module for the NLP ETL Pipeline
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Union, Iterator
import logging
import numpy as np
import pickle
import os
import tensorflow as tf
import traceback
from io import BytesIO

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.functions import udf, pandas_udf
from pyspark.ml.feature import HashingTF, IDF, Tokenizer, CountVectorizer
from pyspark.ml import Pipeline
from pyspark.ml.linalg import DenseVector, SparseVector, Vectors

from src.config.config import EmbeddingConfig, EmbeddingType, Department
from src.logging_module.logger import get_logger, log_execution_time
from src.exception.exceptions import handle_exception, EmbeddingError, ModelLoadError
from src.utils.spark_utils import persist_dataframe

logger = get_logger(__name__)


class Embedder(ABC):
    """Abstract base class for all embedders"""
    
    def __init__(self, config: EmbeddingConfig, spark: SparkSession):
        """
        Initialize the embedder
        
        Args:
            config: Embedding configuration
            spark: Spark session
        """
        self.config = config
        self.spark = spark
        self.validate_config()
    
    def validate_config(self) -> bool:
        """
        Validate the configuration
        
        Returns:
            True if configuration is valid, False otherwise
        """
        if not self.config.validate():
            raise EmbeddingError("Invalid embedding configuration")
        return True
    
    @abstractmethod
    def generate_embeddings(self, df: DataFrame) -> DataFrame:
        """
        Generate embeddings for text
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with embeddings
        """
        pass


class TFIDFEmbedder(Embedder):
    """Embedder that uses TF-IDF for generating embeddings"""
    
    @log_execution_time(stage_name="TFIDFEmbedding")
    @handle_exception
    def generate_embeddings(self, df: DataFrame) -> DataFrame:
        """
        Generate TF-IDF embeddings for text
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with TF-IDF embeddings
        """
        logger.info("Generating TF-IDF embeddings")
        
        # Check if text column exists
        if "chunk_text" not in df.columns:
            raise EmbeddingError("chunk_text column not found in DataFrame")
        
        # Get parameters from config
        num_features = self.config.params.get("num_features", 1024)
        min_term_freq = self.config.params.get("min_term_freq", 2)
        
        # Build pipeline for TF-IDF
        tokenizer = Tokenizer(inputCol="chunk_text", outputCol="words")
        
        # Use CountVectorizer instead of HashingTF to get interpretable features
        cv = CountVectorizer(inputCol="words", outputCol="tf", vocabSize=num_features, minDF=min_term_freq)
        idf = IDF(inputCol="tf", outputCol="embedding")
        
        pipeline = Pipeline(stages=[tokenizer, cv, idf])
        
        # Fit and transform
        logger.info(f"Fitting TF-IDF model with {num_features} features")
        pipeline_model = pipeline.fit(df)
        
        # Transform data to get embeddings
        result_df = pipeline_model.transform(df)
        
        # Save vocabulary for interpretability
        try:
            vocab = pipeline_model.stages[1].vocabulary
            vocab_file = f"tfidf_vocab_{len(vocab)}.pkl"
            with open(vocab_file, "wb") as f:
                pickle.dump(vocab, f)
            logger.info(f"Saved TF-IDF vocabulary to {vocab_file}")
        except Exception as e:
            logger.warning(f"Failed to save TF-IDF vocabulary: {str(e)}")
        
        # Return DataFrame with embeddings
        return result_df.select(
            "doc_id", 
            "chunk_id", 
            "chunk_text", 
            "chunk_index",
            "embedding"
        )


class ST5Embedder(Embedder):
    """Embedder that uses Google's ST5 model for generating sentence embeddings"""
    
    def __init__(self, config: EmbeddingConfig, spark: SparkSession):
        """
        Initialize the ST5 embedder
        
        Args:
            config: Embedding configuration
            spark: Spark session
        """
        super().__init__(config, spark)
        self.model = None
        self.tokenizer = None
        self.batch_size = config.batch_size
        self.max_sequence_length = config.max_sequence_length
        self.model_path = config.model_path
        
        # Additional config validation specific to ST5
        self._validate_st5_config()
    
    def _validate_st5_config(self):
        """Validate ST5-specific configuration"""
        if not self.model_path:
            raise ModelLoadError("Model path not specified for ST5 embedder")
    
    @handle_exception
    def _load_model(self):
        """Load the ST5 model and tokenizer"""
        logger.info(f"Loading ST5 model from {self.model_path}")
        
        try:
            # Suppress TensorFlow warnings
            os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
            
            # Import TensorFlow and Transformers libraries dynamically
            import tensorflow as tf
            from transformers import TFAutoModel, AutoTokenizer
            
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_path)
            
            # Load model
            self.model = TFAutoModel.from_pretrained(self.model_path)
            
            logger.info("ST5 model and tokenizer loaded successfully")
            
        except ImportError as e:
            error_msg = f"Required libraries not installed: {str(e)}"
            logger.error(error_msg)
            raise ModelLoadError(error_msg)
        except Exception as e:
            error_msg = f"Failed to load ST5 model: {str(e)}"
            logger.error(f"{error_msg}\n{traceback.format_exc()}")
            raise ModelLoadError(error_msg)
    
    @handle_exception
    def _get_embeddings(self, texts: List[str]) -> List[np.ndarray]:
        """
        Generate embeddings for a batch of texts
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding arrays
        """
        if self.model is None or self.tokenizer is None:
            self._load_model()
        
        # Encode inputs
        inputs = self.tokenizer(
            texts,
            padding="max_length",
            truncation=True,
            max_length=self.max_sequence_length,
            return_tensors="tf"
        )
        
        # Generate embeddings
        with tf.device('/CPU:0'):  # Force CPU to avoid GPU memory issues
            outputs = self.model(**inputs)
            
            # Use mean pooling of the last hidden state
            embeddings = outputs.last_hidden_state.numpy()
            attention_mask = inputs['attention_mask'].numpy()
            
            # Apply attention mask and compute mean
            masked_embeddings = embeddings * attention_mask[:, :, tf.newaxis]
            summed = masked_embeddings.sum(axis=1)
            counts = attention_mask.sum(axis=1).reshape(-1, 1)
            mean_pooled = summed / counts
            
            return [embedding for embedding in mean_pooled]
    
    @pandas_udf(T.ArrayType(T.FloatType()))
    def _st5_embeddings_udf(self, texts_series):
        """
        Pandas UDF for generating ST5 embeddings in batches
        
        Args:
            texts_series: Pandas series of texts
            
        Returns:
            Pandas series of embedding arrays
        """
        import pandas as pd
        
        # Load model if not loaded
        if self.model is None or self.tokenizer is None:
            self._load_model()
        
        # Process in batches
        all_embeddings = []
        batch_size = self.batch_size
        
        for i in range(0, len(texts_series), batch_size):
            batch_texts = texts_series[i:i+batch_size].tolist()
            batch_embeddings = self._get_embeddings(batch_texts)
            all_embeddings.extend([emb.tolist() for emb in batch_embeddings])
        
        return pd.Series(all_embeddings)
    
    @log_execution_time(stage_name="ST5Embedding")
    @handle_exception
    def generate_embeddings(self, df: DataFrame) -> DataFrame:
        """
        Generate ST5 embeddings for text
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with ST5 embeddings
        """
        logger.info("Generating ST5 embeddings")
        
        # Check if text column exists
        if "chunk_text" not in df.columns:
            raise EmbeddingError("chunk_text column not found in DataFrame")
        
        # Generate embeddings using pandas UDF
        result_df = df.withColumn("embedding_array", self._st5_embeddings_udf("chunk_text"))
        
        # Convert embedding array to vector
        @udf(returnType=T.VectorUDT())
        def array_to_vector(array):
            if array is None:
                return None
            return DenseVector(array)
        
        result_df = result_df.withColumn("embedding", array_to_vector("embedding_array"))
        
        # Return DataFrame with embeddings
        return result_df.select(
            "doc_id", 
            "chunk_id", 
            "chunk_text", 
            "chunk_index",
            "embedding"
        )


class BatchedST5Embedder(Embedder):
    """
    Embedder that processes chunks in batches to generate ST5 embeddings.
    This implementation is more memory-efficient for large datasets.
    """
    
    def __init__(self, config: EmbeddingConfig, spark: SparkSession):
        """
        Initialize the batched ST5 embedder
        
        Args:
            config: Embedding configuration
            spark: Spark session
        """
        super().__init__(config, spark)
        self.model_path = config.model_path
        self.batch_size = config.batch_size
        self.max_sequence_length = config.max_sequence_length
    
    @log_execution_time(stage_name="BatchedST5Embedding")
    @handle_exception
    def generate_embeddings(self, df: DataFrame) -> DataFrame:
        """
        Generate ST5 embeddings for text in batches
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with ST5 embeddings
        """
        logger.info("Generating ST5 embeddings in batches")
        
        # Check if text column exists
        if "chunk_text" not in df.columns:
            raise EmbeddingError("chunk_text column not found in DataFrame")
        
        # Persist DataFrame to avoid recomputation
        df = persist_dataframe(df)
        
        # Create a temporary view
        view_name = f"chunks_to_embed_{hash(df)}"
        df.createOrReplaceTempView(view_name)
        
        # Define the Python function for embedding generation
        def generate_batch_embeddings():
            try:
                # Import libraries
                import tensorflow as tf
                from transformers import TFAutoModel, AutoTokenizer
                import pandas as pd
                
                # Suppress TensorFlow warnings
                os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
                
                # Load model and tokenizer
                logger.info(f"Loading ST5 model from {self.model_path}")
                tokenizer = AutoTokenizer.from_pretrained(self.model_path)
                model = TFAutoModel.from_pretrained(self.model_path)
                
                # Get Spark session
                from pyspark.sql import SparkSession
                spark = SparkSession.builder.getOrCreate()
                
                # Process in batches
                batch_size = self.batch_size
                max_length = self.max_sequence_length
                
                # Get total count
                total_count = spark.sql(f"SELECT COUNT(*) FROM {view_name}").collect()[0][0]
                num_batches = (total_count // batch_size) + (1 if total_count % batch_size > 0 else 0)
                
                logger.info(f"Processing {total_count} chunks in {num_batches} batches")
                
                for batch_num in range(num_batches):
                    # Get batch data
                    batch_df = spark.sql(
                        f"""
                        SELECT doc_id, chunk_id, chunk_text, chunk_index
                        FROM {view_name}
                        ORDER BY chunk_id
                        LIMIT {batch_size} OFFSET {batch_num * batch_size}
                        """
                    )
                    
                    # Convert to pandas
                    batch_pd = batch_df.toPandas()
                    
                    if batch_pd.empty:
                        continue
                    
                    # Get texts
                    texts = batch_pd["chunk_text"].tolist()
                    
                    # Tokenize
                    inputs = tokenizer(
                        texts,
                        padding="max_length",
                        truncation=True,
                        max_length=max_length,
                        return_tensors="tf"
                    )
                    
                    # Generate embeddings
                    with tf.device('/CPU:0'):  # Force CPU to avoid GPU memory issues
                        outputs = model(**inputs)
                        
                        # Use mean pooling of the last hidden state
                        embeddings = outputs.last_hidden_state.numpy()
                        attention_mask = inputs['attention_mask'].numpy()
                        
                        # Apply attention mask and compute mean
                        masked_embeddings = embeddings * attention_mask[:, :, tf.newaxis]
                        summed = masked_embeddings.sum(axis=1)
                        counts = attention_mask.sum(axis=1).reshape(-1, 1)
                        mean_pooled = summed / counts
                    
                    # Convert to lists
                    embedding_lists = [embedding.tolist() for embedding in mean_pooled]
                    
                    # Add embeddings to dataframe
                    batch_pd["embedding_array"] = embedding_lists
                    
                    # Convert to Spark DataFrame
                    schema = T.StructType([
                        T.StructField("doc_id", T.StringType(), True),
                        T.StructField("chunk_id", T.StringType(), True),
                        T.StructField("chunk_text", T.StringType(), True),
                        T.StructField("chunk_index", T.IntegerType(), True),
                        T.StructField("embedding_array", T.ArrayType(T.FloatType()), True)
                    ])
                    
                    # Create a Spark DataFrame with embeddings
                    result_batch = spark.createDataFrame(batch_pd, schema=schema)
                    
                    # Write to temporary table
                    temp_table = f"temp_embeddings_batch_{batch_num}"
                    result_batch.createOrReplaceTempView(temp_table)
                    
                    # Append to result table
                    if batch_num == 0:
                        spark.sql(f"CREATE TABLE IF NOT EXISTS embeddings_result AS SELECT * FROM {temp_table}")
                    else:
                        spark.sql(f"INSERT INTO embeddings_result SELECT * FROM {temp_table}")
                    
                    # Drop temporary table
                    spark.sql(f"DROP TABLE IF EXISTS {temp_table}")
                    
                    logger.info(f"Processed batch {batch_num+1}/{num_batches}")
                
                return True
            
            except Exception as e:
                logger.error(f"Error generating embeddings: {str(e)}\n{traceback.format_exc()}")
                return False
        
        # Execute the batch processing function
        success = self.spark.sparkContext.parallelize([1]).map(lambda x: generate_batch_embeddings()).collect()[0]
        
        if not success:
            raise EmbeddingError("Failed to generate embeddings")
        
        # Get the result DataFrame
        result_df = self.spark.sql("SELECT * FROM embeddings_result")
        
        # Convert embedding array to vector
        @udf(returnType=T.VectorUDT())
        def array_to_vector(array):
            if array is None:
                return None
            return DenseVector(array)
        
        result_df = result_df.withColumn("embedding", array_to_vector("embedding_array"))
        
        # Drop the temporary table
        self.spark.sql("DROP TABLE IF EXISTS embeddings_result")
        
        # Return DataFrame with embeddings
        return result_df.select(
            "doc_id", 
            "chunk_id", 
            "chunk_text", 
            "chunk_index",
            "embedding"
        )


class CombinedEmbedder(Embedder):
    """Embedder that combines multiple embedding methods"""
    
    def __init__(self, configs: List[EmbeddingConfig], spark: SparkSession):
        """
        Initialize the combined embedder
        
        Args:
            configs: List of embedding configurations
            spark: Spark session
        """
        # Use the first config for base initialization
        super().__init__(configs[0], spark)
        self.configs = configs
        self.embedders = []
        
        # Create individual embedders
        for config in configs:
            if config.embedding_type == EmbeddingType.TFIDF:
                self.embedders.append(TFIDFEmbedder(config, spark))
            elif config.embedding_type == EmbeddingType.SENTENCE_ST5:
                self.embedders.append(ST5Embedder(config, spark))
    
    @log_execution_time(stage_name="CombinedEmbedding")
    @handle_exception
    def generate_embeddings(self, df: DataFrame) -> DataFrame:
        """
        Generate multiple types of embeddings
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with multiple embeddings
        """
        logger.info(f"Generating combined embeddings with {len(self.embedders)} methods")
        
        # Check if text column exists
        if "chunk_text" not in df.columns:
            raise EmbeddingError("chunk_text column not found in DataFrame")
        
        # Apply each embedder in sequence
        result_df = df
        
        for i, embedder in enumerate(self.embedders):
            logger.info(f"Applying embedder {i+1}/{len(self.embedders)}: {type(embedder).__name__}")
            
            # Generate embeddings
            embedding_df = embedder.generate_embeddings(df)
            
            # Rename the embedding column to avoid conflicts
            embedding_name = f"embedding_{i+1}"
            embedding_df = embedding_df.withColumnRenamed("embedding", embedding_name)
            
            # Join with result DataFrame
            if i == 0:
                result_df = embedding_df
            else:
                # Join on chunk_id
                result_df = result_df.join(
                    embedding_df.select("chunk_id", embedding_name),
                    on="chunk_id",
                    how="left"
                )
        
        # Create a combined embedding column if needed
        if len(self.embedders) > 1:
            logger.info("Creating combined embedding (not implemented yet, using first embedding)")
            result_df = result_df.withColumn("embedding", F.col("embedding_1"))
        
        return result_df


class EmbedderFactory:
    """Factory class for creating embedders"""
    
    @staticmethod
    def create_embedder(config: EmbeddingConfig, spark: SparkSession) -> Embedder:
        """
        Create an embedder based on configuration
        
        Args:
            config: Embedding configuration
            spark: Spark session
            
        Returns:
            Configured embedder
        """
        if config.embedding_type == EmbeddingType.TFIDF:
            return TFIDFEmbedder(config, spark)
        elif config.embedding_type == EmbeddingType.SENTENCE_ST5:
            # Check if we should use batched implementation
            if config.params.get("use_batched", False):
                return BatchedST5Embedder(config, spark)
            else:
                return ST5Embedder(config, spark)
        else:
            raise EmbeddingError(f"Unsupported embedding type: {config.embedding_type}")
    
    @staticmethod
    def create_combined_embedder(configs: List[EmbeddingConfig], spark: SparkSession) -> Embedder:
        """
        Create a combined embedder with multiple methods
        
        Args:
            configs: List of embedding configurations
            spark: Spark session
            
        Returns:
            Combined embedder
        """
        return CombinedEmbedder(configs, spark) 