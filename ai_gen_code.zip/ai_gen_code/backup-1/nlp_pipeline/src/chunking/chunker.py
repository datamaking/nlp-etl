"""
Chunking module for the NLP ETL Pipeline
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
import logging
import re
import hashlib
import uuid

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.functions import udf

from src.config.config import ChunkingConfig, ChunkingStrategy, Department
from src.logging_module.logger import get_logger, log_execution_time
from src.exception.exceptions import handle_exception, ChunkingError
from src.utils.text_utils import segment_sentences, calculate_text_stats

logger = get_logger(__name__)


# Define schema for chunk arrays
chunk_schema = T.ArrayType(
    T.StructType([
        T.StructField("chunk_id", T.StringType(), False),
        T.StructField("chunk_text", T.StringType(), False),
        T.StructField("chunk_index", T.IntegerType(), False),
        T.StructField("doc_id", T.StringType(), False),
        T.StructField("start_idx", T.IntegerType(), True),
        T.StructField("end_idx", T.IntegerType(), True)
    ])
)


@udf(returnType=chunk_schema)
def fixed_size_chunking_udf(text, doc_id, chunk_size, chunk_overlap):
    """
    UDF for fixed size chunking
    
    Args:
        text: Text to chunk
        doc_id: Document ID
        chunk_size: Size of each chunk in characters
        chunk_overlap: Overlap between chunks in characters
        
    Returns:
        Array of chunk structs
    """
    if not text or not isinstance(text, str):
        return []
    
    chunks = []
    step_size = chunk_size - chunk_overlap
    
    for i in range(0, len(text), step_size):
        # Create chunk
        start_idx = i
        end_idx = min(i + chunk_size, len(text))
        chunk_text = text[start_idx:end_idx]
        
        # Skip empty chunks
        if not chunk_text.strip():
            continue
        
        # Generate chunk ID
        chunk_index = len(chunks)
        chunk_id = f"{doc_id}_{chunk_index}"
        
        # Add chunk
        chunks.append({
            "chunk_id": chunk_id,
            "chunk_text": chunk_text,
            "chunk_index": chunk_index,
            "doc_id": doc_id,
            "start_idx": start_idx,
            "end_idx": end_idx
        })
    
    return chunks


@udf(returnType=chunk_schema)
def sentence_chunking_udf(text, doc_id, max_sentences, sentence_overlap):
    """
    UDF for sentence-based chunking
    
    Args:
        text: Text to chunk
        doc_id: Document ID
        max_sentences: Maximum number of sentences per chunk
        sentence_overlap: Number of sentences to overlap
        
    Returns:
        Array of chunk structs
    """
    if not text or not isinstance(text, str):
        return []
    
    # Split text into sentences
    sentences = segment_sentences(text)
    
    if not sentences:
        return []
    
    chunks = []
    step_size = max_sentences - sentence_overlap
    
    # Find start and end indices for each sentence
    sentence_indices = []
    start_idx = 0
    
    for sentence in sentences:
        # Find where this sentence appears in the original text
        sentence_start = text.find(sentence, start_idx)
        if sentence_start == -1:  # Should not happen
            sentence_start = start_idx
        
        sentence_end = sentence_start + len(sentence)
        sentence_indices.append((sentence_start, sentence_end))
        start_idx = sentence_end
    
    # Create chunks
    for i in range(0, len(sentences), step_size):
        end_idx = min(i + max_sentences, len(sentences))
        chunk_sentences = sentences[i:end_idx]
        
        # Skip empty chunks
        if not chunk_sentences:
            continue
        
        # Get start and end indices
        start_pos = sentence_indices[i][0]
        end_pos = sentence_indices[end_idx - 1][1]
        
        # Create chunk text
        chunk_text = text[start_pos:end_pos]
        
        # Generate chunk ID
        chunk_index = len(chunks)
        chunk_id = f"{doc_id}_{chunk_index}"
        
        # Add chunk
        chunks.append({
            "chunk_id": chunk_id,
            "chunk_text": chunk_text,
            "chunk_index": chunk_index,
            "doc_id": doc_id,
            "start_idx": start_pos,
            "end_idx": end_pos
        })
    
    return chunks


@udf(returnType=chunk_schema)
def paragraph_chunking_udf(text, doc_id, max_paragraphs, paragraph_overlap):
    """
    UDF for paragraph-based chunking
    
    Args:
        text: Text to chunk
        doc_id: Document ID
        max_paragraphs: Maximum number of paragraphs per chunk
        paragraph_overlap: Number of paragraphs to overlap
        
    Returns:
        Array of chunk structs
    """
    if not text or not isinstance(text, str):
        return []
    
    # Split text into paragraphs
    paragraphs = [p for p in re.split(r'\n\s*\n', text) if p.strip()]
    
    if not paragraphs:
        return []
    
    chunks = []
    step_size = max_paragraphs - paragraph_overlap
    
    # Find start and end indices for each paragraph
    paragraph_indices = []
    start_idx = 0
    
    for paragraph in paragraphs:
        # Find where this paragraph appears in the original text
        paragraph_start = text.find(paragraph, start_idx)
        if paragraph_start == -1:  # Should not happen
            paragraph_start = start_idx
        
        paragraph_end = paragraph_start + len(paragraph)
        paragraph_indices.append((paragraph_start, paragraph_end))
        start_idx = paragraph_end
    
    # Create chunks
    for i in range(0, len(paragraphs), step_size):
        end_idx = min(i + max_paragraphs, len(paragraphs))
        chunk_paragraphs = paragraphs[i:end_idx]
        
        # Skip empty chunks
        if not chunk_paragraphs:
            continue
        
        # Get start and end indices
        start_pos = paragraph_indices[i][0]
        end_pos = paragraph_indices[end_idx - 1][1]
        
        # Create chunk text
        chunk_text = text[start_pos:end_pos]
        
        # Generate chunk ID
        chunk_index = len(chunks)
        chunk_id = f"{doc_id}_{chunk_index}"
        
        # Add chunk
        chunks.append({
            "chunk_id": chunk_id,
            "chunk_text": chunk_text,
            "chunk_index": chunk_index,
            "doc_id": doc_id,
            "start_idx": start_pos,
            "end_idx": end_pos
        })
    
    return chunks


@udf(returnType=chunk_schema)
def recursive_chunking_udf(text, doc_id, max_chunk_size, min_chunk_size):
    """
    UDF for recursive chunking
    
    Args:
        text: Text to chunk
        doc_id: Document ID
        max_chunk_size: Maximum size of each chunk in characters
        min_chunk_size: Minimum size of each chunk in characters
        
    Returns:
        Array of chunk structs
    """
    if not text or not isinstance(text, str):
        return []
    
    # Helper function to recursively split text
    def recursive_split(text, start_idx=0):
        if len(text) <= max_chunk_size:
            return [(text, start_idx, start_idx + len(text))]
        
        # Try to split at paragraph boundaries
        paragraph_splits = [m.end() for m in re.finditer(r'\n\s*\n', text)]
        for split_point in paragraph_splits:
            if min_chunk_size <= split_point <= max_chunk_size:
                left = text[:split_point]
                right = text[split_point:]
                
                return [(left, start_idx, start_idx + len(left))] + recursive_split(right, start_idx + len(left))
        
        # Try to split at sentence boundaries
        sentence_splits = [m.end() for m in re.finditer(r'[.!?]\s+', text)]
        for split_point in sentence_splits:
            if min_chunk_size <= split_point <= max_chunk_size:
                left = text[:split_point]
                right = text[split_point:]
                
                return [(left, start_idx, start_idx + len(left))] + recursive_split(right, start_idx + len(left))
        
        # Fall back to splitting at word boundaries
        words = text.split()
        if len(words) <= 1:
            # Can't split further, just return as is
            return [(text, start_idx, start_idx + len(text))]
        
        # Find a middle word to split on
        mid_idx = len(words) // 2
        left_text = ' '.join(words[:mid_idx])
        right_text = ' '.join(words[mid_idx:])
        
        return recursive_split(left_text, start_idx) + recursive_split(right_text, start_idx + len(left_text) + 1)
    
    # Split text recursively
    split_chunks = recursive_split(text)
    
    # Convert to chunk objects
    chunks = []
    for i, (chunk_text, start_pos, end_pos) in enumerate(split_chunks):
        # Skip empty chunks
        if not chunk_text.strip():
            continue
        
        # Generate chunk ID
        chunk_id = f"{doc_id}_{i}"
        
        # Add chunk
        chunks.append({
            "chunk_id": chunk_id,
            "chunk_text": chunk_text,
            "chunk_index": i,
            "doc_id": doc_id,
            "start_idx": start_pos,
            "end_idx": end_pos
        })
    
    return chunks


@udf(returnType=chunk_schema)
def semantic_chunking_udf(text, doc_id, max_chunk_size, min_chunk_size):
    """
    UDF for semantic chunking
    
    Args:
        text: Text to chunk
        doc_id: Document ID
        max_chunk_size: Maximum size of each chunk in characters
        min_chunk_size: Minimum size of each chunk in characters
        
    Returns:
        Array of chunk structs
    """
    if not text or not isinstance(text, str):
        return []
    
    # This is a simplified semantic chunking that uses a heuristic approach
    # In a real implementation, you might use NLP techniques to detect topic shifts
    
    # Split text into sentences
    sentences = segment_sentences(text)
    
    if not sentences:
        return []
    
    chunks = []
    current_chunk = []
    current_length = 0
    chunk_index = 0
    start_idx = 0
    last_end_idx = 0
    
    # Calculate sentence positions in original text
    sentence_positions = []
    pos = 0
    for sentence in sentences:
        sentence_start = text.find(sentence, pos)
        if sentence_start == -1:
            sentence_start = pos
        sentence_end = sentence_start + len(sentence)
        sentence_positions.append((sentence_start, sentence_end))
        pos = sentence_end
    
    # Group sentences into chunks
    for i, sentence in enumerate(sentences):
        sentence_start, sentence_end = sentence_positions[i]
        
        # If adding this sentence would exceed max_chunk_size and we have at least min_chunk_size
        # Or if we detect a potential topic change (simplified heuristic: long sentences or certain keywords)
        if (current_length + len(sentence) > max_chunk_size and current_length >= min_chunk_size) or \
           (len(current_chunk) > 0 and (len(sentence) > 100 or re.search(r'\b(however|nevertheless|in contrast|on the other hand)\b', sentence, re.IGNORECASE))):
            
            # Finish current chunk
            if current_chunk:
                chunk_text = text[start_idx:last_end_idx]
                
                # Generate chunk ID
                chunk_id = f"{doc_id}_{chunk_index}"
                
                # Add chunk
                chunks.append({
                    "chunk_id": chunk_id,
                    "chunk_text": chunk_text,
                    "chunk_index": chunk_index,
                    "doc_id": doc_id,
                    "start_idx": start_idx,
                    "end_idx": last_end_idx
                })
                
                chunk_index += 1
                current_chunk = []
                current_length = 0
                start_idx = sentence_start
        
        # Add sentence to current chunk
        if not current_chunk:
            start_idx = sentence_start
            
        current_chunk.append(sentence)
        current_length += len(sentence)
        last_end_idx = sentence_end
    
    # Add the last chunk if not empty
    if current_chunk:
        chunk_text = text[start_idx:last_end_idx]
        
        # Generate chunk ID
        chunk_id = f"{doc_id}_{chunk_index}"
        
        # Add chunk
        chunks.append({
            "chunk_id": chunk_id,
            "chunk_text": chunk_text,
            "chunk_index": chunk_index,
            "doc_id": doc_id,
            "start_idx": start_idx,
            "end_idx": last_end_idx
        })
    
    return chunks


@udf(returnType=T.ArrayType(T.StringType()))
def smoothing_udf(chunks):
    """
    UDF for smoothing chunks
    
    Args:
        chunks: Array of chunk structs
        
    Returns:
        Array of smoothed chunk texts
    """
    if not chunks or len(chunks) <= 1:
        return [chunk["chunk_text"] for chunk in chunks]
    
    # Simple smoothing: make sure sentences aren't cut off
    smoothed_chunks = []
    
    for i, chunk in enumerate(chunks):
        chunk_text = chunk["chunk_text"]
        
        # Check if chunk ends with a partial sentence
        if not re.search(r'[.!?][\s"\']*$', chunk_text):
            # If not the last chunk, try to find a complete sentence boundary
            if i < len(chunks) - 1:
                next_chunk = chunks[i + 1]["chunk_text"]
                
                # Look for the first sentence end in the next chunk
                match = re.search(r'^[^.!?]*[.!?]', next_chunk)
                if match:
                    # Add the complete sentence from the next chunk
                    chunk_text += " " + match.group(0)
        
        smoothed_chunks.append(chunk_text)
    
    return smoothed_chunks


class Chunker(ABC):
    """Abstract base class for all chunkers"""
    
    def __init__(self, config: ChunkingConfig, spark: SparkSession):
        """
        Initialize the chunker
        
        Args:
            config: Chunking configuration
            spark: Spark session
        """
        self.config = config
        self.spark = spark
        self.validate_config()
    
    def validate_config(self) -> bool:
        """
        Validate the configuration
        
        Returns:
            True if configuration is valid, False otherwise
        """
        if not self.config.validate():
            raise ChunkingError("Invalid chunking configuration")
        return True
    
    @abstractmethod
    def chunk(self, df: DataFrame) -> DataFrame:
        """
        Chunk the text in the DataFrame
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with chunked text
        """
        pass
    
    @handle_exception
    def generate_doc_ids(self, df: DataFrame) -> DataFrame:
        """
        Generate document IDs if not present
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with document IDs
        """
        if "doc_id" not in df.columns:
            logger.info("Generating document IDs")
            
            # Define UDF for generating document IDs
            @udf(returnType=T.StringType())
            def generate_doc_id(text):
                if not text:
                    return str(uuid.uuid4())
                # Create a deterministic ID based on text content
                return hashlib.md5(text.encode()).hexdigest()
            
            return df.withColumn("doc_id", generate_doc_id("text"))
        
        return df
    
    @handle_exception
    def apply_smoothing(self, df: DataFrame) -> DataFrame:
        """
        Apply chunk smoothing if enabled
        
        Args:
            df: DataFrame with chunks
            
        Returns:
            DataFrame with smoothed chunks
        """
        if not self.config.enable_smoothing:
            return df
        
        logger.info("Applying chunk smoothing")
        
        return df.withColumn("smoothed_chunks", smoothing_udf("chunks"))


class FixedSizeChunker(Chunker):
    """Chunker that creates fixed-size chunks of text"""
    
    @log_execution_time(stage_name="FixedSizeChunking")
    @handle_exception
    def chunk(self, df: DataFrame) -> DataFrame:
        """
        Chunk text into fixed-size chunks
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with chunked text
        """
        logger.info(f"Chunking text with fixed size strategy, chunk size: {self.config.chunk_size}, overlap: {self.config.chunk_overlap}")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise ChunkingError("Text column not found in DataFrame")
        
        # Ensure document IDs are present
        df = self.generate_doc_ids(df)
        
        # Apply chunking
        chunked_df = df.withColumn(
            "chunks",
            fixed_size_chunking_udf(
                "text",
                "doc_id",
                F.lit(self.config.chunk_size),
                F.lit(self.config.chunk_overlap)
            )
        )
        
        # Apply smoothing if enabled
        if self.config.enable_smoothing:
            chunked_df = self.apply_smoothing(chunked_df)
        
        return chunked_df


class SentenceChunker(Chunker):
    """Chunker that creates chunks based on sentences"""
    
    @log_execution_time(stage_name="SentenceChunking")
    @handle_exception
    def chunk(self, df: DataFrame) -> DataFrame:
        """
        Chunk text based on sentences
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with chunked text
        """
        logger.info("Chunking text with sentence strategy")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise ChunkingError("Text column not found in DataFrame")
        
        # Ensure document IDs are present
        df = self.generate_doc_ids(df)
        
        # Get parameters from config with defaults
        max_sentences = self.config.params.get("max_sentences", 5)
        sentence_overlap = self.config.params.get("sentence_overlap", 1)
        
        # Apply chunking
        chunked_df = df.withColumn(
            "chunks",
            sentence_chunking_udf(
                "text",
                "doc_id",
                F.lit(max_sentences),
                F.lit(sentence_overlap)
            )
        )
        
        # Apply smoothing if enabled
        if self.config.enable_smoothing:
            chunked_df = self.apply_smoothing(chunked_df)
        
        return chunked_df


class ParagraphChunker(Chunker):
    """Chunker that creates chunks based on paragraphs"""
    
    @log_execution_time(stage_name="ParagraphChunking")
    @handle_exception
    def chunk(self, df: DataFrame) -> DataFrame:
        """
        Chunk text based on paragraphs
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with chunked text
        """
        logger.info("Chunking text with paragraph strategy")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise ChunkingError("Text column not found in DataFrame")
        
        # Ensure document IDs are present
        df = self.generate_doc_ids(df)
        
        # Get parameters from config with defaults
        max_paragraphs = self.config.params.get("max_paragraphs", 3)
        paragraph_overlap = self.config.params.get("paragraph_overlap", 0)
        
        # Apply chunking
        chunked_df = df.withColumn(
            "chunks",
            paragraph_chunking_udf(
                "text",
                "doc_id",
                F.lit(max_paragraphs),
                F.lit(paragraph_overlap)
            )
        )
        
        # Apply smoothing if enabled
        if self.config.enable_smoothing:
            chunked_df = self.apply_smoothing(chunked_df)
        
        return chunked_df


class RecursiveChunker(Chunker):
    """Chunker that recursively splits text into chunks"""
    
    @log_execution_time(stage_name="RecursiveChunking")
    @handle_exception
    def chunk(self, df: DataFrame) -> DataFrame:
        """
        Chunk text recursively
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with chunked text
        """
        logger.info("Chunking text with recursive strategy")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise ChunkingError("Text column not found in DataFrame")
        
        # Ensure document IDs are present
        df = self.generate_doc_ids(df)
        
        # Get parameters from config with defaults
        max_chunk_size = self.config.params.get("max_chunk_size", self.config.chunk_size)
        min_chunk_size = self.config.params.get("min_chunk_size", max_chunk_size // 2)
        
        # Apply chunking
        chunked_df = df.withColumn(
            "chunks",
            recursive_chunking_udf(
                "text",
                "doc_id",
                F.lit(max_chunk_size),
                F.lit(min_chunk_size)
            )
        )
        
        # Apply smoothing if enabled
        if self.config.enable_smoothing:
            chunked_df = self.apply_smoothing(chunked_df)
        
        return chunked_df


class SemanticChunker(Chunker):
    """Chunker that creates chunks based on semantic boundaries"""
    
    @log_execution_time(stage_name="SemanticChunking")
    @handle_exception
    def chunk(self, df: DataFrame) -> DataFrame:
        """
        Chunk text based on semantic boundaries
        
        Args:
            df: DataFrame with input data
            
        Returns:
            DataFrame with chunked text
        """
        logger.info("Chunking text with semantic strategy")
        
        # Check if text column exists
        if "text" not in df.columns:
            raise ChunkingError("Text column not found in DataFrame")
        
        # Ensure document IDs are present
        df = self.generate_doc_ids(df)
        
        # Get parameters from config with defaults
        max_chunk_size = self.config.params.get("max_chunk_size", self.config.chunk_size)
        min_chunk_size = self.config.params.get("min_chunk_size", max_chunk_size // 3)
        
        # Apply chunking
        chunked_df = df.withColumn(
            "chunks",
            semantic_chunking_udf(
                "text",
                "doc_id",
                F.lit(max_chunk_size),
                F.lit(min_chunk_size)
            )
        )
        
        # Apply smoothing if enabled
        if self.config.enable_smoothing:
            chunked_df = self.apply_smoothing(chunked_df)
        
        return chunked_df


@log_execution_time(stage_name="ExplodeChunks")
@handle_exception
def explode_chunks(df: DataFrame) -> DataFrame:
    """
    Explode the chunks array into separate rows
    
    Args:
        df: DataFrame with chunks column
        
    Returns:
        DataFrame with one row per chunk
    """
    logger.info("Exploding chunks into separate rows")
    
    # Check if chunks column exists
    if "chunks" not in df.columns:
        raise ChunkingError("Chunks column not found in DataFrame")
    
    # Select only necessary columns and explode chunks
    if "smoothed_chunks" in df.columns:
        # Create a sequential index to match smoothed_chunks with original chunks
        return df.select(
            "doc_id",
            F.posexplode("chunks").alias("chunk_index", "chunk"),
            F.posexplode("smoothed_chunks").alias("smoothed_index", "smoothed_chunk_text")
        ).filter("chunk_index = smoothed_index").select(
            "doc_id",
            F.col("chunk.chunk_id").alias("chunk_id"),
            F.col("smoothed_chunk_text").alias("chunk_text"),
            F.col("chunk.chunk_index").alias("chunk_index"),
            F.col("chunk.start_idx").alias("start_idx"),
            F.col("chunk.end_idx").alias("end_idx")
        )
    else:
        return df.select(
            "doc_id",
            F.explode("chunks").alias("chunk")
        ).select(
            "doc_id",
            F.col("chunk.chunk_id").alias("chunk_id"),
            F.col("chunk.chunk_text").alias("chunk_text"),
            F.col("chunk.chunk_index").alias("chunk_index"),
            F.col("chunk.start_idx").alias("start_idx"),
            F.col("chunk.end_idx").alias("end_idx")
        )


class ChunkerFactory:
    """Factory class for creating chunkers"""
    
    @staticmethod
    def create_chunker(config: ChunkingConfig, spark: SparkSession) -> Chunker:
        """
        Create a chunker based on configuration
        
        Args:
            config: Chunking configuration
            spark: Spark session
            
        Returns:
            Configured chunker
        """
        if config.chunking_strategy == ChunkingStrategy.FIXED_SIZE:
            return FixedSizeChunker(config, spark)
        elif config.chunking_strategy == ChunkingStrategy.SENTENCE:
            return SentenceChunker(config, spark)
        elif config.chunking_strategy == ChunkingStrategy.PARAGRAPH:
            return ParagraphChunker(config, spark)
        elif config.chunking_strategy == ChunkingStrategy.RECURSIVE:
            return RecursiveChunker(config, spark)
        elif config.chunking_strategy == ChunkingStrategy.SEMANTIC:
            return SemanticChunker(config, spark)
        else:
            raise ChunkingError(f"Unsupported chunking strategy: {config.chunking_strategy}") 